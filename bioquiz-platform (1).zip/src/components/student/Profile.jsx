// ✅ Dynamic User Profile Cabinet with PRO Upgrade checks and virtual coins refiller
import React, { useState } from 'react';
import { useAuthStore } from '../../store/useAuthStore';
import { useAppStore } from '../../store/useAppStore';
import { triggerHaptic } from '../../lib/telegramAuth';
import Button from '../ui/Button';
import Card from '../ui/Card';
import Input from '../ui/Input';
import Badge from '../ui/Badge';
import { User, ShieldAlert, Award, Coins, Sparkles, ShoppingCart } from 'lucide-react';

export default function StudentProfile() {
  const { profile, updateProfile, addCredits } = useAuthStore();
  const { showToast } = useAppStore();

  const [newName, setNewName] = useState(profile?.full_name || '');
  const [newCenter, setNewCenter] = useState(profile?.learning_center || '');
  const [submitting, setSubmitting] = useState(false);

  const handleUpdateUser = async (e) => {
    e.preventDefault();
    if (!newName.trim()) {
      showToast("Ism bo'sh bo'lishi mumkin emas!", "warning");
      return;
    }

    setSubmitting(true);
    triggerHaptic('light');

    try {
      await updateProfile({
        full_name: newName.trim(),
        learning_center: newCenter.trim()
      });
      showToast("Profil tahrirlari muvaffaqiyatli saqlandi!", "success");
    } catch (e) {
      showToast("Xatolik yuz berdi.", "error");
    } finally {
      setSubmitting(false);
    }
  };

  const handleBuyCredits = async (amount) => {
    triggerHaptic('success');
    try {
      await addCredits(amount);
      showToast(`${amount.toLocaleString()} UZS balansga qo'shildi!`, "success");
    } catch (e) {
      showToast("Balansni to'ldirish barbod bo'ldi.", "error");
    }
  };

  const handleBuyProStatus = async () => {
    triggerHaptic('success');
    const balance = profile?.wallet_balance || 0;
    
    if (balance < 50000) {
      showToast("Virtual balansingiz yetarli emas! Premium sotib olish 50,000 UZS", "error");
      return;
    }

    try {
      const net = balance - 50000;
      await updateProfile({
        wallet_balance: net,
        is_pro: true
      });
      showToast("Tabriklaymiz! Siz PRO a'zolikka muvaffaqiyatli daryoverlandingiz!", "success");
    } catch (err) {
      showToast("PRO ulanishda og'ish yuz berdi.", "error");
    }
  };

  return (
    <div id="student_profile_frame" className="w-full space-y-6 animate-fade-in text-left pb-[90px]">
      
      {/* Visual Title Header */}
      <div className="text-left space-y-0.5">
        <h3 className="text-xl font-extrabold text-white">Shaxsiy kabinet sozlamalari</h3>
        <p className="text-xs text-text-secondary font-medium">Profilingizni tahrirlang yoki hisob balansini ko'paytiring</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Left Column: Editable Form details and Role Switcher */}
        <div className="md:col-span-1 space-y-5">
          <Card variant="glass" className="p-5 space-y-4 border-border-subtle">
            <p className="text-xs font-bold font-mono tracking-wider text-text-secondary uppercase">Profil tahrirlari</p>
            
            <form onSubmit={handleUpdateUser} className="space-y-4">
              <Input
                label="Ism-sharafingiz"
                placeholder="Jasur Karimov"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                required
              />
              <Input
                label="O'quv markaz nomi"
                placeholder="Alfa Academy"
                value={newCenter}
                onChange={(e) => setNewCenter(e.target.value)}
              />

              <Button type="submit" variant="primary" size="md" className="w-full font-bold" isLoading={submitting}>
                Tahrirlarni Saqlash
              </Button>
            </form>
          </Card>

          {/* Elegant Role Switcher */}
          <Card variant="glass" className="p-5 space-y-4 border-border-subtle">
            <p className="text-xs font-bold font-mono tracking-wider text-text-secondary uppercase flex items-center gap-1.5">
              <ShieldAlert className="w-4.5 h-4.5 text-primary-cyan" /> Tizimdagi rolimiz
            </p>
            <p className="text-[10px] text-text-secondary leading-normal">
              Barcha funksiyalarni (test tuzish, dars o'tish, talaba paneli) sinab ko'rish uchun profilingiz rolimizni istalgan paytda o'zgartiring:
            </p>

            <div className="flex flex-col gap-2 pt-1">
              {[
                { id: 'student', label: 'Talaba (Student)', desc: 'Testlar yechish, flashcardlar' },
                { id: 'teacher', label: 'O\'qituvchi (Teacher)', desc: 'Test tuzish, sinf guruhlari' },
                { id: 'admin', label: 'Administrator (Admin)', desc: 'Barcha testlar va guruhlar' }
              ].map((r) => {
                const isSelected = profile?.role === r.id;
                return (
                  <button
                    key={r.id}
                    id={`role_switcher_btn_${r.id}`}
                    type="button"
                    onClick={() => {
                      triggerHaptic('success');
                      updateProfile({ role: r.id });
                      showToast(`Profil rolingiz "${r.label}" ga o'zgartirildi!`, 'success');
                    }}
                    className={`w-full text-left p-2.5 rounded-xl border transition-all duration-200 cursor-pointer flex flex-col gap-0.5
                    ${isSelected 
                      ? 'bg-primary-green/10 border-primary-green/50 shadow-[0_0_10px_rgba(0,230,118,0.1)]' 
                      : 'bg-surface-2 border-border-subtle hover:border-text-secondary/30'}`}
                  >
                    <div className="flex items-center justify-between">
                      <span className={`text-xs font-black ${isSelected ? 'text-primary-green' : 'text-white'}`}>
                        {r.label}
                      </span>
                      {isSelected && (
                        <span className="text-[9px] font-mono uppercase bg-primary-green text-bg font-extrabold px-1.5 py-0.5 rounded">Faol</span>
                      )}
                    </div>
                    <span className="text-[9px] text-text-secondary">{r.desc}</span>
                  </button>
                );
              })}
            </div>
          </Card>
        </div>

        {/* Right Column: Wallet Recharge & Pro Upgrade buy box */}
        <div className="md:col-span-2 space-y-5">
          {/* Top-up balance cards row */}
          <Card variant="glass" className="p-5 space-y-4 border-border-subtle">
            <h4 className="text-xs font-bold font-mono tracking-wider text-text-secondary uppercase flex items-center gap-1.5">
              <Coins className="w-4.5 h-4.5 text-primary-green animate-bounce" /> Virtual hisobni to'ldirish
            </h4>
            <p className="text-xs text-text-secondary">Premium testlarni sotib olish uchun hisobingizga quyidagi paketlarni qo'shing:</p>

            <div className="grid grid-cols-3 gap-3">
              {[
                { label: '+15k sum', val: 15000 },
                { label: '+30k sum', val: 30000 },
                { label: '+50k sum', val: 50000 }
              ].map((pack) => (
                <button
                  id={`refill_pack_${pack.val}`}
                  key={pack.val}
                  type="button"
                  onClick={() => handleBuyCredits(pack.val)}
                  className="bg-surface-2 hover:bg-primary-green hover:text-bg hover:shadow-[0_0_12px_rgba(0,230,118,0.2)] border border-border-subtle px-3.5 py-4 rounded-xl text-center cursor-pointer transition-all active:scale-95 text-white font-mono text-xs font-bold"
                >
                  {pack.label}
                </button>
              ))}
            </div>
          </Card>

          {/* Premium banner upgrade blocks */}
          <Card
            variant={profile?.is_pro ? "glass" : "active"}
            className={`p-5 space-y-4 relative overflow-hidden flex flex-col justify-between border-border-subtle ${!profile?.is_pro ? 'border-amber-400/50 shadow-[0_0_20px_rgba(255,215,0,0.1)]' : ''}`}
          >
            {/* Ambient pro gold visual background */}
            <div className="absolute right-0 top-0 -mr-6 -mt-6 w-24 h-24 bg-amber-400 rounded-full blur-3xl opacity-15" />

            <div className="flex items-center gap-3 border-b border-border-subtle/50 pb-3">
              <div className="p-2 bg-amber-500/10 text-amber-500 border border-amber-500/30 rounded-lg">
                <Sparkles className="w-5 h-5 animate-spin-slow" />
              </div>
              <div className="text-left">
                <h4 className="text-sm font-extrabold text-white">PRO Tizim a'zoligi</h4>
                <p className="text-xs text-text-secondary">Platformadagi barcha cheklovlarni butunlay bartaraf etish</p>
              </div>
            </div>

            {profile?.is_pro ? (
              <div className="flex items-center gap-2.5 text-xs text-[#00E676] font-bold">
                ✓ Siz hozirda PRO a'zoligingiz faolasiz! Cheksiz flashcardlar, OCR tahlillar ochiq.
              </div>
            ) : (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="text-left text-xs text-text-secondary space-y-1 max-w-sm">
                  <p>✓ Reklamasiz va cheksiz biologiya testlariga kirish</p>
                  <p>✓ Xato qilingan savollar bo'yicha interval flashcardlar darsligi</p>
                  <p>✓ AI tahlil hisobotlari o'quv doskasi</p>
                </div>

                <Button
                  variant="primary"
                  className="bg-amber-500 hover:bg-amber-600 shadow-[0_0_15px_rgba(245,158,11,0.35)] text-bg font-black px-6 flex items-center gap-2 self-start sm:self-center"
                  onClick={handleBuyProStatus}
                >
                  <ShoppingCart className="w-4 h-4" /> 50,000 UZS ga PRO bo'lish
                </Button>
              </div>
            )}
          </Card>
        </div>
      </div>

    </div>
  );
}

// ✅ DONE: src/components/student/Profile.jsx
