// ✅ Highly Polished Administrative AdminDashboard panel
import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabaseClient';
import { useAuthStore } from '../../store/useAuthStore';
import { useAppStore } from '../../store/useAppStore';
import { triggerHaptic } from '../../lib/telegramAuth';
import Card from '../ui/Card';
import Button from '../ui/Button';
import Badge from '../ui/Badge';
import Input from '../ui/Input';
import { 
  Users, 
  GraduationCap, 
  Send, 
  Search, 
  CheckCircle2, 
  XCircle, 
  Coins, 
  TrendingUp, 
  Calendar, 
  Clock, 
  Plus, 
  Minus, 
  MessageCircle, 
  UserPlus, 
  BookOpen, 
  ShieldCheck, 
  Globe 
} from 'lucide-react';

export default function AdminDashboard() {
  const { profile: currentAdmin } = useAuthStore();
  const { showToast } = useAppStore();

  const [activeTab, setActiveTab2] = useState('students'); // 'students' | 'teachers'

  const [students, setStudents] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [examResults, setExamResults] = useState([]);
  const [tests, setTests] = useState([]);
  const [groups, setGroups] = useState([]);
  const [loading, setLoading] = useState(true);

  // Search states
  const [studentSearch, setStudentSearch] = useState('');
  const [teacherSearch, setTeacherSearch] = useState('');

  // Selected student for detailed results view in Accordion
  const [expandedStudentId, setExpandedStudentId] = useState(null);

  // Edit states for virtual coin recharge or PRO state change directly in UI
  const [editingUserId, setEditingUserId] = useState(null);
  const [coinAmountChange, setCoinAmountChange] = useState('');

  useEffect(() => {
    loadAllAdminData();
  }, []);

  const loadAllAdminData = async () => {
    setLoading(true);
    try {
      // 1. Fetch profiles
      const { data: allProfiles, error: profilesErr } = await supabase
        .from('profiles')
        .select('*');
      
      if (profilesErr) throw profilesErr;

      // 2. Fetch exam results
      const { data: allResults, error: resultsErr } = await supabase
        .from('exam_results')
        .select('*')
        .order('completed_at', { ascending: false });

      if (resultsErr) throw resultsErr;

      // 3. Fetch tests
      const { data: allTests, error: testsErr } = await supabase
        .from('tests')
        .select('*');

      if (testsErr) throw testsErr;

      // 4. Fetch groups
      const { data: allGroups, error: groupsErr } = await supabase
        .from('groups')
        .select('*');

      if (groupsErr) throw groupsErr;

      // Parse profiles into Students vs Teachers
      const studentsList = (allProfiles || []).filter(p => p.role === 'student');
      const teachersList = (allProfiles || []).filter(p => p.role === 'teacher' || p.role === 'admin');

      setStudents(studentsList);
      setTeachers(teachersList);
      setExamResults(allResults || []);
      setTests(allTests || []);
      setGroups(allGroups || []);
    } catch (err) {
      console.error("Admin data loading error", err);
      showToast("Tizim ma'lumotlarini yuklashda xatolik yuz berdi.", "error");
    } finally {
      setLoading(false);
    }
  };

  // Switch student PRO status
  const handleToggleProStatus = async (user) => {
    triggerHaptic('success');
    const updatedProState = !user.is_pro;
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ is_pro: updatedProState })
        .eq('id', user.id);

      if (error) throw error;

      showToast(`PRO status muvaffaqiyatli saqlandi!`, "success");
      
      // Update local state instantly
      setStudents(prev => prev.map(s => s.id === user.id ? { ...s, is_pro: updatedProState } : s));
      setTeachers(prev => prev.map(t => t.id === user.id ? { ...t, is_pro: updatedProState } : t));
    } catch (err) {
      console.error(err);
      showToast("PRO darajani o'zgartirishda xatolik yuz berdi.", "error");
    }
  };

  // Modify user balance (recharge virtual coins)
  const handleRechargeCoins = async (user, changeType) => {
    triggerHaptic('medium');
    const parsedAmount = parseInt(coinAmountChange, 10);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      showToast("Iltimos to'g'ri tanga miqdorini kiriting!", "warning");
      return;
    }

    const currentBalance = user.wallet_balance || 0;
    const newBalance = changeType === 'add' ? currentBalance + parsedAmount : Math.max(0, currentBalance - parsedAmount);

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ wallet_balance: newBalance })
        .eq('id', user.id);

      if (error) throw error;

      showToast(`Balans muvaffaqiyatli yangilandi! Yangi balans: ${newBalance.toLocaleString()} UZS`, "success");
      
      // Update local state instantly
      setStudents(prev => prev.map(s => s.id === user.id ? { ...s, wallet_balance: newBalance } : s));
      setTeachers(prev => prev.map(t => t.id === user.id ? { ...t, wallet_balance: newBalance } : t));
      
      setEditingUserId(null);
      setCoinAmountChange('');
    } catch (err) {
      console.error(err);
      showToast("Balansni o'zgartirishda xatolik yuz berdi.", "error");
    }
  };

  const handleOpenTelegramDM = (username, telegramId) => {
    triggerHaptic('light');
    if (username) {
      // Open in a safe standard layout or window redirect
      window.open(`https://t.me/${username}`, '_blank');
      showToast(`${username} bilan bog'lanish uchun Telegram ochilmoqda`, 'info');
    } else {
      // Forward using user id if possible or fall back
      window.open(`tg://user?id=${telegramId}`, '_blank');
      showToast(`Telegram chatga yo'naltirilmoqda (ID: ${telegramId})`, 'info');
    }
  };

  // Filter lists based on search
  const filteredStudents = students.filter(s => 
    s.full_name.toLowerCase().includes(studentSearch.toLowerCase()) ||
    (s.username && s.username.toLowerCase().includes(studentSearch.toLowerCase())) ||
    String(s.telegram_id).includes(studentSearch)
  );

  const filteredTeachers = teachers.filter(t => 
    t.full_name.toLowerCase().includes(teacherSearch.toLowerCase()) ||
    (t.username && t.username.toLowerCase().includes(teacherSearch.toLowerCase())) ||
    (t.learning_center && t.learning_center.toLowerCase().includes(teacherSearch.toLowerCase())) ||
    String(t.telegram_id).includes(teacherSearch)
  );

  return (
    <div id="admin_portal_frame" className="w-full space-y-6 animate-fade-in pb-[90px] text-left">
      
      {/* Admin Panel Header with system stats */}
      <Card variant="glass" className="p-5 border-primary-green/20">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="text-left space-y-1">
            <div className="flex items-center gap-2">
              <span className="p-1 rounded-md bg-amber-400/10 text-amber-400"><ShieldCheck className="w-5 h-5" /></span>
              <p className="text-xs font-mono text-text-secondary uppercase">ADMINISTRATOR TIZIMI</p>
            </div>
            <h2 className="text-2xl font-black text-white">{currentAdmin?.full_name}</h2>
            <p className="text-xs text-text-secondary">Xush kelibsiz! Tizimdagi barcha foydalanuvchilar, faoliyat va imtihonlarni boshqaring.</p>
          </div>

          <div className="flex gap-2 text-center">
            <div className="bg-surface-2 border border-border-subtle/50 px-3 py-1.5 rounded-xl">
              <span className="block text-[8px] font-bold text-text-secondary uppercase">TALABALAR</span>
              <span className="block text-sm font-black font-mono text-primary-cyan">{students.length} ta</span>
            </div>
            <div className="bg-surface-2 border border-border-subtle/50 px-3 py-1.5 rounded-xl">
              <span className="block text-[8px] font-bold text-text-secondary uppercase">O'QITUVCHILAR</span>
              <span className="block text-sm font-black font-mono text-primary-green">{teachers.length} ta</span>
            </div>
          </div>
        </div>
      </Card>

      {/* Primary tab switches */}
      <div id="admin_navigation_tabs" className="flex border-b border-border-subtle/50 gap-2">
        <button
          onClick={() => { setActiveTab2('students'); triggerHaptic('light'); }}
          className={`flex-1 py-3 text-center text-xs font-bold transition-all border-b-2 
          ${activeTab === 'students' 
            ? 'border-primary-cyan text-primary-cyan bg-primary-cyan/5 rounded-t-xl' 
            : 'border-transparent text-text-secondary hover:text-white'}`}
        >
          <span className="flex items-center justify-center gap-1.5">
            <Users className="w-4 h-4" /> Talabalar va Natijalar
          </span>
        </button>

        <button
          onClick={() => { setActiveTab2('teachers'); triggerHaptic('light'); }}
          className={`flex-1 py-3 text-center text-xs font-bold transition-all border-b-2 
          ${activeTab === 'teachers' 
            ? 'border-primary-green text-primary-green bg-primary-green/5 rounded-t-xl' 
            : 'border-transparent text-text-secondary hover:text-white'}`}
        >
          <span className="flex items-center justify-center gap-1.5">
            <GraduationCap className="w-4 h-4" /> O'qituvchi & Markazlar
          </span>
        </button>
      </div>

      {loading ? (
        <div id="admin_loading_state" className="text-center py-20 space-y-4">
          <div className="w-10 h-10 border-4 border-t-primary-cyan border-border-subtle rounded-full animate-spin mx-auto" />
          <p className="text-xs text-text-secondary">Katta ma'lumotlar bazasi sinxronizatsiya qilinmoqda...</p>
        </div>
      ) : (
        <div id="admin_view_portals">
          
          {/* TAB 1: STUDENTS DIRECTORY */}
          {activeTab === 'students' && (
            <div className="space-y-4 animate-fade-in">
              <div className="relative">
                <Search className="absolute left-3.5 top-1/2 transform -translate-y-1/2 w-4 h-4 text-text-secondary" />
                <Input
                  className="pl-10"
                  placeholder="Talabani ismi, username yoki telegram ID orqali qidirish..."
                  value={studentSearch}
                  onChange={(e) => setStudentSearch(e.target.value)}
                />
              </div>

              <div className="space-y-4">
                {filteredStudents.length === 0 ? (
                  <div className="text-center py-10 text-xs italic text-text-secondary bg-surface-2 rounded-2xl border border-border-subtle">
                    Qidiruv bo'yicha hech qaysi o'quvchi topilmadi.
                  </div>
                ) : (
                  filteredStudents.map((stud) => {
                    const isExpanded = expandedStudentId === stud.id;
                    const resultsForThisStudent = examResults.filter(r => r.student_id === stud.id);
                    
                    return (
                      <Card key={stud.id} variant="glass" className="p-4 border-border-subtle space-y-3 transition-all duration-200">
                        {/* Upper Details Row */}
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div className="text-left space-y-1">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-extrabold text-[#E8F5E9] text-sm flex items-center gap-1">
                                {stud.full_name} 
                              </span>
                              <Badge variant={stud.is_pro ? "pro" : "premium"}>
                                {stud.is_pro ? "PRO" : "ODDIY"}
                              </Badge>
                            </div>
                            <div className="text-[10px] text-text-secondary space-y-0.5">
                              <p>Telegram ID: <strong className="font-mono text-white">{stud.telegram_id}</strong> {stud.username ? `· Username: @${stud.username}` : ''}</p>
                              <p>Markaz: <strong className="text-primary-cyan">{stud.learning_center || "Mavjud emas"}</strong> · Ulanish: {new Date(stud.created_at).toLocaleDateString()}</p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2 flex-wrap">
                            {/* DM Button with Telegram Link as requested */}
                            <Button 
                              variant="glass" 
                              size="sm" 
                              className="text-[10px] uppercase font-bold text-sky-400 border-sky-400/20 bg-sky-400/5 hover:bg-sky-400/10 flex items-center gap-1"
                              onClick={() => handleOpenTelegramDM(stud.username, stud.telegram_id)}
                            >
                              <MessageCircle className="w-3.5 h-3.5" /> Telegram DM
                            </Button>

                            {/* Options adjust */}
                            <Button 
                              variant="glass" 
                              size="sm" 
                              className="text-[10px] uppercase font-bold"
                              onClick={() => setEditingUserId(editingUserId === stud.id ? null : stud.id)}
                            >
                              Balans
                            </Button>

                            <Button 
                              variant={stud.is_pro ? "secondary" : "primary"} 
                              size="sm" 
                              className="text-[10px] uppercase font-bold"
                              onClick={() => handleToggleProStatus(stud)}
                            >
                              {stud.is_pro ? "Tushirish" : "Upgrade PRO"}
                            </Button>
                          </div>
                        </div>

                        {/* Adjust Balance / Wallet block */}
                        {editingUserId === stud.id && (
                          <div className="bg-surface-2 p-3 rounded-xl border border-border-subtle space-y-3 animate-fade-in">
                            <div className="flex justify-between items-center">
                              <span className="text-[11px] font-bold text-text-secondary">Virtual hamyonni boshqarish (Xozirgi balans: {stud.wallet_balance?.toLocaleString()} UZS)</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Input
                                placeholder="UZS miqdori..."
                                type="number"
                                value={coinAmountChange}
                                onChange={(e) => setCoinAmountChange(e.target.value)}
                                className="text-xs h-9"
                              />
                              <Button 
                                variant="primary" 
                                size="sm" 
                                className="h-9 px-3.5 text-xs flex items-center gap-1 font-black"
                                onClick={() => handleRechargeCoins(stud, 'add')}
                              >
                                <Plus className="w-3.5 h-3.5" /> Qo'shish
                              </Button>
                              <Button 
                                variant="danger" 
                                size="sm" 
                                className="h-9 px-3.5 text-xs flex items-center gap-1 font-black"
                                onClick={() => handleRechargeCoins(stud, 'sub')}
                              >
                                <Minus className="w-3.5 h-3.5" /> Ayirish
                              </Button>
                            </div>
                          </div>
                        )}

                        {/* Results Accordion switch */}
                        <div className="pt-2 border-t border-border-subtle/50 flex items-center justify-between gap-2">
                          <span className="text-[10px] text-text-secondary font-bold font-mono">
                            JAMI IMTIHONLAR: <strong className="text-primary-cyan">{resultsForThisStudent.length} ta dars</strong>
                          </span>

                          <button
                            onClick={() => {
                              triggerHaptic('light');
                              setExpandedStudentId(isExpanded ? null : stud.id);
                            }}
                            className="text-[10px] text-primary-cyan hover:underline font-bold focus:outline-none flex items-center gap-1 cursor-pointer"
                          >
                            {isExpanded ? "Yopish ▲" : "Natijalarni ko'rish ▼"}
                          </button>
                        </div>

                        {/* Detailed Results list accordion view */}
                        {isExpanded && (
                          <div className="bg-surface-2/60 border border-border-subtle rounded-xl p-3 space-y-2.5 mt-2 animate-fade-in font-sans">
                            <h5 className="text-[10px] font-bold text-text-secondary uppercase tracking-widest border-b border-border-subtle pb-1.5">Talaba imtihon natijalari</h5>
                            {resultsForThisStudent.length === 0 ? (
                              <p className="text-[11px] text-text-secondary italic">Ushbu talaba hali bironta ham test imtihonini topshirgani yo'q.</p>
                            ) : (
                              <div className="space-y-2 max-h-[220px] overflow-y-auto no-scrollbar">
                                {resultsForThisStudent.map((res, rid) => {
                                  // Locate test title
                                  const linkedTest = tests.find(t => t.id === res.test_id);
                                  return (
                                    <div key={res.id || rid} className="bg-surface-1 border border-border-subtle p-2.5 rounded-lg flex justify-between items-center text-left text-[11px]">
                                      <div className="space-y-0.5 max-w-[70%]">
                                        <h6 className="font-extrabold text-white truncate">{linkedTest?.title || "Noma'lum test imtihon"}</h6>
                                        <p className="text-[9px] text-text-secondary flex items-center gap-1">
                                          <Calendar className="w-3 h-3 text-text-muted" /> {new Date(res.completed_at).toLocaleDateString()} · 
                                          <Clock className="w-3 h-3 text-text-muted" /> {res.total_time_spent || 0}s spent
                                        </p>
                                      </div>
                                      <div className="text-right">
                                        <span className={`block font-extrabold text-sm ${res.percentage >= 60 ? 'text-primary-green' : 'text-danger-accent'}`}>{res.percentage}%</span>
                                        <span className="block text-[9px] text-text-secondary font-mono">To'g'ri: {res.score} / {res.total}</span>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        )}
                      </Card>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* TAB 2: TEACHERS DIRECTORY */}
          {activeTab === 'teachers' && (
            <div className="space-y-4 animate-fade-in">
              <div className="relative">
                <Search className="absolute left-3.5 top-1/2 transform -translate-y-1/2 w-4 h-4 text-text-secondary" />
                <Input
                  className="pl-10"
                  placeholder="Ustozni ismi, markazi, username yoki telegram ID orqali qidirish..."
                  value={teacherSearch}
                  onChange={(e) => setTeacherSearch(e.target.value)}
                />
              </div>

              <div className="space-y-4">
                {filteredTeachers.length === 0 ? (
                  <div className="text-center py-10 text-xs italic text-text-secondary bg-surface-2 rounded-2xl border border-border-subtle">
                    Hech qanday o'qituvchi topilmadi.
                  </div>
                ) : (
                  filteredTeachers.map((teach) => {
                    const teacherTests = tests.filter(t => t.teacher_id === teach.id);
                    const teacherGroups = groups.filter(g => g.teacher_id === teach.id);

                    return (
                      <Card key={teach.id} variant="glass" className="p-4 border-border-subtle space-y-3 text-left">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div className="space-y-1">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-extrabold text-white text-sm">
                                {teach.full_name}
                              </span>
                              <Badge variant="pro">
                                {teach.role === 'admin' ? 'BOSH ADMIN' : 'USTOZ'}
                              </Badge>
                            </div>
                            <div className="text-[10px] text-text-secondary space-y-0.5">
                              <p>Telegram ID: <strong className="font-mono text-white">{teach.telegram_id}</strong> {teach.username ? `· Username: @${teach.username}` : ''}</p>
                              <p>O'quv Markazi: <strong className="text-primary-green">{teach.learning_center || 'Biriktirilmagan'}</strong> · Faol: {new Date(teach.created_at).toLocaleDateString()}</p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            {/* DM Button with Telegram Link as requested */}
                            <Button 
                              variant="glass" 
                              size="sm" 
                              className="text-[10px] uppercase font-bold text-sky-400 border-sky-400/20 bg-sky-400/5 hover:bg-sky-400/10 flex items-center gap-1"
                              onClick={() => handleOpenTelegramDM(teach.username, teach.telegram_id)}
                            >
                              <MessageCircle className="w-3.5 h-3.5" /> Telegram DM
                            </Button>

                            <Button 
                              variant="glass" 
                              size="sm" 
                              className="text-[10px] uppercase font-bold"
                              onClick={() => setEditingUserId(editingUserId === teach.id ? null : teach.id)}
                            >
                              Balans
                            </Button>

                            <Button 
                              variant="secondary" 
                              size="sm" 
                              className="text-[10px] uppercase font-bold text-primary-cyan border-primary-cyan/20 bg-primary-cyan/5 hover:bg-primary-cyan/10"
                              onClick={() => handleToggleProStatus(teach)}
                            >
                              Toggle Pro
                            </Button>
                          </div>
                        </div>

                        {/* Adjust Balance for Teacher */}
                        {editingUserId === teach.id && (
                          <div className="bg-surface-2 p-3 rounded-xl border border-border-subtle space-y-3 animate-fade-in">
                            <div className="flex justify-between items-center">
                              <span className="text-[11px] font-bold text-text-secondary">Hamyonni boshqarish (Xozirgi balans: {teach.wallet_balance?.toLocaleString()} UZS)</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Input
                                placeholder="UZS miqdori..."
                                type="number"
                                value={coinAmountChange}
                                onChange={(e) => setCoinAmountChange(e.target.value)}
                                className="text-xs h-9"
                              />
                              <Button 
                                variant="primary" 
                                size="sm" 
                                className="h-9 px-3.5 text-xs flex items-center gap-1 font-black"
                                onClick={() => handleRechargeCoins(teach, 'add')}
                              >
                                <Plus className="w-3.5 h-3.5" /> Qo'shish
                              </Button>
                              <Button 
                                variant="danger" 
                                size="sm" 
                                className="h-9 px-3.5 text-xs flex items-center gap-1 font-black"
                                onClick={() => handleRechargeCoins(teach, 'sub')}
                              >
                                <Minus className="w-3.5 h-3.5" /> Ayirish
                              </Button>
                            </div>
                          </div>
                        )}

                        <div className="pt-2.5 border-t border-border-subtle/40 grid grid-cols-2 gap-2 text-center text-[10px] font-mono">
                          <div className="bg-surface-2/70 border border-border-subtle/40 p-1.5 rounded-lg">
                            <span className="block text-text-secondary uppercase text-[8px] font-bold">YARATGAN TESTLARI</span>
                            <span className="block font-black text-primary-green font-mono text-sm">{teacherTests.length} ta dars</span>
                          </div>
                          <div className="bg-surface-2/70 border border-border-subtle/40 p-1.5 rounded-lg">
                            <span className="block text-text-secondary uppercase text-[8px] font-bold">SINF GURUHLARI</span>
                            <span className="block font-black text-primary-cyan font-mono text-sm">{teacherGroups.length} ta sinf</span>
                          </div>
                        </div>
                      </Card>
                    );
                  })
                )}
              </div>
            </div>
          )}

        </div>
      )}
    </div>
  );
}
