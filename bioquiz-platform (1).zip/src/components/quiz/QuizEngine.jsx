// ✅ Student Dynamic Quiz Engine with reactive selections constraints and dot matrices
import React, { useEffect, useState } from 'react';
import { useQuizStore } from '../../store/useQuizStore';
import { useAuthStore } from '../../store/useAuthStore';
import { useAppStore } from '../../store/useAppStore';
import { triggerHaptic } from '../../lib/telegramAuth';
import Button from '../ui/Button';
import Card from '../ui/Card';
import Badge from '../ui/Badge';
import ProgressBar from '../ui/ProgressBar';
import { Clock, ArrowLeft, ArrowRight, CheckCircle, AlertTriangle, Play } from 'lucide-react';

export default function QuizEngine({ test, initialQuestions, onFinished }) {
  const { profile } = useAuthStore();
  const { showToast } = useAppStore();

  const {
    questions,
    currentIndex,
    answers,
    timeLeft,
    isEnded,
    startQuiz,
    selectAnswer,
    nextQuestion,
    prevQuestion,
    jumpToQuestion,
    finishQuiz,
    resetQuiz
  } = useQuizStore();

  const [scoreCompiledResult, setScoreCompiledResult] = useState(null);

  // Initialize Quiz Engine
  useEffect(() => {
    startQuiz(initialQuestions, test.time_limit || 20, null, 'solo', test.id);
    return () => {
      resetQuiz();
    };
  }, [test, initialQuestions]);

  const currentQ = questions[currentIndex];
  
  // Format seconds-left helper clock
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Check if current question was answered already
  const selectedAnswerIndex = currentQ ? answers[currentQ.id] : undefined;
  const isAnswered = selectedAnswerIndex !== undefined;

  const handleSelectOptionClick = (optionIndex) => {
    if (isAnswered) return; // locked once answered!
    selectAnswer(currentQ.id, optionIndex);
  };

  const handleFinishQuizAction = async () => {
    if (!window.confirm("Haqiqatdan ham testni muddatidan oldin tugatib natijalarni saqlamoqchimisiz?")) return;
    triggerHaptic('success');
    
    // Call finish quiz in store to compile failed topics and insert results in DB
    const results = await finishQuiz(profile?.id, profile?.learning_center);
    setScoreCompiledResult(results);
    
    if (onFinished) {
      onFinished(results);
    }
  };

  if (!currentQ) {
    return (
      <div className="min-h-[300px] flex items-center justify-center text-text-secondary">
        Imtihon savollar bazasi yuklanmoqda...
      </div>
    );
  }

  const completionPct = questions.length > 0 ? ((currentIndex + 1) / questions.length) * 100 : 0;
  
  // Dynamic warning if clock timer is low (less than 15 seconds left)
  const isTimeUrgent = timeLeft > 0 && timeLeft <= 15;

  return (
    <div id="quiz_engine_card_flow" className="w-full space-y-6 animate-fade-in text-left pb-[60px]">
      
      {/* Quiz timer progress headbar */}
      <Card variant="glass" className="p-4 border-primary-green/20">
        <div className="flex items-center justify-between">
          <div className="text-left space-y-0.5">
            <h3 className="font-extrabold text-white text-base truncate max-w-[200px] sm:max-w-xs">{test.title}</h3>
            <p className="text-xs text-text-secondary flex items-center gap-1.5 font-semibold">
              Savol: <strong className="text-white">{currentIndex + 1} / {questions.length}</strong>
            </p>
          </div>

          {/* Dynamic timer display clock */}
          {timeLeft > 0 ? (
            <div className={`flex items-center gap-2 border px-4 py-2 rounded-xl transition-all
            ${isTimeUrgent ? 'border-danger-accent bg-red-950/20 text-[#FF5252] animate-pulse-glow' : 'border-border-subtle bg-surface-2 text-[#00E676]'}`}>
              <Clock className="w-4 h-4" />
              <span className="font-black font-mono tracking-wider text-sm">{formatTime(timeLeft)}</span>
            </div>
          ) : (
            <Badge variant="default">Cheksiz dars</Badge>
          )}
        </div>

        <ProgressBar value={completionPct} className="mt-4" color={isTimeUrgent ? 'red' : 'green'} />
      </Card>

      {/* Main question slide box */}
      <Card variant="glass" className="p-6 border-border-subtle relative space-y-4">
        
        {/* Topic cataloging tag */}
        <div className="flex justify-between items-center bg-surface-2/65 p-2 rounded-xl border border-border-subtle/50">
          <span className="text-xs font-bold text-[#E8F5E9] flex items-center gap-2">
            🧬 MAVZU: <strong className="text-primary-green uppercase font-mono tracking-wide">{currentQ.topic || 'Biologiya'}</strong>
          </span>
          <Badge variant={test.difficulty === 'qiyin' ? 'danger' : test.difficulty === 'o_rta' ? 'warning' : 'success'}>
            {currentQ.difficulty || test.difficulty || 'aralash'}
          </Badge>
        </div>

        {/* Attached Illustration if exists */}
        {currentQ.image_url && (
          <div className="w-full max-h-[180px] rounded-xl overflow-hidden border border-border-active bg-surface-2 flex items-center justify-center p-2">
            <img
              src={currentQ.image_url}
              alt="Biology structure"
              className="max-h-full max-w-full object-contain hover:scale-105 transition-transform duration-350 cursor-zoom-in"
              referrerPolicy="no-referrer"
            />
          </div>
        )}

        {/* Text paragraph */}
        <p className="text-base sm:text-lg font-bold text-white leading-relaxed text-left">
          "{currentQ.question_text || currentQ.question}"
        </p>

        {/* Interactive Option selection buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
          {currentQ.options.map((opt, oIdx) => {
            const isSelected = selectedAnswerIndex === oIdx;
            const isCorrectOption = currentQ.correct_index === oIdx;

            // Compute background and border colorings once student inputs guess
            let choiceStyle = 'border-border-subtle bg-surface-1 hover:border-primary-green';
            if (isAnswered) {
              if (isCorrectOption) {
                choiceStyle = 'border-[#00E676] bg-[#00E676]/10 text-[#00E676] font-bold shadow-[0_0_12px_rgba(0,230,118,0.18)]';
              } else if (isSelected) {
                choiceStyle = 'border-[#FF5252] bg-[#FF5252]/10 text-[#FF5252] font-semibold';
              } else {
                choiceStyle = 'border-border-subtle/30 bg-surface-1 opacity-50';
              }
            }

            return (
              <button
                id={`option_btn_${oIdx}`}
                key={oIdx}
                disabled={isAnswered}
                onClick={() => handleSelectOptionClick(oIdx)}
                className={`w-full p-4 rounded-xl text-xs sm:text-sm text-left border flex items-center gap-3.5 transition-all outline-none text-[#CFD8DC]
                ${choiceStyle} ${!isAnswered ? 'cursor-pointer active:scale-98' : ''}`}
              >
                {/* Visual Circle index alphabet */}
                <span className={`w-6.5 h-6.5 rounded-lg text-[11px] font-black font-mono tracking-tight flex items-center justify-center border
                ${isAnswered && isCorrectOption 
                  ? 'bg-primary-green border-primary-green text-[#020c07]' 
                  : isAnswered && isSelected 
                    ? 'bg-danger-accent border-danger-accent text-[#020c07]' 
                    : 'bg-surface-2 border-border-subtle text-text-secondary'}`}>
                  {['A', 'B', 'C', 'D'][oIdx]}
                </span>
                <span className="flex-grow font-semibold">{opt}</span>
              </button>
            );
          })}
        </div>

      </Card>

      {/* Dynamic Dot matrices navigation tray */}
      <Card variant="glass" className="p-3 border-border-subtle flex flex-wrap gap-2 justify-center items-center">
        {questions.map((q, qIndex) => {
          const isCurrent = qIndex === currentIndex;
          const isQAnswered = answers[q.id] !== undefined;
          
          let dotStyle = 'border-border-subtle/50 text-text-muted';
          if (isCurrent) {
            dotStyle = 'border-primary-green text-primary-green font-bold shadow-[0_0_8px_rgba(0,230,118,0.3)] bg-primary-green/5';
          } else if (isQAnswered) {
            dotStyle = 'bg-primary-green/20 border-primary-green/40 text-primary-green';
          }

          return (
            <button
              id={`quick_jump_${qIndex}`}
              key={qIndex}
              onClick={() => jumpToQuestion(qIndex)}
              className={`w-8.5 h-8.5 rounded-lg border flex items-center justify-center text-xs font-bold font-mono transition-all cursor-pointer hover:border-primary-green
              ${dotStyle}`}
            >
              {qIndex + 1}
            </button>
          );
        })}
      </Card>

      {/* Footer navigation actions links */}
      <footer className="flex items-center justify-between gap-4">
        <Button variant="glass" disabled={currentIndex === 0} onClick={prevQuestion}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        
        {currentIndex < questions.length - 1 ? (
          <Button variant="glass" disabled={!isAnswered} className="px-6" onClick={nextQuestion}>
            Keyingi savol <ArrowRight className="w-4 h-4 ml-1" />
          </Button>
        ) : (
          <Button variant="primary" disabled={!isAnswered} className="flex-grow glow-green font-black" onClick={handleFinishQuizAction}>
            Natijalarni Yakunlash
          </Button>
        )}
      </footer>

    </div>
  );
}

// ✅ DONE: src/components/quiz/QuizEngine.jsx
