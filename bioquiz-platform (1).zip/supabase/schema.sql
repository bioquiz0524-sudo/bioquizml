-- Supabase Schema for BioQuiz Platform

-- Enable UUID extension
create extension if not exists "uuid-ossp";

-- Create Table: groups (must be created before profiles reference)
create table if not exists groups (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  teacher_id uuid, -- will reference profiles later after compile
  center_name text,
  invite_link text unique,
  created_at timestamptz default now()
);

-- Create Table: profiles
create table if not exists profiles (
  id uuid primary key default uuid_generate_v4(),
  telegram_id bigint unique not null,
  full_name text not null,
  username text,
  avatar_url text,
  role text not null check(role in ('student', 'teacher', 'admin')),
  learning_center text,
  teacher_id uuid references profiles(id) on delete set null,
  group_id uuid references groups(id) on delete set null,
  is_pro boolean default false,
  wallet_balance integer default 0,
  created_at timestamptz default now()
);

-- Add foreign key constraint to groups table referencing profiles
alter table groups add constraint fk_groups_teacher foreign key (teacher_id) references profiles(id) on delete set null;

-- Create Table: tests
create table if not exists tests (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  teacher_id uuid references profiles(id) on delete set null,
  center_name text,
  subject text default 'Biologiya',
  grade text,
  topic jsonb, -- array of topics
  difficulty text check(difficulty in ('oson', 'o_rta', 'qiyin', 'aralash')),
  question_count integer default 0,
  time_limit integer, -- in minutes, nullable
  is_premium boolean default false,
  price integer default 0,
  status text default 'draft' check(status in ('draft', 'active', 'archived')),
  session_code text unique,
  invite_link text,
  settings jsonb default '{}'::jsonb,
  created_at timestamptz default now()
);

-- Create Table: questions
create table if not exists questions (
  id uuid primary key default uuid_generate_v4(),
  test_id uuid references tests(id) on delete cascade,
  question_text text not null,
  image_url text,
  options jsonb not null, -- array of strings, exactly 4
  correct_index integer not null check(correct_index >= 0 and correct_index <= 3),
  topic text,
  subject text default 'Biologiya',
  grade text,
  difficulty text,
  order_number integer,
  created_by uuid references profiles(id) on delete set null,
  created_at timestamptz default now()
);

-- Create Table: flashcards
create table if not exists flashcards (
  id uuid primary key default uuid_generate_v4(),
  test_id uuid references tests(id) on delete cascade,
  question_id uuid references questions(id) on delete cascade,
  front_text text not null,
  back_text text not null,
  topic text,
  difficulty text,
  created_at timestamptz default now()
);

-- Create Table: student_flashcard_progress
create table if not exists student_flashcard_progress (
  id uuid primary key default uuid_generate_v4(),
  student_id uuid references profiles(id) on delete cascade,
  flashcard_id uuid references flashcards(id) on delete cascade,
  confidence_level integer default 0 check(confidence_level >= 0 and confidence_level <= 5),
  next_review_date timestamptz default now(),
  review_count integer default 0,
  last_reviewed timestamptz,
  unique(student_id, flashcard_id)
);

-- Create Table: sessions ( Kahoot live style )
create table if not exists sessions (
  id uuid primary key default uuid_generate_v4(),
  code text unique not null,
  test_id uuid references tests(id) on delete cascade,
  teacher_id uuid references profiles(id) on delete set null,
  center_name text,
  status text default 'waiting' check(status in ('waiting', 'active', 'finished', 'cancelled')),
  started_at timestamptz,
  finished_at timestamptz,
  created_at timestamptz default now()
);

-- Create Table: session_participants
create table if not exists session_participants (
  id uuid primary key default uuid_generate_v4(),
  session_id uuid references sessions(id) on delete cascade,
  student_id uuid references profiles(id) on delete cascade,
  score integer default 0,
  total integer default 0,
  percentage integer default 0,
  total_time_spent integer default 0, -- in seconds
  answers jsonb default '[]'::jsonb,
  failed_topics jsonb default '[]'::jsonb,
  joined_at timestamptz default now(),
  completed_at timestamptz
);

-- Create Table: assignments
create table if not exists assignments (
  id uuid primary key default uuid_generate_v4(),
  teacher_id uuid references profiles(id) on delete set null,
  test_id uuid references tests(id) on delete cascade,
  title text,
  assigned_to jsonb, -- student ids or group ids
  due_date timestamptz,
  status text default 'active',
  created_at timestamptz default now()
);

-- Create Table: exam_results
create table if not exists exam_results (
  id uuid primary key default uuid_generate_v4(),
  student_id uuid references profiles(id) on delete cascade ,
  test_id uuid references tests(id) on delete cascade,
  session_id uuid references sessions(id) on delete set null,
  center_name text,
  score integer default 0,
  total integer default 0,
  percentage integer default 0,
  total_time_spent integer default 0,
  answers jsonb default '[]'::jsonb,
  failed_topics jsonb default '[]'::jsonb,
  completed_at timestamptz default now()
);

-- Create Table: purchases
create table if not exists purchases (
  id uuid primary key default uuid_generate_v4(),
  student_id uuid references profiles(id) on delete cascade,
  test_id uuid references tests(id) on delete cascade,
  amount integer not null,
  status text default 'success',
  created_at timestamptz default now()
);

-- ==========================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ==========================================

alter table profiles enable row level security;
alter table groups enable row level security;
alter table tests enable row level security;
alter table questions enable row level security;
alter table flashcards enable row level security;
alter table student_flashcard_progress enable row level security;
alter table sessions enable row level security;
alter table session_participants enable row level security;
alter table assignments enable row level security;
alter table exam_results enable row level security;
alter table purchases enable row level security;

-- Profiles Policies
create policy "Allow insert for onboarding" on profiles for insert with check (true);
create policy "Users see own profile" on profiles for select using (true);
create policy "Users update own profile" on profiles for update using (true);
create policy "Admin manages profiles" on profiles for all using (
  exists (select 1 from profiles where id = auth.uid() and role = 'admin')
);

-- Groups Policies
create policy "Anyone can select groups" on groups for select using (true);
create policy "Teachers manage own groups" on groups for all using (true);

-- Tests Policies
create policy "Anyone can select tests" on tests for select using (true);
create policy "Teachers manage own tests" on tests for all using (true);

-- Questions Policies
create policy "Anyone can see questions" on questions for select using (true);
create policy "Teachers manage questions" on questions for all using (true);

-- Flashcards Policies
create policy "Anyone can select flashcards" on flashcards for select using (true);
create policy "Flashcard management" on flashcards for all using (true);

-- Progress Policies
create policy "Students manage own progress" on student_flashcard_progress for all using (true);

-- Sessions Policies
create policy "Anyone can see sessions" on sessions for select using (true);
create policy "Session management" on sessions for all using (true);

-- Session Participants Policies
create policy "Anyone can participate" on session_participants for all using (true);

-- Assignments Policies
create policy "Select assignments" on assignments for select using (true);
create policy "Teacher management assignments" on assignments for all using (true);

-- Exam Results Policies
create policy "View exam results" on exam_results for select using (true);
create policy "Insert exam results" on exam_results for insert with check (true);
create policy "Admin exam results" on exam_results for all using (true);

-- Purchases Policies
create policy "Student view own purchases" on purchases for select using (true);
create policy "Insert purchase" on purchases for insert with check (true);
create policy "Admin view purchases" on purchases for all using (true);
