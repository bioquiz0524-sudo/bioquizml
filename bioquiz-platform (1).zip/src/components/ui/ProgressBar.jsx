// ✅ Custom animated Progress Bar
import React from 'react';

export default function ProgressBar({
  id = `progress_${Math.random().toString(36).substr(2, 9)}`,
  value = 0, // 0 to 100
  showText = false,
  color = 'green', // 'green' | 'blue' | 'yellow' | 'red'
  className = ''
}) {
  const percentage = Math.max(0, Math.min(100, Math.round(value)));

  const colorStyles = {
    green: 'bg-primary-green shadow-[0_0_8px_rgba(0,230,118,0.3)]',
    blue: 'bg-blue-accent shadow-[0_0_8px_rgba(0,188,212,0.3)]',
    yellow: 'bg-warning-accent shadow-[0_0_8px_rgba(255,214,0,0.3)]',
    red: 'bg-danger-accent shadow-[0_0_8px_rgba(255,82,82,0.3)]'
  };

  return (
    <div id={id} className={`w-full ${className}`}>
      {showText && (
        <div id={`${id}_header`} className="flex justify-between items-center mb-1.5 text-xs font-semibold text-text-secondary">
          <span>Tugallanish holati</span>
          <span className="font-mono text-white">{percentage}%</span>
        </div>
      )}
      
      {/* Background track bar */}
      <div id={`${id}_track`} className="w-full h-2.5 rounded-full bg-surface-2 overflow-hidden border border-border-subtle/50">
        <div
          id={`${id}_thumb`}
          style={{ width: `${percentage}%` }}
          className={`h-full rounded-full transition-all duration-300 ease-out ${colorStyles[color]}`}
        />
      </div>
    </div>
  );
}

// ✅ DONE: src/components/ui/ProgressBar.jsx
