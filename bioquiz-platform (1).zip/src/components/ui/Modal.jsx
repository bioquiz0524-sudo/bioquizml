// ✅ Slide-up Glass-overlay Bottom Sheet Modal
import React, { useEffect } from 'react';
import { X } from 'lucide-react';
import { triggerHaptic } from '../../lib/telegramAuth';

export default function Modal({
  id = `modal_${Math.random().toString(36).substr(2, 9)}`,
  isOpen,
  onClose,
  title,
  children,
  className = ''
}) {
  // Prevent page scroll when modal is active
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      triggerHaptic('light');
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div id={id} className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
      {/* Background shadow overlay */}
      <div
        id={`${id}_overlay`}
        onClick={onClose}
        className="absolute inset-0 bg-[#020c07]/80 backdrop-blur-md transition-opacity duration-305 ease-out"
      />

      {/* Modal drawer structure */}
      <div
        id={`${id}_drawer`}
        className={`relative w-full max-w-lg glass-panel text-text-primary rounded-t-3xl sm:rounded-2xl shadow-2xl p-6 sm:p-7 z-10 
        transform transition-all duration-300 ease-out translate-y-0 max-h-[90vh] overflow-y-auto no-scrollbar ${className}`}
      >
        {/* Mobile slide drawer indicator bar */}
        <div id={`${id}_drag_indicator`} className="w-12 h-1 bg-border-subtle rounded-full mx-auto mb-4 sm:hidden" />

        {/* Modal Header */}
        <div id={`${id}_header`} className="flex items-center justify-between mb-5">
          <h3 id={`${id}_title`} className="text-xl font-bold tracking-tight text-white">{title}</h3>
          <button
            id={`${id}_close`}
            onClick={onClose}
            className="p-1.5 rounded-lg bg-surface-2 hover:bg-card-hover border border-border-subtle hover:border-primary-green/50 text-text-secondary hover:text-white transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body Content */}
        <div id={`${id}_content`} className="w-full text-text-secondary text-sm leading-relaxed">
          {children}
        </div>
      </div>
    </div>
  );
}

// ✅ DONE: src/components/ui/Modal.jsx
