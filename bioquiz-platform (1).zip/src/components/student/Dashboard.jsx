// ✅ Student Core Dashboard Engine with Live Session entry and Test Catalog
import React, { useState, useEffect } from 'react';
import { useAuthStore } from '../../store/useAuthStore';
import { useQuizStore } from '../../store/useQuizStore';
import { useAppStore } from '../../store/useAppStore';
import { supabase } from '../../lib/supabaseClient';
import { triggerHaptic } from '../../lib/telegramAuth';
import Button from '../ui/Button';
import Card from '../ui/Card';
import Badge from '../ui/Badge';
import Input from '../ui/Input';
import ProgressBar from '../ui/ProgressBar';
import { 
  Play, 
  Key, 
  Award, 
  Clock, 
  Coins, 
  Flame, 
  BookOpen, 
  AlertCircle, 
  ShoppingBag, 
  CheckCircle,
  Star,
  Sparkles,
  Check
} from 'lucide-react';

export default function StudentDashboard({ onSelectSessionCode, onSelectQuiz }) {
  const { profile, addCredits, updateProfile } = useAuthStore();
  const { startQuiz } = useQuizStore();
  const { showToast, openModal } = useAppStore();

  const [sessionPin, setSessionPin] = useState('');
  const [tests, setTests] = useState([]);
  const [assignments, setAssignments] = useState([]);
  const [purchases, setPurchases] = useState([]);
  const [history, setHistory] = useState([]);
  
  const [buyingTestId, setBuyingTestId] = useState(null);

  // Sync test materials and user context
  useEffect(() => {
    loadData();
  }, [profile?.id]);

  const loadData = async () => {
    try {
      // 1. Get tests
      const { data: testData } = await supabase.from('tests').select('*').eq('status', 'active');
      if (testData) setTests(testData);

      // 2. Get student purchases
      if (profile?.id) {
        const { data: purchaseData } = await supabase.from('purchases').select('*').eq('student_id', profile.id);
        if (purchaseData) setPurchases(purchaseData.map(p => p.test_id));

        // 3. Get student assignments
        const { data: assignData } = await supabase.from('assignments').select('*');
        if (assignData) {
          // Filter assignments assigned to student's group
          const studentAss = assignData.filter(a => {
            const dests = Array.isArray(a.assigned_to) ? a.assigned_to : [];
            return dests.includes(profile.group_id) || dests.includes('all') || dests.includes(profile.id);
          });
          setAssignments(studentAss);
        }

        // 4. Get student previous trials history
        const { data: histData } = await supabase
          .from('exam_results')
          .select('*')
          .eq('student_id', profile.id)
          .order('completed_at', { ascending: false });
        if (histData) setHistory(histData);
      }
    } catch (e) {
      console.error("Data load exception on dashboard", e);
    }
  };

  // Join Kahoot multiplayer live session
  const handleJoinLive = async () => {
    if (!sessionPin.trim()) {
      showToast("Iltimos, dars PIN kodini kiriting!", "warning");
      return;
    }
    
    const formattedPin = sessionPin.trim().toUpperCase();
    triggerHaptic('light');

    try {
      showToast("Sessiya tekshirilmoqda...", "info");
      
      const { data: liveSession } = await supabase
        .from('sessions')
        .select('*')
        .eq('code', formattedPin)
        .single();

      if (!liveSession) {
        showToast("Jonli sessiya topilmadi! Kodni tekshiring.", "error");
        return;
      }

      if (liveSession.status === 'finished') {
        showToast("Bu koxut darsi yakunlangan!", "warning");
        return;
      }

      // Add student to session participants list
      await supabase.from('session_participants').upsert({
        session_id: liveSession.id,
        student_id: profile.id,
        score: 0,
        total: 10
      });

      // Navigate outer router to active live session waits page
      if (onSelectSessionCode) {
        onSelectSessionCode(formattedPin, liveSession);
      }
    } catch (err) {
      showToast("Ulanishda muammo yuz berdi.", "error");
    }
  };

  // Buy Premium biology challenges
  const handlePurchaseTest = async (test) => {
    setBuyingTestId(test.id);
    triggerHaptic('light');

    try {
      const balance = profile?.wallet_balance || 0;
      if (balance < test.price) {
        showToast("Balans yetarli emas! Iltimos, hisobni to'ldiring.", "error");
        openModal('refill_balance_modal');
        return;
      }

      // Deduct balance and create purchase ticket
      const newBal = balance - test.price;
      await updateProfile({ wallet_balance: newBal });

      await supabase.from('purchases').insert({
        student_id: profile.id,
        test_id: test.id,
        amount: test.price,
        status: 'success'
      });

      showToast(`"${test.title}" imtihoni muvaffaqiyatli sotib olindi!`, "success");
      setPurchases([...purchases, test.id]);
    } catch (err) {
      showToast("Xarid amalga oshmadi.", "error");
    } finally {
      setBuyingTestId(null);
    }
  };

  // Start single solo testing
  const handleStartPracticeTest = async (test) => {
    triggerHaptic('success');
    
    try {
      // Load questions for this test
      const { data: questions } = await supabase
        .from('questions')
        .select('*')
        .eq('test_id', test.id)
        .order('order_number', { ascending: true });

      if (!questions || questions.length === 0) {
        showToast("Ushbu testda hali savollar yo'q!", "warning");
        return;
      }

      if (onSelectQuiz) {
        onSelectQuiz(test, questions);
      }
    } catch (err) {
      showToast("Testni yuklashda xatolik.", "error");
    }
  };

  return (
    <div id="student_dashboard_scroll" className="w-full space-y-6 animate-fade-in pb-[90px]">
      
      {/* 1. Header Profile Box */}
      <Card variant="glass" className="relative p-5 border-primary-green/20">
        <div className="flex items-center justify-between">
          <div className="text-left space-y-1">
            <p className="text-xs font-mono text-text-secondary tracking-wide uppercase">XUSH KELIBSIZ</p>
            <h2 className="text-xl font-extrabold text-white">{profile?.full_name}</h2>
            <div className="flex items-center gap-2 text-xs font-semibold text-text-secondary">
              <span className="bg-surface-2 px-2.5 py-1 rounded-md border border-border-subtle">{profile?.learning_center || 'Markazsiz'}</span>
              {profile?.is_pro && <Badge variant="pro">PRO TALABA</Badge>}
            </div>
          </div>

          {/* Wallet Balance widget card */}
          <div
            id="student_wallet"
            onClick={() => openModal('refill_balance_modal')}
            className="flex items-center gap-2 bg-surface-2 hover:bg-card-hover border border-border-subtle hover:border-primary-green px-3.5 py-2.5 rounded-xl transition-all cursor-pointer select-none active:scale-95"
          >
            <Coins className="w-5 h-5 text-primary-green animate-bounce" />
            <div className="text-right">
              <p className="text-[9px] font-bold text-text-secondary uppercase">HAMYON</p>
              <p className="text-sm font-black font-mono text-white">{profile?.wallet_balance?.toLocaleString() || 0} UZS</p>
            </div>
          </div>
        </div>

        {/* PRO dynamic upsell row */}
        {!profile?.is_pro ? (
          <div className="mt-5 pt-5 border-t border-border-subtle/50 space-y-4">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
              <span className="text-sm font-extrabold text-[#FFF176] tracking-tight">PRO statusga o'ting va barcha imkoniyatlarni oching!</span>
            </div>
            
            <div className="grid grid-cols-1 xs:grid-cols-2 gap-2 text-[11px] text-text-secondary leading-normal">
              <div className="flex items-center gap-1.5">
                <span className="p-0.5 rounded-full bg-primary-green/20 text-primary-green flex items-center justify-center"><Check className="w-3 h-3" /></span>
                <span>Cheksiz interval takrorlash flashcardlari (SRS)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="p-0.5 rounded-full bg-primary-green/20 text-primary-green flex items-center justify-center"><Check className="w-3 h-3" /></span>
                <span>Natijalarni AI orqali chuqur tahlil qilish</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="p-0.5 rounded-full bg-primary-green/20 text-primary-green flex items-center justify-center"><Check className="w-3 h-3" /></span>
                <span>O'quv markazidagi pullik testlar mutlaqo bepul</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="p-0.5 rounded-full bg-primary-green/20 text-primary-green flex items-center justify-center"><Check className="w-3 h-3" /></span>
                <span>Sun'iy intellekt (OCR) yechgichlaridan foydalanish</span>
              </div>
            </div>

            <div className="bg-surface-2 p-3.5 rounded-xl border border-border-subtle/70 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <span className="block text-[10px] uppercase font-bold text-text-muted">BIR MARTALIK TO'LOV (LIFETIME)</span>
                <span className="block text-lg font-black font-mono text-white text-glow">50,000 UZS <span className="text-xs font-normal text-text-secondary">/ umrbod</span></span>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <Button 
                  variant="primary" 
                  size="sm" 
                  className="bg-amber-400 hover:bg-amber-500 text-bg border-amber-400 hover:border-amber-500 font-extrabold flex-1 sm:flex-initial flex items-center justify-center gap-1"
                  onClick={() => openModal('upgrade_modal')}
                >
                  <Star className="w-3.5 h-3.5 fill-current" /> SOTIB OLISH
                </Button>
              </div>
            </div>
          </div>
        ) : (
          <div className="mt-5 pt-5 border-t border-border-subtle/50">
            <div className="bg-[#1b5e20]/15 border border-[#4caf50]/20 rounded-xl p-3 flex items-center justify-between gap-3 text-xs leading-relaxed text-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-amber-400/10 text-amber-400 border border-amber-400/20 flex items-center justify-center font-bold">
                  ★
                </div>
                <div>
                  <h5 className="font-bold text-amber-400">PRO Tarifi Faol!</h5>
                  <p className="text-[10px] text-text-secondary">Cheksiz biologiya testlari, SRS va tahlillar ochiq.</p>
                </div>
              </div>
              <Badge variant="pro">VIP CHIP</Badge>
            </div>
          </div>
        )}
      </Card>

      {/* 2. KAHOOT-STYLE Live code form */}
      <Card variant="glass" className="p-5 border-primary-green/20">
        <div className="flex items-center gap-3 mb-4.5">
          <div className="p-2.5 rounded-lg bg-primary-green/10 text-primary-green">
            <Key className="w-5 h-5" />
          </div>
          <div className="text-left">
            <h3 className="font-extrabold text-white text-sm">Jonli darslik koxut o'yini</h3>
            <p className="text-xs text-text-secondary">O'qituvchingiz bergan sessiya kodi bilan jonli bellashuvga kiring</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <input
            id="session_pin_input"
            type="text"
            placeholder="KOD: BIO-XXXX"
            value={sessionPin}
            onChange={(e) => setSessionPin(e.target.value)}
            className="flex-grow uppercase bg-surface-1 font-mono tracking-widest text-[#00E676] text-center text-lg font-black border border-border-subtle focus:border-primary-green px-4 py-3 rounded-xl outline-none"
          />
          <Button variant="primary" size="lg" className="min-w-[110px]" onClick={handleJoinLive}>
            Kirish
          </Button>
        </div>
      </Card>

      {/* 3. ASSIGNMENTS container if exists */}
      {assignments.length > 0 && (
        <div className="space-y-3.5">
          <h4 className="text-xs font-black tracking-wider uppercase text-text-secondary text-left">Vazifalar (Ustoz tarafdan)</h4>
          <div className="grid grid-cols-1 gap-3">
            {assignments.map((as) => {
              const linkedTest = tests.find(t => t.id === as.test_id);
              if (!linkedTest) return null;

              return (
                <Card key={as.id} variant="interactive" className="p-4 border-r-4 border-r-primary-green" onClick={() => handleStartPracticeTest(linkedTest)}>
                  <div className="flex justify-between items-start">
                    <div className="text-left space-y-1">
                      <p className="text-[10px] font-mono font-bold uppercase text-primary-green">MUDDAT: {new Date(as.due_date).toLocaleDateString()}</p>
                      <h4 className="font-bold text-white text-sm">{as.title || linkedTest.title}</h4>
                      <p className="text-xs text-text-secondary flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-text-muted" /> {linkedTest.time_limit || 20} daqiqa · {linkedTest.question_count || 10} ta savol
                      </p>
                    </div>
                    <Button variant="scale" className="bg-primary-green/10 text-primary-green hover:bg-primary-green p-2 rounded-xl transition-all h-10 w-10">
                      <Play className="w-5 h-5 fill-current" />
                    </Button>
                  </div>
                </Card>
              );
            })}
          </div>
        </div>
      )}

      {/* 4. TESTS LIBRARY CATALOG */}
      <div className="space-y-3.5">
        <h4 className="text-xs font-black tracking-wider uppercase text-text-secondary text-left">Imtihonlar kitobi</h4>
        {tests.length === 0 ? (
          <div className="text-center py-6 border border-dashed border-border-subtle rounded-2xl bg-surface-1/40">
            <BookOpen className="w-8 h-8 text-text-muted mx-auto mb-2" />
            <p className="text-xs text-text-secondary">Hali hech qanday test yaratilmagan.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            {tests.map((test) => {
              const isPremium = test.is_premium;
              const hasBought = purchases.includes(test.id) || profile?.is_pro;
              
              return (
                <Card key={test.id} variant="glass" className="p-4 relative border-border-subtle">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="text-left space-y-1">
                      <div className="flex items-center gap-2">
                        <h4 className="font-extrabold text-white text-base">{test.title}</h4>
                        {isPremium ? (
                          <Badge variant="pro">PREMIUM</Badge>
                        ) : (
                          <Badge variant="success">BEPUL</Badge>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-3.5 text-xs text-text-secondary">
                        <span className="flex items-center gap-1.5"><Clock className="w-3.5 h-3.5" /> {test.time_limit || 'Cheksiz'} daqiqa</span>
                        <span className="flex items-center gap-1.5"><Award className="w-3.5 h-3.5" /> Sinfi: {test.grade || 'Hamma'}</span>
                        <span className="bg-surface-2 px-1.5 py-0.5 rounded text-[10px] font-bold text-text-secondary uppercase">{test.difficulty || 'aralash'}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      {isPremium && !hasBought ? (
                        <Button
                          variant="secondary"
                          className="w-full sm:w-auto flex items-center gap-2"
                          isLoading={buyingTestId === test.id}
                          onClick={() => handlePurchaseTest(test)}
                        >
                          <ShoppingBag className="w-4 h-4" /> {test.price?.toLocaleString()} UZS
                        </Button>
                      ) : (
                        <Button
                          variant="primary"
                          className="w-full sm:w-auto px-6"
                          onClick={() => handleStartPracticeTest(test)}
                        >
                          Boshlash
                        </Button>
                      )}
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* 5. HISTORY SUB-LOGS */}
      {history.length > 0 && (
        <div className="space-y-3.5">
          <h4 className="text-xs font-black tracking-wider uppercase text-text-secondary text-left">Topshirilgan testlar tarixi</h4>
          <div className="space-y-3">
            {history.slice(0, 5).map((h) => {
              const matchedTest = tests.find(t => t.id === h.test_id);
              return (
                <Card key={h.id} variant="glass" className="p-4 border-border-subtle flex items-center justify-between">
                  <div className="text-left space-y-1">
                    <h5 className="font-bold text-white text-sm">{matchedTest?.title || 'Biologiya Testi'}</h5>
                    <p className="text-[10px] text-text-secondary font-mono">{new Date(h.completed_at).toLocaleDateString()} · {Math.round(h.total_time_spent / 60)} daqiqa</p>
                  </div>

                  <div className="flex items-center gap-3 text-right">
                    <div className="space-y-0.5">
                      <p className="text-sm font-black text-primary-green font-mono">{h.score} / {h.total}</p>
                      <p className="text-xs text-text-secondary font-mono">{h.percentage}% natija</p>
                    </div>
                    {h.percentage >= 85 ? (
                      <CheckCircle className="w-5 h-5 text-primary-green" />
                    ) : (
                      <AlertCircle className="w-5 h-5 text-warning-accent" />
                    )}
                  </div>
                </Card>
              );
            })}
          </div>
        </div>
      )}

    </div>
  );
}

// ✅ DONE: src/components/student/Dashboard.jsx
