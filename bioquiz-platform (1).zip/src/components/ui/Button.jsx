// ✅ Custom Button Component with Press Scales and Glowing Boarders
import React from 'react';

export default function Button({
  id = `btn_${Math.random().toString(36).substr(2, 9)}`,
  children,
  onClick,
  variant = 'primary', // 'primary' | 'secondary' | 'danger' | 'glass' | 'ghost'
  size = 'md', // 'sm' | 'md' | 'lg'
  className = '',
  disabled = false,
  isLoading = false,
  icon = null,
  type = 'button'
}) {
  // Styles mapping matching primary green palette
  const baseStyles = 'inline-flex items-center justify-center font-semibold rounded-xl transition-all duration-250 ease-out active:scale-97 cursor-pointer select-none disabled:opacity-40 disabled:cursor-not-allowed disabled:active:scale-100';
  
  const variantStyles = {
    primary: 'bg-primary-green hover:bg-primary-dark text-[#020c07] shadow-[0_0_12px_rgba(0,230,118,0.25)] hover:shadow-[0_0_18px_rgba(0,230,118,0.4)]',
    secondary: 'border border-primary-green/40 hover:border-primary-green text-primary-green hover:bg-primary-green/10 shadow-[0_0_8px_rgba(0,230,118,0.08)]',
    danger: 'bg-danger-accent hover:bg-red-600 text-[#020c07] shadow-lg shadow-red-950/20',
    glass: 'glass-panel text-secondary-green hover:bg-surface-2',
    ghost: 'text-text-secondary hover:text-primary-green bg-transparent'
  };

  const sizeStyles = {
    sm: 'text-xs px-3 py-1.5 gap-1.5',
    md: 'text-sm px-5 py-3 h-[48px] gap-2', // Min target 48px
    lg: 'text-base px-7 py-3.5 h-[54px] gap-2.5'
  };

  return (
    <button
      id={id}
      type={type}
      onClick={onClick}
      disabled={disabled || isLoading}
      className={`${baseStyles} ${variantStyles[variant]} ${sizeStyles[size]} ${className}`}
    >
      {isLoading && (
        <svg id={`${id}_loader`} className="animate-spin -ml-1 mr-2 h-4 w-4 text-current" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
      )}
      {!isLoading && icon && <span className="flex-shrink-0">{icon}</span>}
      <span>{children}</span>
    </button>
  );
}

// ✅ DONE: src/components/ui/Button.jsx
