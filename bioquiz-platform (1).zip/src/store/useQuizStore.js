// ✅ Zustand Quiz Store with Realtime Timer and Analytics Compilation
import { create } from 'zustand';
import { supabase } from '../lib/supabaseClient';
import { triggerHaptic } from '../lib/telegramAuth';

export const useQuizStore = create((set, get) => ({
  questions: [],
  currentIndex: 0,
  answers: {}, // map of { questionId: selectedIndex }
  timeLeft: 0, // dynamic in seconds
  sessionCode: null,
  mode: 'solo', // 'solo' | 'live'
  testId: null,
  isEnded: false,
  timerInterval: null,

  startQuiz: (questionsList, timeLimitMinutes, code = null, mode = 'solo', testId = null) => {
    // Clear any previous running timer
    if (get().timerInterval) {
      clearInterval(get().timerInterval);
    }

    const seconds = timeLimitMinutes ? timeLimitMinutes * 60 : 0;

    set({
      questions: questionsList || [],
      currentIndex: 0,
      answers: {},
      timeLeft: seconds,
      sessionCode: code,
      mode: mode,
      testId: testId,
      isEnded: false
    });

    triggerHaptic('light');

    // Start timer count down if limit existed
    if (seconds > 0) {
      const interval = setInterval(() => {
        const currentLeft = get().timeLeft;
        if (currentLeft <= 1) {
          clearInterval(interval);
          set({ timeLeft: 0, isEnded: true });
          get().finishQuiz();
        } else {
          set({ timeLeft: currentLeft - 1 });
        }
      }, 1000);

      set({ timerInterval: interval });
    }
  },

  selectAnswer: (questionId, optionIndex) => {
    const currentAnswers = { ...get().answers };
    
    // Once answered, cannot override selection
    if (currentAnswers[questionId] !== undefined) return;

    currentAnswers[questionId] = optionIndex;
    set({ answers: currentAnswers });

    // Validate ifcorrect
    const currentQ = get().questions.find(q => q.id === questionId);
    if (currentQ) {
      if (currentQ.correct_index === optionIndex) {
        triggerHaptic('success');
      } else {
        triggerHaptic('error');
      }
    }
  },

  nextQuestion: () => {
    const nextIdx = get().currentIndex + 1;
    if (nextIdx < get().questions.length) {
      set({ currentIndex: nextIdx });
      triggerHaptic('light');
    } else {
      get().finishQuiz();
    }
  },

  prevQuestion: () => {
    const prevIdx = get().currentIndex - 1;
    if (prevIdx >= 0) {
      set({ currentIndex: prevIdx });
      triggerHaptic('light');
    }
  },

  jumpToQuestion: (index) => {
    if (index >= 0 && index < get().questions.length) {
      set({ currentIndex: index });
      triggerHaptic('light');
    }
  },

  finishQuiz: async (userId = null, centerName = '') => {
    if (get().timerInterval) {
      clearInterval(get().timerInterval);
    }

    set({ isEnded: true });

    const { questions, answers, timeLeft, testId, sessionCode, mode } = get();
    let score = 0;
    const failedTopicsMap = new Set();
    const formattedAnswers = [];

    questions.forEach((q) => {
      const selected = answers[q.id];
      const isCorrect = selected === q.correct_index;
      if (isCorrect) {
        score++;
      } else {
        if (q.topic) failedTopicsMap.add(q.topic);
      }

      formattedAnswers.push({
        question_id: q.id,
        question_text: q.question_text || q.text,
        selected_index: selected !== undefined ? selected : null,
        correct_index: q.correct_index,
        is_correct: isCorrect,
        topic: q.topic || 'Biologiya'
      });
    });

    const total = questions.length;
    const pct = total > 0 ? Math.round((score / total) * 100) : 0;
    const failedTopicsList = Array.from(failedTopicsMap);

    // Calculate total time spent
    const totalTimeAllocated = questions.length * 30; // standard mock or fallback limits
    const timeSpent = timeLeft > 0 ? Math.ceil(totalTimeAllocated - timeLeft) : totalTimeAllocated;

    const resultRecord = {
      student_id: userId,
      test_id: testId,
      center_name: centerName || 'BioQuiz Academy',
      score: score,
      total: total,
      percentage: pct,
      total_time_spent: Math.max(10, timeSpent), // limit minimum seconds to avoid zeros
      answers: formattedAnswers,
      failed_topics: failedTopicsList,
      completed_at: new Date().toISOString()
    };

    try {
      // Save results in db if user id exists
      if (userId) {
        // Save to regular exam results
        await supabase.from('exam_results').insert(resultRecord);

        // If wrong answers exist, auto populate student's Spaced Repetition flashcards list!
        const wrongQs = formattedAnswers.filter(fa => !fa.is_correct);
        if (wrongQs.length > 0) {
          // Check if flashcards already exist for these question IDs
          for (const wq of wrongQs) {
            const { data: fc } = await supabase
              .from('flashcards')
              .select('id, front_text, back_text')
              .eq('question_id', wq.question_id)
              .single();

            let targetFcId = fc?.id;

            // If a flashcard doesn't exist for this question yet, create one!
            if (!fc) {
              const matchingQ = questions.find(q => q.id === wq.question_id);
              if (matchingQ) {
                const { data: newFc } = await supabase
                  .from('flashcards')
                  .insert({
                    test_id: testId,
                    question_id: wq.question_id,
                    front_text: matchingQ.question_text || matchingQ.text,
                    back_text: matchingQ.options[matchingQ.correct_index],
                    topic: matchingQ.topic,
                    difficulty: matchingQ.difficulty
                  })
                  .select()
                  .single();
                
                targetFcId = newFc?.id;
              }
            }

            // Bind current student to the flashcard progression queue!
            if (targetFcId) {
              await supabase.from('student_flashcard_progress').upsert({
                student_id: userId,
                flashcard_id: targetFcId,
                confidence_level: 0,
                next_review_date: new Date().toISOString(),
                review_count: 0
              });
            }
          }
        }
      }
    } catch (e) {
      console.error("Quiz results persistence failed, fallback to local state only:", e);
    }

    triggerHaptic('success');
    return resultRecord;
  },

  resetQuiz: () => {
    if (get().timerInterval) {
      clearInterval(get().timerInterval);
    }
    set({
      questions: [],
      currentIndex: 0,
      answers: {},
      timeLeft: 0,
      sessionCode: null,
      mode: 'solo',
      testId: null,
      isEnded: false,
      timerInterval: null
    });
  }
}));

// ✅ DONE: src/store/useQuizStore.js
