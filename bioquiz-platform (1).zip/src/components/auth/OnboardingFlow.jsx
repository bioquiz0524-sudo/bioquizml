// ✅ Complete Multi-step Interactive Profile Onboarding with Autocompletes
import React, { useState, useEffect } from 'react';
import { useAuthStore } from '../../store/useAuthStore';
import { useAppStore } from '../../store/useAppStore';
import { supabase } from '../../lib/supabaseClient';
import { triggerHaptic } from '../../lib/telegramAuth';
import Button from '../ui/Button';
import Card from '../ui/Card';
import Input from '../ui/Input';
import { User, GraduationCap, Building2, UserCheck, Users, Sparkles, Check } from 'lucide-react';

export default function OnboardingFlow() {
  const { profile, updateProfile } = useAuthStore();
  const { showToast } = useAppStore();

  const [step, setStep] = useState(1);
  const [role, setRole] = useState('student'); // 'student' | 'teacher'
  const [learningCenter, setLearningCenter] = useState('');
  const [centerSuggestions, setCenterSuggestions] = useState([]);
  
  const [teachers, setTeachers] = useState([]);
  const [selectedTeacherId, setSelectedTeacherId] = useState('');
  
  const [groups, setGroups] = useState([]);
  const [selectedGroupId, setSelectedGroupId] = useState('');

  const [submitting, setSubmitting] = useState(false);

  // Dynamic Center Autocomplete Query
  useEffect(() => {
    if (step === 2 && learningCenter.trim().length > 0) {
      const getCenters = async () => {
        try {
          const { data } = await supabase
            .from('profiles')
            .select('learning_center')
            .eq('role', 'teacher')
            .ilike('learning_center', `%${learningCenter}%`)
            .limit(10);
            
          if (data) {
            // Uniquify center strings
            const list = Array.from(new Set(data.map(d => d.learning_center).filter(Boolean)));
            setCenterSuggestions(list);
          }
        } catch (e) {
          console.error("Suggestions fetch error", e);
        }
      };
      getCenters();
    } else {
      setCenterSuggestions([]);
    }
  }, [learningCenter, step]);

  // Load teachers for the selected center
  useEffect(() => {
    if (step === 3 && learningCenter) {
      const loadTeachers = async () => {
        try {
          const { data } = await supabase
            .from('profiles')
            .select('*')
            .eq('role', 'teacher')
            .eq('learning_center', learningCenter);
          if (data) {
            setTeachers(data);
            if (data.length > 0) setSelectedTeacherId(data[0].id);
          }
        } catch (e) {
          console.error("Error fetching teachers", e);
        }
      };
      loadTeachers();
    }
  }, [learningCenter, step]);

  // Load groups for the selected teacher
  useEffect(() => {
    if (step === 4 && selectedTeacherId) {
      const loadGroups = async () => {
        try {
          const { data } = await supabase
            .from('groups')
            .select('*')
            .eq('teacher_id', selectedTeacherId);
          if (data) {
            setGroups(data);
            if (data.length > 0) setSelectedGroupId(data[0].id);
          }
        } catch (e) {
          console.error("Error loaded groups", e);
        }
      };
      loadGroups();
    }
  }, [selectedTeacherId, step]);

  const handleNext = () => {
    triggerHaptic('light');

    if (step === 2 && !learningCenter.trim()) {
      showToast("Iltimos, o'quv markazining nomini kiriting!", "warning");
      return;
    }
    if (step === 3 && role === 'student' && !selectedTeacherId) {
      showToast("Iltimos, o'qituvchini tanlang!", "warning");
      return;
    }
    if (step === 4 && role === 'student' && groups.length > 0 && !selectedGroupId) {
      showToast("Iltimos, dars guruhingizni tanlang!", "warning");
      return;
    }

    // Teachers jump step 3 directly to 5 (no groups/teachers selection needed for themselves!)
    if (role === 'teacher' && step === 2) {
      setStep(5);
    } else {
      setStep(step + 1);
    }
  };

  const handleBack = () => {
    triggerHaptic('light');
    
    if (role === 'teacher' && step === 5) {
      setStep(2);
    } else {
      setStep(step - 1);
    }
  };

  const handleConfirmOnboarding = async () => {
    setSubmitting(true);
    triggerHaptic('success');

    try {
      const updates = {
        role: role,
        learning_center: learningCenter.trim(),
        teacher_id: role === 'student' ? (selectedTeacherId || null) : null,
        group_id: role === 'student' ? (selectedGroupId || null) : null
      };

      await updateProfile(updates);
      showToast("Profil muvaffaqiyatli drayverlandi! Xush kelibsiz.", "success");
    } catch (err) {
      showToast("Xatolik yuz berdi. Qayta urinib ko'ring.", "error");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div id="onboarding_frame" className="min-h-screen bg-bg flex flex-col justify-between py-8 px-4 max-w-md mx-auto">
      {/* Banner */}
      <header id="onboarding_banner" className="text-center pt-4">
        <div className="w-16 h-16 rounded-3xl bg-surface-1 border border-primary-green flex items-center justify-center mx-auto mb-3 shadow-[0_0_20px_rgba(0,230,118,0.2)] animate-pulse-glow">
          <Sparkles className="w-8 h-8 text-primary-green" />
        </div>
        <h1 className="text-2xl font-black tracking-tight text-white uppercase text-glow">BIOQUIZ PLATFORMA</h1>
        <p className="text-xs font-semibold text-text-secondary mt-1">Sizga moslashtirilgan biologiya olami</p>
      </header>

      {/* Main card box step views */}
      <main className="my-8 flex-grow flex flex-col justify-center">
        <Card variant="glass" className="p-6 relative overflow-visible border-primary-green/20">
          
          {/* Step Indicator bar */}
          <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 flex gap-1.5 bg-surface-2 border border-border-subtle rounded-full px-3 py-1">
            {[1, 2, 3, 4, 5].map((s) => {
              if (role === 'teacher' && (s === 3 || s === 4)) return null;
              return (
                <div
                  key={s}
                  className={`h-2 rounded-full transition-all duration-300 ${s === step ? 'w-6 bg-primary-green' : 'w-2 bg-text-muted/40'}`}
                />
              );
            })}
          </div>

          {/* STEP 1: Role Selector */}
          {step === 1 && (
            <div className="animate-fade-in">
              <h2 className="text-lg font-extrabold text-white mb-2 text-center">Platformadagi rolingizni tanlang</h2>
              <p className="text-xs text-text-secondary text-center mb-6">Sizga eng mos keladigan moslashuv qutisini tanlang</p>
              
              <div className="flex flex-col gap-4">
                <Card
                  onClick={() => { setRole('student'); triggerHaptic('light'); }}
                  variant={role === 'student' ? 'active' : 'interactive'}
                  className="p-5 flex items-center gap-4 border"
                >
                  <div className={`p-3 rounded-xl ${role === 'student' ? 'bg-primary-green text-bg' : 'bg-surface-2 text-primary-green'}`}>
                    <User className="w-6 h-6" />
                  </div>
                  <div className="text-left flex-grow">
                    <h3 className="font-bold text-base text-white">Biologiya O'quvchisi</h3>
                    <p className="text-xs text-text-secondary mt-0.5">Testlar yechish, flashcardlar bilan dars qilish va reytinglarga kirish</p>
                  </div>
                  {role === 'student' && <Check className="w-5 h-5 text-primary-green" />}
                </Card>

                <Card
                  onClick={() => { setRole('teacher'); triggerHaptic('light'); }}
                  variant={role === 'teacher' ? 'active' : 'interactive'}
                  className="p-5 flex items-center gap-4 border"
                >
                  <div className={`p-3 rounded-xl ${role === 'teacher' ? 'bg-primary-green text-bg' : 'bg-surface-2 text-primary-green'}`}>
                    <GraduationCap className="w-6 h-6" />
                  </div>
                  <div className="text-left flex-grow">
                    <h3 className="font-bold text-base text-white">Biologiya O'qituvchisi</h3>
                    <p className="text-xs text-text-secondary mt-0.5">Savollar tuzish, kitob import (OCR), guruh boshqaruvi va o'quvchilarni kuzatish</p>
                  </div>
                  {role === 'teacher' && <Check className="w-5 h-5 text-primary-green" />}
                </Card>
              </div>
            </div>
          )}

          {/* STEP 2: Center Input with Autocomplete suggestions */}
          {step === 2 && (
            <div className="animate-fade-in">
              <h2 className="text-lg font-extrabold text-white mb-2 text-center">O'quv markazingiz yoki maktabingiz</h2>
              <p className="text-xs text-text-secondary text-center mb-6">Mashg'ulotlaringiz o'tiladigan ta'lim markazi nomini kiriting</p>

              <div className="relative">
                <Input
                  label="Markaz yoki Maktab nomi"
                  placeholder="Masalan: Registon, Grand Ta'lim, 1-maktab..."
                  value={learningCenter}
                  onChange={(e) => setLearningCenter(e.target.value)}
                  icon={<Building2 className="w-5 h-5" />}
                />

                {centerSuggestions.length > 0 && (
                  <div className="absolute left-0 right-0 top-full mt-2 bg-surface-1 border border-border-active rounded-xl p-2.5 z-50 shadow-2xl space-y-1">
                    <p className="text-[10px] font-mono uppercase tracking-wider text-text-muted px-2.5 py-1">Ishlatilgan markazlar</p>
                    {centerSuggestions.map((item) => (
                      <button
                        key={item}
                        type="button"
                        onClick={() => {
                          setLearningCenter(item);
                          setCenterSuggestions([]);
                          triggerHaptic('light');
                        }}
                        className="w-full text-left text-xs font-semibold text-text-secondary hover:text-primary-green hover:bg-surface-2 px-3 py-2.5 rounded-lg transition-colors cursor-pointer"
                      >
                        {item}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* STEP 3: Teacher Selection */}
          {step === 3 && (
            <div className="animate-fade-in">
              <h2 className="text-lg font-extrabold text-white mb-2 text-center">Biologiya o'qituvchingizni tanlang</h2>
              <p className="text-xs text-text-secondary text-center mb-6">"{learningCenter}" markazidagi o'qituvchilar</p>

              {teachers.length === 0 ? (
                <div className="text-center py-6">
                  <p className="text-sm font-semibold text-text-secondary">Ushbu markazda hali ro'yxatdan o'tgan o'qituvchilar yo'q.</p>
                  <Button variant="secondary" size="sm" className="mt-4" onClick={() => { setLearningCenter(''); setStep(2); }}>
                    Markazni qayta yozish
                  </Button>
                </div>
              ) : (
                <div className="flex flex-col gap-3.5 max-h-[250px] overflow-y-auto no-scrollbar">
                  {teachers.map((teacher) => (
                    <Card
                      key={teacher.id}
                      onClick={() => { setSelectedTeacherId(teacher.id); triggerHaptic('light'); }}
                      variant={selectedTeacherId === teacher.id ? 'active' : 'interactive'}
                      className="p-4 flex items-center gap-3.5 border"
                    >
                      <UserCheck className="w-5 h-5 text-primary-green" />
                      <div className="text-left flex-grow">
                        <p className="text-sm font-bold text-white">{teacher.full_name}</p>
                        <p className="text-xs font-mono text-text-secondary">@{teacher.username || 'username_yoq'}</p>
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* STEP 4: Selecting Group */}
          {step === 4 && (
            <div className="animate-fade-in">
              <h2 className="text-lg font-extrabold text-white mb-2 text-center">Guruhni tanlang</h2>
              <p className="text-xs text-text-secondary text-center mb-6">O'qituvchingiz boshqarayotgan o'quv guruhlari</p>

              {groups.length === 0 ? (
                <div className="text-center py-6">
                  <p className="text-sm font-semibold text-text-secondary">Ushbu ustozda guruhlar tashkil qilinmagan.</p>
                  <p className="text-xs text-text-muted mt-1">Ushbu bosqichni o'tkazib yuborishingiz mumkin.</p>
                </div>
              ) : (
                <div className="flex flex-col gap-3.5 max-h-[250px] overflow-y-auto no-scrollbar">
                  {groups.map((g) => (
                    <Card
                      key={g.id}
                      onClick={() => { setSelectedGroupId(g.id); triggerHaptic('light'); }}
                      variant={selectedGroupId === g.id ? 'active' : 'interactive'}
                      className="p-4 flex items-center gap-3.5 border"
                    >
                      <Users className="w-5 h-5 text-primary-green" />
                      <div className="text-left flex-grow">
                        <p className="text-sm font-bold text-white">{g.name}</p>
                        <p className="text-xs text-text-secondary">{g.center_name || learningCenter}</p>
                      </div>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* STEP 5: Confirm and save */}
          {step === 5 && (
            <div className="animate-fade-in text-center">
              <div className="w-12 h-12 rounded-full bg-primary-green/10 border border-primary-green flex items-center justify-center mx-auto mb-4">
                <Check className="w-6 h-6 text-primary-green" />
              </div>
              <h2 className="text-lg font-extrabold text-white mb-2">Ma'lumotlarni tasdiqlash</h2>
              <p className="text-xs text-text-secondary mb-6">Sizning platformadagi dastlabki profilingiz tayyor!</p>

              <div className="bg-surface-2 rounded-xl border border-border-subtle p-4 text-left space-y-3.5 text-xs mb-6">
                <div className="flex justify-between border-b border-border-subtle pb-2">
                  <span className="text-text-secondary font-mono">ISM-SHARIF:</span>
                  <span className="text-white font-bold">{profile?.full_name}</span>
                </div>
                <div className="flex justify-between border-b border-border-subtle pb-2">
                  <span className="text-text-secondary font-mono">ROL:</span>
                  <span className="text-primary-green font-extrabold tracking-wide uppercase">{role === 'student' ? 'O\'quvchi' : 'O\'qituvchi'}</span>
                </div>
                <div className="flex justify-between border-b border-border-subtle pb-2">
                  <span className="text-text-secondary font-mono">MARKAZ:</span>
                  <span className="text-white font-bold">{learningCenter}</span>
                </div>
                {role === 'student' && selectedTeacherId && (
                  <div className="flex justify-between border-b border-border-subtle pb-2">
                    <span className="text-text-secondary font-mono">O\'QITUVCHI:</span>
                    <span className="text-white font-bold">
                      {teachers.find(t => t.id === selectedTeacherId)?.full_name || 'Tanlangan'}
                    </span>
                  </div>
                )}
                {role === 'student' && selectedGroupId && (
                  <div className="flex justify-between pb-0">
                    <span className="text-text-secondary font-mono">GURUH:</span>
                    <span className="text-white font-bold">
                      {groups.find(g => g.id === selectedGroupId)?.name || 'Ulanmagan'}
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}

        </Card>
      </main>

      {/* Back and Next navigation buttons */}
      <footer id="onboarding_actions" className="flex items-center gap-4">
        {step > 1 && (
          <Button variant="glass" className="flex-grow max-w-[120px]" onClick={handleBack}>
            Orqaga
          </Button>
        )}
        
        {step < 5 ? (
          <Button variant="primary" className="flex-grow" onClick={handleNext}>
            Keyingisi
          </Button>
        ) : (
          <Button variant="primary" className="flex-grow glow-green font-black" isLoading={submitting} onClick={handleConfirmOnboarding}>
            Mening kabinetimga kirish
          </Button>
        )}
      </footer>
    </div>
  );
}

// ✅ DONE: src/components/auth/OnboardingFlow.jsx
