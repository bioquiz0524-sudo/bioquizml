-- Seed data for BioQuiz Platform (Uzbek Language)

-- 1. Insert Groups (Temporary IDs for static reference)
INSERT INTO groups (id, name, center_name, invite_link, created_at) VALUES 
('11111111-1111-1111-1111-111111111111', '7-A Biologiya', 'Grand Ta''lim', 'https://t.me/bioquiz_bot?start=g1111', now()),
('22222222-2222-2222-2222-222222222222', '8-B Tibbiyot', 'Registon Markazi', 'https://t.me/bioquiz_bot?start=g2222', now()),
('33333333-3333-3333-3333-333333333333', '9-A Genetika', 'Alfa Academy', 'https://t.me/bioquiz_bot?start=g3333', now())
ON CONFLICT (id) DO NOTHING;

-- 2. Insert Profiles - Teachers (O'zbek names, fixed IDs)
INSERT INTO profiles (id, telegram_id, full_name, username, role, learning_center, is_pro, created_at) VALUES
('a0000000-0000-0000-0000-000000000001', 100001, 'Sardor Rahimov', 'sardor_bio', 'teacher', 'Grand Ta''lim', true, now()),
('a0000000-0000-0000-0000-000000000002', 100002, 'Dilnoza Sobirova', 'dilnoza_biology', 'teacher', 'Registon Markazi', true, now()),
('a0000000-0000-0000-0000-000000000003', 100003, 'Nodir Turg''unov', 'nodir_t', 'teacher', 'Alfa Academy', true, now()),
('a0000000-0000-0000-0000-000000000004', 100004, 'Feruza KarimoVA', 'feruza_edu', 'teacher', 'Grand Ta''lim', false, now()),
('a0000000-0000-0000-0000-000000000005', 100005, 'Azizbek G''ofurov', 'aziz_biology', 'teacher', 'Registon Markazi', false, now()),
('a0000000-0000-0000-0000-000000000006', 100006, 'Shoira G''aniyeva', 'shoira_bio', 'teacher', 'Grand Ta''lim', true, now()),
('a0000000-0000-0000-0000-000000000007', 100007, 'Jasur Umarov', 'jasur_u', 'teacher', 'Alfa Academy', false, now()),
('a0000000-0000-0000-0000-000000000008', 100008, 'Madina HakimoVA', 'madina_edu', 'teacher', 'Grand Ta''lim', true, now()),
('a0000000-0000-0000-0000-000000000009', 100009, 'Dilshod Ergashev', 'dilshod_bio', 'teacher', 'Registon Markazi', true, now()),
('a0000000-0000-0000-0000-000000000010', 100010, 'Lobar Rahimova', 'lobar_biology', 'teacher', 'Alfa Academy', false, now())
ON CONFLICT (id) DO NOTHING;

-- Map teachers to groups
UPDATE groups SET teacher_id = 'a0000000-0000-0000-0000-000000000001' WHERE id = '11111111-1111-1111-1111-111111111111';
UPDATE groups SET teacher_id = 'a0000000-0000-0000-0000-000000000002' WHERE id = '22222222-2222-2222-2222-222222222222';
UPDATE groups SET teacher_id = 'a0000000-0000-0000-0000-000000000003' WHERE id = '33333333-3333-3333-3333-333333333333';

-- 3. Insert Profiles - Students
INSERT INTO profiles (id, telegram_id, full_name, username, role, learning_center, teacher_id, group_id, is_pro, wallet_balance, created_at) VALUES
('b0000000-0000-0000-0000-000000000001', 200001, 'Jasur Karimov', 'jasur_k', 'student', 'Grand Ta''lim', 'a0000000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', false, 30000, now()),
('b0000000-0000-0000-0000-000000000002', 200002, 'Malika Aliyeva', 'malika_a', 'student', 'Grand Ta''lim', 'a0000000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', true, 50000, now()),
('b0000000-0000-0000-0000-000000000003', 200003, 'Temur Hasanov', 'temur_h', 'student', 'Grand Ta''lim', 'a0000000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', false, 15000, now()),
('b0000000-0000-0000-0000-000000000004', 200004, 'Otabek Solihov', 'otabek_s', 'student', 'Registon Markazi', 'a0000000-0000-0000-0000-000000000002', '22222222-2222-2222-2222-222222222222', true, 100000, now()),
('b0000000-0000-0000-0000-000000000005', 200005, 'Rayhona Abdullayeva', 'rayhona_a', 'student', 'Registon Markazi', 'a0000000-0000-0000-0000-000000000002', '22222222-2222-2222-2222-222222222222', false, 0, now()),
('b0000000-0000-0000-0000-000000000006', 200006, 'Sardor Yo''ldoshev', 'sardor_y', 'student', 'Registon Markazi', 'a0000000-0000-0000-0000-000000000002', '22222222-2222-2222-2222-222222222222', false, 25000, now()),
('b0000000-0000-0000-0000-000000000007', 200007, 'Kamola Tojiyeva', 'kamola_t', 'student', 'Alfa Academy', 'a0000000-0000-0000-0000-000000000003', '33333333-3333-3333-3333-333333333333', true, 80000, now()),
('b0000000-0000-0000-0000-000000000008', 200008, 'Abdurahmon Mo''minov', 'abdurahmon_m', 'student', 'Alfa Academy', 'a0000000-0000-0000-0000-000000000003', '33333333-3333-3333-3333-333333333333', false, 5000, now()),
('b0000000-0000-0000-0000-000000000009', 200009, 'Nigora Salihova', 'nigora_s', 'student', 'Alfa Academy', 'a0000000-0000-0000-0000-000000000003', '33333333-3333-3333-3333-333333333333', false, 12000, now()),
('b0000000-0000-0000-0000-000000000010', 200010, 'Bekzod Karimov', 'bekzod_k', 'student', 'Grand Ta''lim', 'a0000000-0000-0000-0000-000000000001', '11111111-1111-1111-1111-111111111111', false, 25000, now())
ON CONFLICT (id) DO NOTHING;

-- 4. Insert Tests
INSERT INTO tests (id, title, teacher_id, center_name, subject, grade, topic, difficulty, question_count, time_limit, is_premium, price, status, session_code, created_at) VALUES
('d0000000-0000-0000-0000-000000000001', 'Odam anatomiyasi — Asosiy', 'a0000000-0000-0000-0000-000000000001', 'Grand Ta''lim', 'Biologiya', '8-sinf', '["Inson tanasi"]', 'oson', 20, 30, false, 0, 'active', 'BIO-7890', now()),
('d0000000-0000-0000-0000-000000000002', 'Odam anatomiyasi — Chuqur tahlil', 'a0000000-0000-0000-0000-000000000001', 'Grand Ta''lim', 'Biologiya', '9-sinf', '["Inson tanasi", "Genetika"]', 'qiyin', 30, 60, true, 25000, 'active', 'BIO-1234', now())
ON CONFLICT (id) DO NOTHING;

-- 5. Insert 50 Biology Questions (Mix of Hujayra, Genetika, Ekologiya, Inson tanasi, O'simliklar)
INSERT INTO questions (id, test_id, question_text, options, correct_index, topic, subject, grade, difficulty, order_number, created_by, created_at) VALUES

-- Test 1 (20 questions) - Odam anatomiyasi — Asosiy
('e0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000001', 'Odam skeletida nechta suyak mavjud?', '["150 tacha", "200 dan ortiq", "100 tacha", "300 dan ortiq"]', 1, 'Inson tanasi', 'Biologiya', '8-sinf', 'oson', 1, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000002', 'd0000000-0000-0000-0000-000000000001', 'Inson yuragi nechta kameradan iborat?', '["2 ta", "3 ta", "4 ta", "5 ta"]', 2, 'Inson tanasi', 'Biologiya', '8-sinf', 'oson', 2, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000003', 'd0000000-0000-0000-0000-000000000001', 'Odam nafas olganda organizmga qaysi gaz kiradi?', '["Karbonat angidrid", "Azot", "Argon", "Kislorod"]', 3, 'Inson tanasi', 'Biologiya', '8-sinf', 'oson', 3, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000004', 'd0000000-0000-0000-0000-000000000001', 'Sariq rangli o''t suyuqligi (safro) qaysi organda ishlab chiqariladi?', '["O''t pufagida", "Oshqozon osti bezida", "Jigarda", "Oshqozonda"]', 2, 'Inson tanasi', 'Biologiya', '8-sinf', 'oson', 4, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000005', 'd0000000-0000-0000-0000-000000000001', 'Inson tanasidagi eng uzun suyak qaysi?', '["Boldir suyagi", "Comb suyagi", "Yelka suyagi", "Son suyagi"]', 3, 'Inson tanasi', 'Biologiya', '8-sinf', 'oson', 5, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000006', 'd0000000-0000-0000-0000-000000000001', 'Qon shakar miqdorini nazorat qiluvchi insulin gormoni qaysi bezdan ajraladi?', '["Qalqonsimon bez", "Oshqozon osti bezi", "Gipofiz", "Buyrak usti bezi"]', 1, 'Inson tanasi', 'Biologiya', '8-sinf', 'oson', 6, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000007', 'd0000000-0000-0000-0000-000000000001', 'Katta qon aylanish doirasi qaysi kameradan boshlanadi?', '["Chap qorinchadan", "O''ng qorinchadan", "Chap bo''lmachadan", "O''ng bo''lmachadan"]', 0, 'Inson tanasi', 'Biologiya', '8-sinf', 'oson', 7, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000008', 'd0000000-0000-0000-0000-000000000001', 'Normal holatda inson tana harorati necha daraja bo''ladi?', '["37.5 °C", "36.6 °C", "35.5 °C", "38.0 °C"]', 1, 'Inson tanasi', 'Biologiya', '8-sinf', 'oson', 8, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000009', 'd0000000-0000-0000-0000-000000000001', 'Odamda necha juft qovurg''a bor?', '["10 juft", "12 juft", "14 juft", "16 juft"]', 1, 'Inson tanasi', 'Biologiya', '8-sinf', 'oson', 9, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000010', 'd0000000-0000-0000-0000-000000000001', 'Nefrologiya qaysi organ kasalliklarini o''rganadi?', '["O''pka", "Yurak", "Buyrak", "Jigar"]', 2, 'Inson tanasi', 'Biologiya', '8-sinf', 'oson', 10, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000011', 'd0000000-0000-0000-0000-000000000001', 'Inson organizmidagi eng kichik suyak qayerda joylashgan?', '["Burunda", "Quloqda", "Barmoqda", "Tishda"]', 1, 'Inson tanasi', 'Biologiya', '8-sinf', 'oson', 11, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000012', 'd0000000-0000-0000-0000-000000000001', 'Qonning suyuq qismi nima deb ataladi?', '["Gemoglobin", "Plazma", "Eritrotsit", "Limfa"]', 1, 'Inson tanasi', 'Biologiya', '8-sinf', 'oson', 12, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000013', 'd0000000-0000-0000-0000-000000000001', 'Odamda ko''rish markazi miyaning qaysi qismida joylashgan?', '["Peshona qismida", "Ensa qismida", "Chakka qismida", "Tepalik qismida"]', 1, 'Inson tanasi', 'Biologiya', '8-sinf', 'oson', 13, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000014', 'd0000000-0000-0000-0000-000000000001', 'Markaziy nerv sistemasiga nimalar kiradi?', '["Faqat bosh miya", "Asab tolalari", "Bosh miya va orqa miya", "Retseptorlar"]', 2, 'Inson tanasi', 'Biologiya', '8-sinf', 'oson', 14, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000015', 'd0000000-0000-0000-0000-000000000001', 'Odamda nechta qon guruhi bor?', '["3 ta", "4 ta", "5 ta", "6 ta"]', 1, 'Inson tanasi', 'Biologiya', '8-sinf', 'oson', 15, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000016', 'd0000000-0000-0000-0000-000000000001', 'Tishning eng tashqi, qattiq qavati nima deb ataladi?', '["Dentin", "Pulpa", "Kvars", "Emal"]', 3, 'Inson tanasi', 'Biologiya', '8-sinf', 'oson', 16, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000017', 'd0000000-0000-0000-0000-000000000001', 'Qaysi vitamin yetishmasligi oqibatida karies yoki tish to''kilishi yuzaga keladi?', '["C vitamini", "D vitamini", "A vitamini", "B12"]', 1, 'Inson tanasi', 'Biologiya', '8-sinf', 'oson', 17, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000018', 'd0000000-0000-0000-0000-000000000001', 'Kichik qon aylanish doirasi qayerda tugaydi?', '["O''ng bo''lmachada", "Chap bo''lmachada", "O''ng qorinchada", "Chap qorinchada"]', 1, 'Inson tanasi', 'Biologiya', '8-sinf', 'oson', 18, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000019', 'd0000000-0000-0000-0000-000000000001', 'Odam siydik ajratish tizimiga qaysi organ kiradi?', '["Buyraklar", "O''pka", "Safro yo''li", "Kuzor"]', 0, 'Inson tanasi', 'Biologiya', '8-sinf', 'oson', 19, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000020', 'd0000000-0000-0000-0000-000000000001', 'Oshqozon shirasining kislotaliligini qaysi kislota ta''minlaydi?', '["Sulfat kislota", "Sirka kislotasi", "Xlorid kislota", "Fosfat kislota"]', 2, 'Inson tanasi', 'Biologiya', '8-sinf', 'oson', 20, 'a0000000-0000-0000-0000-000000000001', now()),

-- Test 2 (30 questions) - Odam anatomiyasi — Chuqur tahlil
('e0000000-0000-0000-0000-000000000021', 'd0000000-0000-0000-0000-000000000002', 'Hujayraning energetik stansiyasi nima?', '["Ribosoma", "Yadro", "Mitoxondriya", "Lizosoma"]', 2, 'Hujayra', 'Biologiya', '9-sinf', 'o_rta', 1, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000022', 'd0000000-0000-0000-0000-000000000002', 'Genetika fanining asoschisi kim?', '["Gregor Mendel", "Charlz Darvin", "Lui Paster", "Tomas Morgan"]', 0, 'Genetika', 'Biologiya', '9-sinf', 'o_rta', 2, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000023', 'd0000000-0000-0000-0000-000000000002', 'Hujayraning bo''linishida ishtirok etadigan asosiy organoid?', '["Hujayra markazi", "Xloroplast", "Vakuola", "Ribosoma"]', 0, 'Hujayra', 'Biologiya', '9-sinf', 'o_rta', 3, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000024', 'd0000000-0000-0000-0000-000000000002', 'Fotosintez jarayoni o''simlik hujayrasining qaysi organoidida kechadi?', '["Leykoplast", "Xromoplast", "Xloroplast", "Golji majmuasi"]', 2, 'O''simliklar', 'Biologiya', '9-sinf', 'o_rta', 4, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000025', 'd0000000-0000-0000-0000-000000000002', 'DNK qo''sh spirali modelini kimlar yaratgan?', '["Mendel va Morgan", "Uotson va Krik", "Eyxler va Darvin", "Shleyden va Shvann"]', 1, 'Genetika', 'Biologiya', '9-sinf', 'o_rta', 5, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000026', 'd0000000-0000-0000-0000-000000000002', 'Inson tana hujayrasida (somatik) nechta xromosoma bor?', '["23 ta", "46 ta", "48 ta", "22 ta"]', 1, 'Genetika', 'Biologiya', '9-sinf', 'o_rta', 6, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000027', 'd0000000-0000-0000-0000-000000000002', 'Ekologiya atamasini birinchi marta fanga kim kiritgan?', '["Ernst Gekkel", "Artur Tensli", "Charlz Darvin", "Vladimir Vernadskiy"]', 0, 'Ekologiya', 'Biologiya', '9-sinf', 'o_rta', 7, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000028', 'd0000000-0000-0000-0000-000000000002', 'Inson organizmidagi qaysi organ zaharli moddalarni neytrallaydi?', '["O''pka", "Buyrak", "Me''da osti bezi", "Jigar"]', 3, 'Inson tanasi', 'Biologiya', '9-sinf', 'o_rta', 8, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000029', 'd0000000-0000-0000-0000-000000000002', 'Qaysi qon garmoni buyrak usti bezidan favqulodda vaziyatlarda ajraladi?', '["Tiroksin", "Adrenalin", "Insulin", "Estrogen"]', 1, 'Inson tanasi', 'Biologiya', '9-sinf', 'o_rta', 9, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000030', 'd0000000-0000-0000-0000-000000000002', 'Tabiatda organik moddalarni parchalovchilar qanday ataladi?', '["Produtsentlar", "Konsumentlar", "Redutsentlar", "Eko-destruktorlar"]', 2, 'Ekologiya', 'Biologiya', '9-sinf', 'o_rta', 10, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000031', 'd0000000-0000-0000-0000-000000000002', 'Irsiyatning elementar birligi nima?', '["Xromosoma", "Gen", "Nukleotid", "Sitoplazma"]', 1, 'Genetika', 'Biologiya', '9-sinf', 'o_rta', 11, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000032', 'd0000000-0000-0000-0000-000000000002', 'Inson ko''zining to''r pardasida joyhazgan yorug''lik retseptorlari qaysilar?', '["Shishasimonlar va tasmalar", "Ratsional va emotsional", "Kolbachalar va tayoqchalar", "Akson va dendritlar"]', 2, 'Inson tanasi', 'Biologiya', '9-sinf', 'o_rta', 12, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000033', 'd0000000-0000-0000-0000-000000000002', 'O''simliklarda suv va unda erigan mineral tuzlar qaysi to''qima orqali harakatlanadi?', '["Ksilema (Elaksimon)", "Ksilema (Yog''ochlik)", "Floema", "Po''stloq"]', 1, 'O''simliklar', 'Biologiya', '9-sinf', 'o_rta', 13, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000034', 'd0000000-0000-0000-0000-000000000002', 'Geterozigota organizm qanday belgilanadi?', '["AA", "aa", "Aa", "XhY"]', 2, 'Genetika', 'Biologiya', '9-sinf', 'o_rta', 14, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000035', 'd0000000-0000-0000-0000-000000000002', 'Golji majmuasining asosiy vazifasi nima?', '["Oqsil sintez qilish", "Moddalarni tashish va qadoqlash", "DNK replikatsiyasi", "Hujayra nafas olishi"]', 1, 'Hujayra', 'Biologiya', '9-sinf', 'o_rta', 15, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000036', 'd0000000-0000-0000-0000-000000000002', 'Miyaning qaysi qismi muvozanat va harakat koordinatsiyasini boshqaradi?', '["Miyacha", "Uzunchoq miya", "O''rta miya", "Orqa miya"]', 0, 'Inson tanasi', 'Biologiya', '9-sinf', 'o_rta', 16, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000037', 'd0000000-0000-0000-0000-000000000002', 'Xlorofill pigmenti tarkibida qaysi metall atomi bor?', '["Temir (Fe)", "Magniy (Mg)", "Mis (Cu)", "Kalsiy (Ca)"]', 1, 'Hujayra', 'Biologiya', '9-sinf', 'o_rta', 17, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000038', 'd0000000-0000-0000-0000-000000000002', 'Qaysi qon guruhiga ega inson umumiy donor (hamma guruhga qon bera oladi) hisoblanadi?', '["I guruh (0)", "II guruh (A)", "III guruh (B)", "IV guruh (AB)"]', 0, 'Inson tanasi', 'Biologiya', '9-sinf', 'o_rta', 18, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000039', 'd0000000-0000-0000-0000-000000000002', 'Mejoz bo''linish natijasida bitta onalik hujayradan nechta qizli hujayra hosil bo''ladi?', '["2 ta", "4 ta", "1 ta", "8 ta"]', 1, 'Hujayra', 'Biologiya', '9-sinf', 'o_rta', 19, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000040', 'd0000000-0000-0000-0000-000000000002', 'Qonning ivishida qaysi hujayralar (plastinkalar) muhim ro''l o''ynaydi?', '["Eritrotsitlar", "Leykotsitlar", "Trombotsitlar", "Limfotsitlar"]', 2, 'Inson tanasi', 'Biologiya', '9-sinf', 'o_rta', 20, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000041', 'd0000000-0000-0000-0000-000000000002', 'Atmosferadagi erkin azotni o''zlashtirib, tuproqni boyituvchi bakteriyalar qanday ataladi?', '["Achitqi bakteriyalar", "Tugunak bakteriyalari", "Chirish bakteriyalari", "Sut-kislotali bakteriyalar"]', 1, 'Ekologiya', 'Biologiya', '9-sinf', 'o_rta', 21, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000042', 'd0000000-0000-0000-0000-000000000002', 'Birinchi qon guruhi (I guruh, 0) tarkibidagi aglyutininlar qaysilar?', '["alfa va betta", "faqat alfa", "faqat betta", "aglyutininlar mavjud emas"]', 0, 'Inson tanasi', 'Biologiya', '9-sinf', 'qiyin', 22, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000043', 'd0000000-0000-0000-0000-000000000002', 'Odam ko''richagining chuvalchangsimon o''simtasi qanday organ hisoblanadi?', '["Atavizm", "Rudiment", "Analogik organ", "Gomologik organ"]', 1, 'Inson tanasi', 'Biologiya', '9-sinf', 'o_rta', 23, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000044', 'd0000000-0000-0000-0000-000000000002', 'Gidra qaysi tana qoplamiga, qanday shaklga ega?', '["Ikki qavatli, radial simmetriyali", "Uch qavatli, ikki tomonlama", "Bir hujayrali, asimmetrik", "Yassi shaklli, tishli"]', 0, 'Ekologiya', 'Biologiya', '9-sinf', 'o_rta', 24, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000045', 'd0000000-0000-0000-0000-000000000002', 'Yadro qobig''iga ega bo''lmagan, genetik materiali sitoplazmada joylashgan organizmlar?', '["Evkariotlar", "Prokariotlar", "Viruslar", "Prionlar"]', 1, 'Hujayra', 'Biologiya', '9-sinf', 'o_rta', 25, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000046', 'd0000000-0000-0000-0000-000000000002', 'Taqidlovchi (inhibitor) neyromediator qaysi?', '["Adrenalin", "Dofamin", "GAYK (Gamma-aminomoy kislota)", "Atsetilxolin"]', 2, 'Inson tanasi', 'Biologiya', '9-sinf', 'qiyin', 26, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000047', 'd0000000-0000-0000-0000-000000000002', 'Insonda rang ajratolmaslik (daltonizm) qanday tug''ma kasallik turi?', '["Y-xromosomaga birikkan dominant", "X-xromosomaga birikkan retsessiv", "Autosom-dominant", "Mutatsiya emas, orttirilgan"]', 1, 'Genetika', 'Biologiya', '9-sinf', 'qiyin', 27, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000048', 'd0000000-0000-0000-0000-000000000002', 'Ekologik piramida qoidasiga ko''ra, bir trofik darajadan keyingisiga qancha energiya o''tadi?', '["Faqat 10%", "Faqat 50%", "Faqat 1%", "Faqat 90%"]', 0, 'Ekologiya', 'Biologiya', '9-sinf', 'o_rta', 28, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000049', 'd0000000-0000-0000-0000-000000000002', 'Mitoz bo''linishning qaysi bosqichida xromosomalar ekvator tekisligida tiziladi?', '["Profaza", "Metafaza", "Anafaza", "Telofaza"]', 1, 'Hujayra', 'Biologiya', '9-sinf', 'o_rta', 29, 'a0000000-0000-0000-0000-000000000001', now()),
('e0000000-0000-0000-0000-000000000050', 'd0000000-0000-0000-0000-000000000002', 'Gemosianin pigmenti bor qonda qaysi metall mavjud va u qonni qanday rangga bo''yaydi?', '["Rux - Yashil", "Mis - Moviy (Ko''k)", "Temir - Qizil", "Magniy - Sariq"]', 1, 'Ekologiya', 'Biologiya', '9-sinf', 'qiyin', 30, 'a0000000-0000-0000-0000-000000000001', now())
ON CONFLICT (id) DO NOTHING;

-- 6. Insert Flashcards for Spaced Repetition (Linked to the questions above)
INSERT INTO flashcards (id, test_id, question_id, front_text, back_text, topic, difficulty) VALUES
('f0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000001', 'Odam skeletida nechta suyak mavjud?', '200 dan ortiq suyak bor', 'Inson tanasi', 'oson'),
('f0000000-0000-0000-0000-000000000002', 'd0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000002', 'Inson yuragi nechta kameradan iborat?', '4 ta kameradan (2 ta bo''lmacha va 2 ta qorincha)', 'Inson tanasi', 'oson'),
('f0000000-0000-0000-0000-000000000003', 'd0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000003', 'Odam nafas olganda organizmga qaysi gaz kiradi?', 'Kislorod (O2) gazi kiradi', 'Inson tanasi', 'oson'),
('f0000000-0000-0000-0000-000000000004', 'd0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000004', 'Sariq rangli o''t suyuqligi (safro) qayerda ishlab chiqariladi?', 'Jigarda hosil bo''ladi, o''t pufagida to''planadi', 'Inson tanasi', 'oson'),
('f0000000-0000-0000-0000-000000000005', 'd0000000-0000-0000-0000-000000000001', 'e0000000-0000-0000-0000-000000000005', 'Inson tanasidagi eng uzun suyak qaysi?', 'Son suyagi (femur)', 'Inson tanasi', 'oson')
ON CONFLICT (id) DO NOTHING;

-- 7. Insert Sample Exam Results
INSERT INTO exam_results (id, student_id, test_id, center_name, score, total, percentage, total_time_spent, answers, failed_topics, completed_at) VALUES
('c0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000001', 'Grand Ta''lim', 18, 20, 90, 450, '[]'::jsonb, '[]'::jsonb, now() - interval '2 days'),
('c0000000-0000-0000-0000-000000000002', 'b0000000-0000-0000-0000-000000000002', 'd0000000-0000-0000-0000-000000000001', 'Grand Ta''lim', 20, 20, 100, 310, '[]'::jsonb, '[]'::jsonb, now() - interval '1 days'),
('c0000000-0000-0000-0000-000000000003', 'b0000000-0000-0000-0000-000000000003', 'd0000000-0000-0000-0000-000000000001', 'Grand Ta''lim', 14, 20, 70, 600, '[]'::jsonb, '["Inson tanasi"]'::jsonb, now())
ON CONFLICT (id) DO NOTHING;
