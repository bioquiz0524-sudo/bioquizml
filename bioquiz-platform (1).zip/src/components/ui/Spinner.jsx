// ✅ Circular Spinner Loader with Green accents
import React from 'react';

export default function Spinner({
  id = `spinner_${Math.random().toString(36).substr(2, 9)}`,
  size = 'md', // 'sm' | 'md' | 'lg'
  className = ''
}) {
  const sizeStyles = {
    sm: 'w-5 h-5 border-2',
    md: 'w-10 h-10 border-3',
    lg: 'w-16 h-16 border-4'
  };

  return (
    <div id={id} className={`flex justify-center items-center p-4 ${className}`}>
      <div
        id={`${id}_circle`}
        className={`${sizeStyles[size]} border-border-subtle border-t-primary-green rounded-full animate-spin`}
      />
    </div>
  );
}

// ✅ DONE: src/components/ui/Spinner.jsx
