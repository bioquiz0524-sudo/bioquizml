// ✅ Group classroom manager and students mass Telegram-inviter
import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabaseClient';
import { useAppStore } from '../../store/useAppStore';
import { useAuthStore } from '../../store/useAuthStore';
import { triggerHaptic } from '../../lib/telegramAuth';
import Button from '../ui/Button';
import Card from '../ui/Card';
import Input from '../ui/Input';
import Badge from '../ui/Badge';
import { Users, Plus, Key, Link2, Mail, Send, Award, Trash2 } from 'lucide-react';

export default function GroupManager() {
  const { profile } = useAuthStore();
  const { showToast } = useAppStore();

  const [groups, setGroups] = useState([]);
  const [students, setStudents] = useState([]);
  const [activeGroup, setActiveGroup] = useState(null);
  
  const [newGroupName, setNewGroupName] = useState('');
  const [isCreating, setIsCreating] = useState(false);

  useEffect(() => {
    if (profile?.id) {
      loadGroupsAndStudents();
    }
  }, [profile?.id]);

  const loadGroupsAndStudents = async () => {
    try {
      // Load groups created by this teacher
      const { data: gData } = await supabase
        .from('groups')
        .select('*')
        .eq('teacher_id', profile.id);

      if (gData) {
        setGroups(gData);
        if (gData.length > 0 && !activeGroup) {
          setActiveGroup(gData[0]);
        }
      }

      // Load all students registered under this teacher
      const { data: sData } = await supabase
        .from('profiles')
        .select('*')
        .eq('role', 'student')
        .eq('teacher_id', profile.id);

      if (sData) setStudents(sData);
    } catch (e) {
      console.error("Group loads error", e);
    }
  };

  const handleCreateGroup = async (e) => {
    e.preventDefault();
    if (!newGroupName.trim()) return;

    setIsCreating(true);
    triggerHaptic('light');

    const cleanName = newGroupName.trim();
    const mockCode = `g_${Math.random().toString(36).substr(2, 6)}`;
    const inviteLink = `https://t.me/bioquiz_bot?start=${mockCode}`;

    try {
      const newGroupObj = {
        name: cleanName,
        teacher_id: profile.id,
        center_name: profile.learning_center || 'BioQuiz Platform',
        invite_link: inviteLink
      };

      const { data, error } = await supabase
        .from('groups')
        .insert(newGroupObj)
        .select()
        .single();

      if (error) throw error;

      setGroups([...groups, data]);
      setActiveGroup(data);
      setNewGroupName('');
      showToast(`"${cleanName}" o'quv guruhi yaratildi!`, "success");
    } catch (err) {
      showToast("Guruh yaratishda xatolik yuz berdi.", "error");
    } finally {
      setIsCreating(false);
    }
  };

  const handleDeleteGroup = async (groupId) => {
    if (!window.confirm("Haqiqatdan ham bu guruhni o'chirib yubormoqchimisiz?")) return;
    triggerHaptic('error');

    try {
      await supabase.from('groups').delete().eq('id', groupId);
      const remaining = groups.filter(g => g.id !== groupId);
      setGroups(remaining);
      setActiveGroup(remaining[0] || null);
      showToast("Guruh muvaffaqiyatli o'chirildi", "info");
    } catch (err) {
      showToast("Guruhni o'chirish barbod bo'ldi.", "error");
    }
  };

  // Filter students belonging to the active group
  const activeStudents = students.filter(s => s.group_id === activeGroup?.id);

  // Copy bot invite link to clipboard
  const handleCopyLink = (link) => {
    navigator.clipboard.writeText(link);
    showToast("Taklif havolasi buferga nusxalandi!", "success");
    triggerHaptic('success');
  };

  return (
    <div id="group_manager_frame" className="w-full space-y-6 animate-fade-in text-left pb-[60px]">
      
      {/* Overview header */}
      <div className="text-left space-y-0.5">
        <h3 className="text-xl font-extrabold text-white">Sinflar va o'quv guruhlari</h3>
        <p className="text-xs text-text-secondary">O'quvchilaringiz ro'yxati, guruh ko'rsatkichlari va dars takliflari</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* left column: Group creator & selector list */}
        <div className="space-y-4 md:col-span-1">
          {/* Create Group box */}
          <Card variant="glass" className="p-4 space-y-4">
            <h4 className="text-xs font-bold font-mono tracking-wider text-text-secondary uppercase">Yangi sinf ochish</h4>
            <form onSubmit={handleCreateGroup} className="flex flex-col gap-3">
              <Input
                placeholder="Guruh nomi: 9-A, Tibbiyot..."
                value={newGroupName}
                onChange={(e) => setNewGroupName(e.target.value)}
                required
              />
              <Button type="submit" variant="primary" size="sm" className="w-full" isLoading={isCreating} icon={<Plus className="w-4 h-4" />}>
                Guruh Yaratish
              </Button>
            </form>
          </Card>

          {/* List of active groups */}
          <div className="space-y-2">
            <p className="text-[10px] font-bold font-mono text-text-muted uppercase tracking-wider pl-1 font-bold">Faol Guruhlar</p>
            {groups.length === 0 ? (
              <p className="text-xs text-text-secondary italic pl-1">Sizda hali guruhlar yo'q.</p>
            ) : (
              groups.map((g) => {
                const isActive = activeGroup?.id === g.id;
                return (
                  <Card
                    key={g.id}
                    onClick={() => { setActiveGroup(g); triggerHaptic('light'); }}
                    variant={isActive ? 'active' : 'interactive'}
                    className="p-3.5 flex items-center justify-between border"
                  >
                    <span className="text-sm font-bold text-white flex items-center gap-2">
                      <Users className="w-4.5 h-4.5 text-primary-green" /> {g.name}
                    </span>
                    <button
                      onClick={(e) => { e.stopPropagation(); handleDeleteGroup(g.id); }}
                      className="p-1 rounded text-text-muted hover:text-danger-accent transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </Card>
                );
              })
            )}
          </div>
        </div>

        {/* right column: Active classroom member roster table */}
        <div className="md:col-span-2">
          {activeGroup ? (
            <Card variant="glass" className="p-5 space-y-5 border-primary-green/20">
              
              {/* Header metrics card */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-border-subtle pb-4">
                <div className="text-left space-y-1">
                  <h3 className="text-lg font-extrabold text-white flex items-center gap-2">
                    <Users className="w-5.5 h-5.5 text-primary-green" /> {activeGroup.name}
                  </h3>
                  <p className="text-xs text-text-secondary">Markaz: {activeGroup.center_name || 'BioQuiz platforma'}</p>
                </div>

                <div className="flex items-center gap-2">
                  <Button
                    variant="glass"
                    size="sm"
                    className="flex items-center gap-1.5"
                    onClick={() => handleCopyLink(activeGroup.invite_link)}
                  >
                    <Link2 className="w-4 h-4 text-primary-green" /> Taklif havolasi
                  </Button>
                </div>
              </div>

              {/* Members listing Table */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold font-mono tracking-wider text-text-secondary uppercase">Sinf a'zolari ({activeStudents.length} ta talaba)</h4>
                {activeStudents.length === 0 ? (
                  <div className="text-center py-8 bg-surface-1/40 border border-dashed border-border-subtle rounded-xl">
                    <Mail className="w-8 h-8 text-text-muted mx-auto mb-2" />
                    <p className="text-sm font-semibold text-text-secondary">Ushbu guruhda o'quvchilar topilmadi.</p>
                    <p className="text-xs text-text-muted mt-1">O'quvchilarni taklif havolasi orqali guruhga qo'shing.</p>
                  </div>
                ) : (
                  <div className="space-y-2 max-h-[300px] overflow-y-auto no-scrollbar">
                    {activeStudents.map((st) => (
                      <div
                        key={st.id}
                        className="flex items-center justify-between bg-surface-1 hover:bg-surface-2 px-3.5 py-3 rounded-xl border border-border-subtle"
                      >
                        <div className="text-left space-y-0.5">
                          <p className="text-sm font-bold text-white">{st.full_name}</p>
                          <p className="text-[10px] font-mono text-text-secondary">ID: {st.telegram_id} · @{st.username || 'user'}</p>
                        </div>

                        <div className="flex items-center gap-2.5">
                          {st.is_pro && <Badge variant="pro">PRO</Badge>}
                          <div className="bg-surface-2 border border-border-subtle/50 px-3 py-1.5 rounded-lg flex items-center gap-1 font-mono text-xs font-black text-text-secondary">
                            <Award className="w-4 h-4 text-primary-green" /> {st.wallet_balance?.toLocaleString()} UZS
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </Card>
          ) : (
            <Card variant="glass" className="p-8 text-center border-dashed border-border-subtle">
              <Users className="w-12 h-12 text-text-muted mx-auto mb-3" />
              <p className="text-base font-extrabold text-[#E8F5E9] mb-1">Guruh tanlanmagan</p>
              <p className="text-xs text-text-secondary">Iltimos, guruh tafsilotlarini ko'rish uchun chap tomondan birini bosing yoki yangi sinf yarating.</p>
            </Card>
          )}
        </div>
      </div>

    </div>
  );
}

// ✅ DONE: src/components/teacher/GroupManager.jsx
