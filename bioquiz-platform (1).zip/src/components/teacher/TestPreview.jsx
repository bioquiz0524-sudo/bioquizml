// ✅ Editable Question List Editor with Radio correct selectors
import React, { useState } from 'react';
import { useAppStore } from '../../store/useAppStore';
import { triggerHaptic } from '../../lib/telegramAuth';
import Button from '../ui/Button';
import Card from '../ui/Card';
import Input from '../ui/Input';
import { Plus, Trash, ArrowUp, ArrowDown, HelpCircle, Image as ImageIcon } from 'lucide-react';

export default function TestPreview({ initialQuestions, onSave }) {
  const { showToast } = useAppStore();
  const [questions, setQuestions] = useState(
    initialQuestions && initialQuestions.length > 0 
      ? initialQuestions 
      : [{ question_text: 'Yangi savol matni', options: ['A variant', 'B variant', 'C variant', 'D variant'], correct_index: 0, topic: 'Hujayra' }]
  );

  const handleTextChange = (qIdx, value) => {
    const list = [...questions];
    list[qIdx].question_text = value;
    setQuestions(list);
  };

  const handleOptionChange = (qIdx, oIdx, value) => {
    const list = [...questions];
    list[qIdx].options[oIdx] = value;
    setQuestions(list);
  };

  const handleCorrectSelector = (qIdx, oIdx) => {
    const list = [...questions];
    list[qIdx].correct_index = oIdx;
    setQuestions(list);
    triggerHaptic('light');
  };

  const handleTopicChange = (qIdx, value) => {
    const list = [...questions];
    list[qIdx].topic = value;
    setQuestions(list);
  };

  const handleRemoveQuestion = (qIdx) => {
    if (questions.length <= 1) {
      showToast("Testda kamida bitta savol bo'lishi shart!", "warning");
      return;
    }
    const list = questions.filter((_, idx) => idx !== qIdx);
    setQuestions(list);
    showToast("Savol o'chirildi", "info");
    triggerHaptic('error');
  };

  const handleAddQuestion = () => {
    const list = [...questions, {
      question_text: '',
      options: ['', '', '', ''],
      correct_index: 0,
      topic: 'Hujayra',
      difficulty: 'o_rta'
    }];
    setQuestions(list);
    showToast("Yangi bo'sh savol qo'shildi!", "success");
    triggerHaptic('light');
  };

  // Move questions positions
  const handleMoveUp = (qIdx) => {
    if (qIdx === 0) return;
    const list = [...questions];
    const temp = list[qIdx];
    list[qIdx] = list[qIdx - 1];
    list[qIdx - 1] = temp;
    setQuestions(list);
    triggerHaptic('light');
  };

  const handleMoveDown = (qIdx) => {
    if (qIdx === questions.length - 1) return;
    const list = [...questions];
    const temp = list[qIdx];
    list[qIdx] = list[qIdx + 1];
    list[qIdx + 1] = temp;
    setQuestions(list);
    triggerHaptic('light');
  };

  const handleSaveAll = () => {
    // Validate that there are no empty questions or choices
    const hasEmptyField = questions.some(q => !q.question_text.trim() || q.options.some(o => !o.trim()));
    if (hasEmptyField) {
      showToast("Iltimos barcha matnlarni to'ldiring! Bo'sh qoldirish mumkin emas.", "warning");
      return;
    }

    if (onSave) {
      onSave(questions);
    }
  };

  return (
    <div id="test_preview_editor" className="w-full space-y-6">
      
      <div className="flex items-center justify-between border-b border-border-subtle pb-3">
        <div className="text-left space-y-0.5">
          <h4 className="font-extrabold text-white text-base">Savollarni tekshirish va tahrirlash</h4>
          <p className="text-xs text-text-secondary">Ushbu varaqda xatoliklarni to'g'rilang va javoblar to'g'riligini tasdiqlang</p>
        </div>
        <Button variant="secondary" size="sm" onClick={handleAddQuestion} icon={<Plus className="w-4 h-4" />}>
          Savol Qo'shish
        </Button>
      </div>

      <div className="space-y-4 max-h-[500px] overflow-y-auto no-scrollbar pr-1">
        {questions.map((q, qIdx) => (
          <Card key={qIdx} variant="glass" className="p-5 space-y-4 border-border-subtle relative">
            
            {/* Index card operations bar */}
            <div className="flex items-center justify-between">
              <span className="text-xs font-black font-mono text-primary-green flex items-center gap-1.5 bg-surface-2 px-3 py-1.5 rounded-lg border border-border-subtle">
                <HelpCircle className="w-4 h-4" /> {qIdx + 1}-SAVOL
              </span>
              
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={qIdx === 0}
                  onClick={() => handleMoveUp(qIdx)}
                  className="p-1.5 rounded bg-surface-2 border border-border-subtle text-text-secondary hover:text-white disabled:opacity-30 cursor-pointer"
                >
                  <ArrowUp className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  disabled={qIdx === questions.length - 1}
                  onClick={() => handleMoveDown(qIdx)}
                  className="p-1.5 rounded bg-surface-2 border border-border-subtle text-text-secondary hover:text-white disabled:opacity-30 cursor-pointer"
                >
                  <ArrowDown className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => handleRemoveQuestion(qIdx)}
                  className="p-1.5 rounded bg-surface-2 border border-border-subtle text-text-muted hover:text-danger-accent cursor-pointer"
                >
                  <Trash className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Input Question text box */}
            <textarea
              id={`q_${qIdx}_text`}
              rows={2}
              value={q.question_text || q.text || ''}
              onChange={(e) => handleTextChange(qIdx, e.target.value)}
              placeholder="Biologiya savol loyihasini shu yerda yozing..."
              className="w-full bg-surface-1 border border-border-subtle focus:border-primary-green rounded-xl p-3 text-text-primary text-sm font-medium outline-none resize-none"
            />

            {/* Render Image marker icon if has mapped illustrations */}
            {q.image_url && (
              <div className="flex items-center gap-2 text-xs font-bold text-primary-green bg-surface-2/65 p-2 rounded-lg border border-border-subtle">
                <ImageIcon className="w-4 h-4" /> Biriktirilgan surat mavjud
              </div>
            )}

            {/* Input Options checkboxes inside nested grids */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {['A', 'B', 'C', 'D'].map((letter, oIdx) => {
                const optVal = q.options[oIdx] || '';
                const isCorrect = q.correct_index === oIdx;

                return (
                  <div
                    key={letter}
                    className={`flex items-center gap-2.5 bg-surface-1 px-3 py-2 rounded-xl border transition-all
                    ${isCorrect ? 'border-primary-green/60 bg-primary-green/5' : 'border-border-subtle/50'}`}
                  >
                    {/* Radio Button Selector */}
                    <button
                      type="button"
                      onClick={() => handleCorrectSelector(qIdx, oIdx)}
                      className={`w-5.5 h-5.5 rounded-full border flex items-center justify-center font-bold text-xs cursor-pointer select-none
                      ${isCorrect ? 'bg-primary-green border-primary-green text-[#020c07]' : 'border-border-subtle text-text-secondary'}`}
                    >
                      {letter}
                    </button>

                    <input
                      id={`q_${qIdx}_opt_${oIdx}`}
                      type="text"
                      value={optVal}
                      onChange={(e) => handleOptionChange(qIdx, oIdx, e.target.value)}
                      placeholder={`${letter}-variant`}
                      className="flex-grow bg-transparent text-text-primary text-xs outline-none font-semibold"
                    />
                  </div>
                );
              })}
            </div>

            {/* Select Topic code chip input */}
            <div className="flex items-center gap-2.5">
              <span className="text-[10px] font-mono text-text-secondary tracking-wider font-bold">MAVZU:</span>
              <input
                id={`q_${qIdx}_topic`}
                type="text"
                value={q.topic || ''}
                onChange={(e) => handleTopicChange(qIdx, e.target.value)}
                placeholder="Hujayra, Genetika, Ekologiya, Inson tanasi..."
                className="bg-surface-1 border border-border-subtle rounded-lg px-2 py-1 text-xs text-text-secondary font-semibold outline-none focus:border-primary-green"
              />
            </div>

          </Card>
        ))}
      </div>

      <footer className="pt-2 flex justify-end gap-3">
        <Button variant="primary" className="px-10 font-bold" onClick={handleSaveAll}>
          Tahrirlashni Saqlash
        </Button>
      </footer>
    </div>
  );
}

// ✅ DONE: src/components/teacher/TestPreview.jsx
