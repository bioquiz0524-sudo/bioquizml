// ✅ Styled text form inputs for BioQuiz Platform
import React from 'react';

export default function Input({
  id = `input_${Math.random().toString(36).substr(2, 9)}`,
  type = 'text',
  placeholder = '',
  value,
  onChange,
  label = '',
  error = '',
  icon = null,
  className = '',
  disabled = false,
  required = false,
  maxLength,
  max,
  min
}) {
  return (
    <div className={`w-full flex flex-col gap-1.5 ${className}`}>
      {label && (
        <label id={`${id}_label`} className="text-xs font-bold font-mono uppercase tracking-wider text-text-secondary">
          {label} {required && <span className="text-danger-accent">*</span>}
        </label>
      )}

      {/* Input textbox layout */}
      <div className="relative w-full">
        {icon && (
          <div id={`${id}_prefix`} className="absolute left-4 top-1/2 -translate-y-1/2 text-text-secondary select-none pointer-events-none">
            {icon}
          </div>
        )}
        <input
          id={id}
          type={type}
          value={value !== undefined ? value : ''}
          onChange={onChange}
          placeholder={placeholder}
          disabled={disabled}
          maxLength={maxLength}
          max={max}
          min={min}
          className={`w-full bg-surface-1 border border-border-subtle focus:border-primary-green focus:shadow-[0_0_15px_rgba(0,230,118,0.12)] 
          rounded-xl text-text-primary placeholder:text-text-muted/70 text-sm font-medium transition-all duration-250 outline-none
          ${icon ? 'pl-11' : 'px-4'} py-3.5 min-h-[48px] disabled:opacity-40 disabled:cursor-not-allowed`}
          required={required}
        />
      </div>

      {error && (
        <span id={`${id}_error`} className="text-xs font-semibold text-danger-accent flex items-center gap-1 mt-0.5 animate-shake">
          ⚠️ {error}
        </span>
      )}
    </div>
  );
}

// ✅ DONE: src/components/ui/Input.jsx
