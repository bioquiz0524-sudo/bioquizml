// ✅ Zustand App UI Navigation and Toast Notification Store
import { create } from 'zustand';

export const useAppStore = create((set) => ({
  activeTab: 'dashboard', // matches active tab: 'dashboard' | 'flashcards' | 'profile' | 'admin'
  modals: {}, // map of { modalId: boolean }
  toast: null, // { message: string, type: 'success' | 'error' | 'info' | 'warning', duration?: number }

  setActiveTab: (tabName) => set({ activeTab: tabName }),

  // Custom toast notification trigger
  showToast: (message, type = 'success', duration = 3000) => {
    // Clear any existing active toast timeout first
    const currentToast = useAppStore.getState().toast;
    if (currentToast?.timeoutId) {
      clearTimeout(currentToast.timeoutId);
    }

    const timeoutId = setTimeout(() => {
      set({ toast: null });
    }, duration);

    set({
      toast: { message, type, timeoutId }
    });
  },

  hideToast: () => {
    const currentToast = useAppStore.getState().toast;
    if (currentToast?.timeoutId) {
      clearTimeout(currentToast.timeoutId);
    }
    set({ toast: null });
  },

  // Modal open / close helpers
  openModal: (modalId) => set((state) => ({
    modals: { ...state.modals, [modalId]: true }
  })),

  closeModal: (modalId) => set((state) => ({
    modals: { ...state.modals, [modalId]: false }
  })),

  toggleModal: (modalId) => set((state) => ({
    modals: { ...state.modals, [modalId]: !state.modals[modalId] }
  }))
}));

// ✅ DONE: src/store/useAppStore.js
