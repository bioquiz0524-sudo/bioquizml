// ✅ Top Sliding Ambient Toast Notification component
import React, { useEffect } from 'react';
import { useAppStore } from '../../store/useAppStore';
import { CheckCircle2, AlertTriangle, AlertCircle, Info, X } from 'lucide-react';

export default function Toast() {
  const { toast, hideToast } = useAppStore();

  if (!toast) return null;

  const { message, type } = toast;

  // Render icons corresponding to types
  const iconMap = {
    success: <CheckCircle2 className="w-5 h-5 text-primary-green" />,
    error: <AlertCircle className="w-5 h-5 text-danger-accent" />,
    warning: <AlertTriangle className="w-5 h-5 text-warning-accent" />,
    info: <Info className="w-5 h-5 text-blue-accent" />
  };

  const borderStyles = {
    success: 'border-primary-green/40 shadow-[0_4px_30px_rgba(0,230,118,0.15)]',
    error: 'border-danger-accent/40 shadow-[0_4px_30px_rgba(255,82,82,0.15)]',
    warning: 'border-warning-accent/40 shadow-[0_4px_30px_rgba(255,214,0,0.15)]',
    info: 'border-blue-accent/40 shadow-[0_4px_30px_rgba(0,188,212,0.15)]'
  };

  return (
    <div
      id="toast_container"
      className="fixed top-4 left-4 right-4 z-50 flex justify-center pointer-events-none animate-bounce-short"
    >
      <div
        id="toast_body"
        className={`glass-panel ${borderStyles[type || 'success']} flex items-center gap-3.5 px-4.5 py-4 w-full max-w-sm rounded-2xl pointer-events-auto shadow-2xl transition-all duration-300`}
      >
        <span id="toast_icon">{iconMap[type || 'success']}</span>
        <p id="toast_msg" className="text-white text-sm font-semibold flex-grow">{message}</p>
        <button
          id="toast_dismiss"
          onClick={hideToast}
          className="p-1 rounded-md text-text-secondary hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

// ✅ DONE: src/components/ui/Toast.jsx
