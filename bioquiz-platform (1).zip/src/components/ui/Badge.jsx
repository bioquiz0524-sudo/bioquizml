// ✅ Badging utilities for scores, level ratings and Pro tags
import React from 'react';

export default function Badge({
  id = `badge_${Math.random().toString(36).substr(2, 9)}`,
  children,
  variant = 'default', // 'default' | 'success' | 'warning' | 'danger' | 'pro' | 'blue'
  className = ''
}) {
  const baseStyles = 'inline-flex items-center px-2.5 py-1 text-xs font-bold font-mono uppercase tracking-wider rounded-full border select-none';

  const variantStyles = {
    default: 'bg-surface-1 border-border-subtle text-text-secondary',
    success: 'bg-[#a2714]/20 border-primary-green/30 text-primary-green',
    warning: 'bg-yellow-950/20 border-warning-accent/30 text-warning-accent',
    danger: 'bg-red-950/20 border-danger-accent/30 text-danger-accent',
    pro: 'bg-amber-950/45 border-pro-gold/40 text-pro-gold shadow-[0_0_10px_rgba(255,215,0,0.15)] pro-gold-glow',
    blue: 'bg-cyan-950/20 border-blue-accent/30 text-blue-accent'
  };

  return (
    <span id={id} className={`${baseStyles} ${variantStyles[variant]} ${className}`}>
      {children}
    </span>
  );
}

// ✅ DONE: src/components/ui/Badge.jsx
