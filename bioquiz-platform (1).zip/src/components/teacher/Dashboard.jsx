// ✅ Master Teacher Dashboard Workspace with interactive subtabs routing
import React, { useState } from 'react';
import { useAuthStore } from '../../store/useAuthStore';
import { useAppStore } from '../../store/useAppStore';
import { triggerHaptic } from '../../lib/telegramAuth';
import Card from '../ui/Card';
import Button from '../ui/Button';
import TestCreator from './TestCreator';
import GroupManager from './GroupManager';
import SessionManager from './SessionManager';
import LiveSession from './LiveSession';
import AnalysisBoard from './AnalysisBoard';
import { LayoutGrid, PlusCircle, Users2, PlayCircle, BarChart, GraduationCap, Coins } from 'lucide-react';

export default function TeacherDashboard() {
  const { profile } = useAuthStore();
  const { showToast, openModal } = useAppStore();

  const [activeSubTab, setActiveSubTab] = useState('overview'); // 'overview' | 'create' | 'groups' | 'kahoot' | 'analytics'
  
  // States of running Kahoot Match
  const [runningSession, setRunningSession] = useState(null);
  const [sessionStudents, setSessionStudents] = useState([]);

  const handleSubTabChange = (tabId) => {
    setActiveSubTab(tabId);
    triggerHaptic('light');
  };

  const handleStartLiveStatsView = (sessionObj, studentList) => {
    setRunningSession(sessionObj);
    setSessionStudents(studentList);
  };

  const handleEndLiveStatsView = () => {
    setRunningSession(null);
    setSessionStudents([]);
    setActiveSubTab('kahoot');
  };

  // If a live matchmaking game is ACTIVE, full screen takeover for real-time kahoot statistics!
  if (runningSession) {
    return (
      <div id="live_kahoot_takeover" className="w-full px-4 py-6 max-w-5xl mx-auto">
        <LiveSession
          session={runningSession}
          students={sessionStudents}
          onClose={handleEndLiveStatsView}
        />
      </div>
    );
  }

  const menuButtons = [
    { id: 'overview', label: 'Umumiy', icon: <LayoutGrid className="w-4 h-4" /> },
    { id: 'create', label: 'Test Tuzish', icon: <PlusCircle className="w-4 h-4" /> },
    { id: 'groups', label: 'Guruhlar', icon: <Users2 className="w-4 h-4" /> },
    { id: 'kahoot', label: 'Jonli Kahoot', icon: <PlayCircle className="w-4 h-4 text-primary-green animate-pulse" /> },
    { id: 'analytics', label: 'Statistika', icon: <BarChart className="w-4 h-4" /> }
  ];

  return (
    <div id="teacher_workspace_frame" className="w-full space-y-6 animate-fade-in pb-[90px]">
      
      {/* Dynamic profile card header with Wallet Balance recharge capabilities */}
      <Card variant="glass" className="p-5 border-primary-green/20">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="text-left space-y-1">
            <div className="flex items-center gap-2">
              <span className="p-1 rounded-md bg-primary-green/10 text-primary-green"><GraduationCap className="w-5 h-5" /></span>
              <p className="text-xs font-mono text-text-secondary uppercase">USTOZ PORTALI</p>
            </div>
            <h2 className="text-2xl font-black text-white">{profile?.full_name}</h2>
            <p className="text-xs text-text-secondary">O'quv maskani: <strong>{profile?.learning_center || 'Biriktirilmagan'}</strong></p>
          </div>

          <div
            onClick={() => openModal('refill_balance_modal')}
            className="flex items-center gap-2.5 bg-surface-2 border border-border-subtle hover:border-primary-green rounded-xl p-3 cursor-pointer transition-all active:scale-95 text-right w-full sm:w-auto sm:ml-auto max-w-sm justify-between sm:justify-end"
          >
            <Coins className="w-5 h-5 text-primary-green" />
            <div>
              <p className="text-[8px] font-bold text-text-secondary uppercase">USTOZ BALANSI</p>
              <p className="text-sm font-bold font-mono text-white">{profile?.wallet_balance?.toLocaleString() || 0} UZS</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Sub menu controls */}
      <div id="teacher_nested_nav" className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1 text-left border-b border-border-subtle/50">
        {menuButtons.map((btn) => {
          const isSelected = activeSubTab === btn.id;
          return (
            <button
              id={`subtab_${btn.id}`}
              key={btn.id}
              onClick={() => handleSubTabChange(btn.id)}
              className={`flex items-center gap-1.5 px-4.5 py-3 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer select-none
              ${isSelected ? 'bg-primary-green text-[#020c07] shadow-lg shadow-primary-green/20' : 'bg-surface-2 text-text-secondary border border-border-subtle/50 hover:text-white'}`}
            >
              {btn.icon}
              <span>{btn.label}</span>
            </button>
          );
        })}
      </div>

      {/* Dynamic View portals layout */}
      <div id="subtab_render_area" className="w-full">
        
        {/* TAB 1: OVERVIEW */}
        {activeSubTab === 'overview' && (
          <div className="space-y-6 animate-fade-in text-left">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              
              {/* Quick test creator helper card */}
              <Card variant="glass" className="p-5 space-y-4 border-border-subtle flex flex-col justify-between">
                <div className="space-y-1.5">
                  <h4 className="font-extrabold text-[#E8F5E9] text-base">Savollarni daxshatli oson tuzish</h4>
                  <p className="text-xs text-text-secondary">
                    Hujjat yuklang va sun'iy intellekt (OCR) yordamida soniyalar ichida testlar hosil qiling.
                  </p>
                </div>
                <Button variant="primary" size="md" className="w-full mt-4" onClick={() => handleSubTabChange('create')}>
                  Test Yaratish
                </Button>
              </Card>

              {/* Quick live session match launcher card */}
              <Card variant="glass" className="p-5 space-y-4 border-border-subtle flex flex-col justify-between">
                <div className="space-y-1.5">
                  <h4 className="font-extrabold text-[#E8F5E9] text-base">Jonli dars o'yini tashkil etish</h4>
                  <p className="text-xs text-text-secondary">
                    Guruhlarni jonli bellashuv (Kahoot) rejimiga chaqiring va o'quvchilar javoblarini reaktiv kuzating.
                  </p>
                </div>
                <Button variant="secondary" size="md" className="w-full mt-4" onClick={() => handleSubTabChange('kahoot')}>
                  Kahoot Boshlash
                </Button>
              </Card>
            </div>

            {/* Quick overview welcome details info */}
            <Card variant="glass" className="p-5 space-y-3.5 border-border-subtle">
              <h4 className="font-extrabold text-white text-sm">O'qituvchi yo'riqnomasi</h4>
              <p className="text-xs text-text-secondary leading-relaxed">
                Platformamiz orqali biologiya darsingizni mutlaqo yangi darajaga olib chiqing: <br />
                🌱 <strong>Sinf Guruhlari:</strong> Guruh oching va o'quvchilarga taklif havolasini Telegram orqali yuboring. <br />
                📚 <strong>Imtihonlar:</strong> Savollar tuzgach uchrashuv darslariga tayyorlanasiz. <br />
                🌲 <strong>Tahlillar:</strong> Tahlil bo'limidan sinfda o'xtalish bo'layotgan eng qiyin mavzular ko'rsatkisini ko'rib, o'quvchilar isboti uchun taklif daryolari Flashcard qabul qiling.
              </p>
            </Card>
          </div>
        )}

        {/* TAB 2: CREATE TEST */}
        {activeSubTab === 'create' && (
          <TestCreator onCreationComplete={() => handleSubTabChange('overview')} />
        )}

        {/* TAB 3: GROUPS LIST */}
        {activeSubTab === 'groups' && (
          <GroupManager />
        )}

        {/* TAB 4: KAHOOT LIVE GAME */}
        {activeSubTab === 'kahoot' && (
          <SessionManager onStartLiveStats={handleStartLiveStatsView} />
        )}

        {/* TAB 5: ANALYTICS BOARD */}
        {activeSubTab === 'analytics' && (
          <AnalysisBoard />
        )}

      </div>

    </div>
  );
}

// ✅ DONE: src/components/teacher/Dashboard.jsx
