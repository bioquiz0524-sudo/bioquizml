// ✅ Custom CSS Glassmorphism Card components with active status and hover glows
import React from 'react';

export default function Card({
  id = `card_${Math.random().toString(36).substr(2, 9)}`,
  children,
  onClick = undefined,
  variant = 'default', // 'default' | 'glass' | 'interactive' | 'active'
  className = '',
  ...props
}) {
  const isClickable = !!onClick;
  
  const baseStyles = 'rounded-2xl transition-all duration-250 ease-out p-5 overflow-hidden';
  
  const variantStyles = {
    default: 'bg-card-bg border border-border-subtle text-text-primary',
    glass: 'glass-panel text-text-primary',
    interactive: 'glass-panel text-text-primary hover:bg-card-hover hover:border-primary-green/50 hover:shadow-[0_0_15px_rgba(0,230,118,0.12)] cursor-pointer active:scale-99',
    active: 'bg-[#a2714]/30 border-2 border-primary-green text-text-primary shadow-[0_0_20px_rgba(0,230,118,0.15)] glow-green'
  };

  return (
    <div
      id={id}
      onClick={isClickable && !onClick.disabled ? onClick : undefined}
      className={`${baseStyles} ${variantStyles[variant]} ${isClickable ? 'cursor-pointer' : ''} ${className}`}
      {...props}
    >
      {children}
    </div>
  );
}

// ✅ DONE: src/components/ui/Card.jsx
