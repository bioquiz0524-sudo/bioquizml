// ✅ Kahoot-style Live Session Match initializer with PIN generator
import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabaseClient';
import { useAppStore } from '../../store/useAppStore';
import { useAuthStore } from '../../store/useAuthStore';
import { triggerHaptic } from '../../lib/telegramAuth';
import Button from '../ui/Button';
import Card from '../ui/Card';
import { Play, QrCode, Share2, Users, Rocket, Sparkles, BookOpen } from 'lucide-react';

export default function SessionManager({ onStartLiveStats }) {
  const { profile } = useAuthStore();
  const { showToast } = useAppStore();

  const [activeTests, setActiveTests] = useState([]);
  const [selectedTestId, setSelectedTestId] = useState('');
  const [createdSession, setCreatedSession] = useState(null);
  const [joinedStudents, setJoinedStudents] = useState([]);
  const [isRunning, setIsRunning] = useState(false);

  useEffect(() => {
    loadActiveTests();
  }, []);

  const loadActiveTests = async () => {
    try {
      const { data } = await supabase.from('tests').select('*').eq('status', 'active');
      if (data) {
        setActiveTests(data);
        if (data.length > 0) setSelectedTestId(data[0].id);
      }
    } catch (e) {
      console.error("Test load error in manager", e);
    }
  };

  // Generate randomized PIN code: BIO-XXXX
  const handleCreateSession = async () => {
    if (!selectedTestId) {
      showToast("Iltimos, avval jonli o'tkaziladigan testni tanlang!", "warning");
      return;
    }

    triggerHaptic('light');
    const randomCodeRange = Math.floor(1000 + Math.random() * 9000);
    const sessionPin = `BIO-${randomCodeRange}`;

    try {
      const matchedTest = activeTests.find(t => t.id === selectedTestId);
      
      const newSessionObj = {
        code: sessionPin,
        test_id: selectedTestId,
        teacher_id: profile.id,
        center_name: matchedTest?.center_name || profile.learning_center || 'BioQuiz',
        status: 'waiting'
      };

      const { data, error } = await supabase
        .from('sessions')
        .insert(newSessionObj)
        .select()
        .single();

      if (error) throw error;

      setCreatedSession(data);
      setJoinedStudents([]);
      showToast(`Sessiya muvaffaqiyatli tashkil qilindi! Kod: ${sessionPin}`, "success");
      
      // Simulate real-time student joins for the teacher preview iframe
      simulateStudentJoins(data.id);
    } catch (err) {
      showToast("Jonli sessiya boshlashda xatolik yuz berdi.", "error");
    }
  };

  // High-fidelity student join simulator so the teacher can see how Supabase Realtime renders users joining!
  const simulateStudentJoins = (sessionId) => {
    const mockJoinNames = [
      'Jasur Karimov', 'Malika Aliyeva', 'Temur Hasanov', 
      'Otabek Solihov', 'Rayhona Abdullayeva', 'Sardor Yo\'ldoshev',
      'Kamola Tojiyeva', 'Abdurahmon Mo\'minov'
    ];
    let index = 0;

    const interval = setInterval(async () => {
      if (index >= mockJoinNames.length) {
        clearInterval(interval);
        return;
      }

      const freshStudentName = mockJoinNames[index];
      
      const stObj = {
        id: `sim_stud_${index + 1}`,
        full_name: freshStudentName,
        telegram_id: 300000 + index,
        role: 'student'
      };

      // Push into state list and trigger a haptic
      setJoinedStudents(prev => {
        const has = prev.some(p => p.full_name === freshStudentName);
        if (has) return prev;
        
        triggerHaptic('light');
        return [...prev, stObj];
      });

      index++;
    }, 1500); // add another student every 1.5 seconds
  };

  const handleLaunchMatch = () => {
    if (!createdSession) return;
    triggerHaptic('success');
    
    // Set status to active in database
    supabase.from('sessions').update({ status: 'active', started_at: new Date().toISOString() }).eq('id', createdSession.id);
    
    showToast("Jonli test boshlandi!", "success");

    // Route to active stats dashboard
    if (onStartLiveStats) {
      onStartLiveStats(createdSession, joinedStudents);
    }
  };

  return (
    <div id="session_manager_box" className="w-full space-y-6 animate-fade-in text-left">
      
      {/* Intro descriptive header */}
      <div className="text-left space-y-1">
        <h3 className="text-xl font-extrabold text-white">Jonli Kahoot-sinf darslari</h3>
        <p className="text-xs text-text-secondary">
          Hozirgi vaqtda butun sinf bilan birgalikda, real vaqt rejimida biologiya musobaqasini tashkil eting!
        </p>
      </div>

      {!createdSession ? (
        // 1. Selector Test Layout
        <Card variant="glass" className="p-5 space-y-5 border-primary-green/20">
          <div className="flex items-center gap-3.5 border-b border-border-subtle pb-3.5">
            <div className="p-2.5 rounded-lg bg-primary-green/10 text-primary-green">
              <BookOpen className="w-5 h-5" />
            </div>
            <div className="text-left">
              <h4 className="font-extrabold text-white text-sm">Jonli mavzuni tanlash</h4>
              <p className="text-xs text-text-secondary">Bellashuv o'tkaziladigan imtihon savollar bazasini belgilang</p>
            </div>
          </div>

          {activeTests.length === 0 ? (
            <p className="text-xs text-text-secondary italic">Sizda faol testlar topilmadi. Avval test yarating.</p>
          ) : (
            <div className="space-y-4">
              <div className="flex flex-col gap-1.5">
                <label className="text-[10px] font-bold font-mono tracking-wider text-text-secondary uppercase">Mavjud testlaringiz</label>
                <select
                  value={selectedTestId}
                  onChange={(e) => setSelectedTestId(e.target.value)}
                  className="w-full bg-surface-1 border border-border-subtle text-text-primary rounded-xl px-4 py-3 text-sm focus:border-primary-green outline-none font-semibold cursor-pointer min-h-[48px]"
                >
                  {activeTests.map((t) => (
                    <option key={t.id} value={t.id} className="bg-surface-1 text-white font-medium">{t.title} ({t.question_count} ta savol)</option>
                  ))}
                </select>
              </div>

              <Button variant="primary" className="w-full glow-green font-black gap-2" onClick={handleCreateSession} icon={<QrCode className="w-5 h-5" />}>
                Jonli sessiya xonasini ochish
              </Button>
            </div>
          )}
        </Card>
      ) : (
        // 2. Waiting Lobby Layout inside QR Banner
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* PIN Card information */}
          <Card variant="active" className="p-6 text-center space-y-6 md:col-span-1 border-primary-green glow-green flex flex-col justify-center">
            <div className="space-y-1">
              <span className="text-[10px] font-mono tracking-widest text-[#69F0AE] uppercase text-semibold bg-primary-green/15 px-3 py-1 rounded-full">SINF XONASI PIN</span>
              <h2 className="text-4xl font-black font-mono tracking-widest text-white text-glow mt-2">{createdSession.code}</h2>
            </div>

            {/* Simulative QR Code representing premium Kahoot experience */}
            <div className="w-32 h-32 rounded-2xl bg-white border-4 border-primary-green flex items-center justify-center p-2 mx-auto shadow-xl">
              <svg className="w-full h-full text-bg" viewBox="0 0 100 100" fill="currentColor">
                <rect x="10" y="10" width="25" height="25" />
                <rect x="65" y="10" width="25" height="25" />
                <rect x="10" y="65" width="25" height="25" />
                <rect x="15" y="15" width="15" height="15" fill="white" />
                <rect x="70" y="15" width="15" height="15" fill="white" />
                <rect x="15" y="70" width="15" height="15" fill="white" />
                <rect x="42" y="10" width="16" height="40" />
                <rect x="65" y="42" width="25" height="16" />
                <rect x="10" y="42" width="25" height="16" />
                <rect x="42" y="60" width="40" height="25" />
              </svg>
            </div>

            <p className="text-[10px] text-text-secondary leading-relaxed">
              O'quvchilar ushbu dars kodini kiriting yoki link orqali ulaning: <br />
              <strong className="text-primary-green">https://t.me/bioquiz_bot?start={createdSession.code}</strong>
            </p>
          </Card>

          {/* Joined Students list */}
          <Card variant="glass" className="p-6 space-y-5 md:col-span-2 border-border-subtle flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between border-b border-border-subtle pb-3.5">
                <h4 className="font-extrabold text-white text-base flex items-center gap-2">
                  <Users className="w-5 h-5 text-primary-green" /> O'quvchilar ulanmoqda...
                </h4>
                <div className="bg-surface-2 px-3 py-1.5 rounded-lg text-xs font-black font-mono text-[#00E676] tracking-wide animate-pulse-glow">
                  {joinedStudents.length} TA ULANGAN
                </div>
              </div>

              {joinedStudents.length === 0 ? (
                <div className="text-center py-12 text-text-secondary space-y-2">
                  <div className="w-8 h-8 rounded-full bg-surface-2 border border-border-subtle border-t-primary-green animate-spin mx-auto" />
                  <p className="text-xs">Ulamovchilarni kutilmoqda...</p>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-h-[220px] overflow-y-auto no-scrollbar">
                  {joinedStudents.map((st, i) => (
                    <div
                      key={st.id}
                      className="bg-surface-2 border border-primary-green/20 rounded-xl px-3 py-2.5 text-center text-xs font-bold text-white shadow-md animate-scale-in"
                    >
                      🌱 {st.full_name}
                    </div>
                  ))}
                </div>
              )}
            </div>

            <Button
              variant="primary"
              disabled={joinedStudents.length === 0}
              size="lg"
              className="w-full flex items-center justify-center gap-2 glow-green font-black mt-4"
              onClick={handleLaunchMatch}
              icon={<Rocket className="w-5 h-5" />}
            >
              Testni daxshatli tarzda boshlash!
            </Button>
          </Card>
        </div>
      )}

    </div>
  );
}

// ✅ DONE: src/components/teacher/SessionManager.jsx
