// ✅ Question Illustration Mapper with Drag/Drop image uploader
import React, { useState } from 'react';
import { useAppStore } from '../../store/useAppStore';
import { triggerHaptic } from '../../lib/telegramAuth';
import Button from '../ui/Button';
import Card from '../ui/Card';
import Input from '../ui/Input';
import { ImagePlus, Link2, Trash2, Check, CheckSquare } from 'lucide-react';

export default function ImageMapper({ questions, onMappingComplete }) {
  const { showToast } = useAppStore();
  const [targetIndex, setTargetIndex] = useState('1');
  const [imageFileUrl, setImageFileUrl] = useState('');
  const [mappedList, setMappedList] = useState({}); // map of { questionIndex: imageUrl }

  const handleDragMockFile = (e) => {
    e.preventDefault();
  };

  const handleImageFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      // Simulate database upload of illustration
      const tempUrl = URL.createObjectURL(file);
      setImageFileUrl(tempUrl);
      showToast("Rasm yuklandi. Endi savol raqamini kiriting va Qo'shishni bosing.", "info");
      triggerHaptic('light');
    }
  };

  const handleAddMap = () => {
    const idx = parseInt(targetIndex);
    if (!imageFileUrl) {
      showToast("Iltimos, avval rasm tanlang!", "warning");
      return;
    }
    if (isNaN(idx) || idx < 1 || idx > questions.length) {
      showToast(`Noto'g'ri tartib raqami. Savollar soni jami ${questions.length} ta.`, "error");
      return;
    }

    setMappedList({
      ...mappedList,
      [idx]: imageFileUrl
    });

    setImageFileUrl('');
    setTargetIndex((idx + 1).toString()); // increment index automatically for teacher speed!
    showToast(`${idx}-savolga rasm biriktirildi!`, "success");
    triggerHaptic('success');
  };

  const handleRemoveMap = (idx) => {
    const fresh = { ...mappedList };
    delete fresh[idx];
    setMappedList(fresh);
    triggerHaptic('error');
  };

  const handleFinish = () => {
    triggerHaptic('success');
    if (onMappingComplete) {
      onMappingComplete(mappedList);
    }
  };

  return (
    <div id="image_mapper_view" className="w-full space-y-5">
      
      {/* Informative description block */}
      <div className="text-left space-y-1">
        <h4 className="font-extrabold text-white text-base">Savollarga biologik rasm qo'shish</h4>
        <p className="text-xs text-text-secondary">
          Testingizda darslik chizmalari, mikroskop suratlari yoki jadvallari bo'lsa, ularni nechanchi savolga biriktirishni belgilang.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Upload tool panel card */}
        <Card variant="glass" className="p-4 space-y-4">
          <label
            onDragOver={handleDragMockFile}
            className="flex flex-col items-center justify-center border border-dashed border-border-subtle hover:border-primary-green rounded-xl p-6 bg-surface-1/40 hover:bg-surface-2 transition-all cursor-pointer h-32 text-center"
          >
            <input type="file" accept="image/*" onChange={handleImageFileChange} className="hidden" />
            {imageFileUrl ? (
              <div className="relative h-20 w-32 rounded overflow-hidden border border-border-active">
                <img src={imageFileUrl} alt="Illustration upload" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-[#020c07]/50 flex items-center justify-center text-[10px] text-white">Rasm yuklandi</div>
              </div>
            ) : (
              <div className="space-y-1 text-text-secondary">
                <ImagePlus className="w-8 h-8 mx-auto" />
                <p className="text-xs">Rasm tanlash uchun bosing</p>
              </div>
            )}
          </label>

          <div className="flex items-end gap-3">
            <Input
              type="number"
              label="Savol tartib raqami"
              placeholder="Masalan: 1, 2, 3"
              value={targetIndex}
              onChange={(e) => setTargetIndex(e.target.value)}
              className="flex-grow"
            />
            <Button variant="primary" className="h-[48px]" onClick={handleAddMap}>
              Qo'shish
            </Button>
          </div>
        </Card>

        {/* Current list of attached illustrations */}
        <Card variant="glass" className="p-4 space-y-3.5 flex flex-col justify-between max-h-[200px] overflow-y-auto no-scrollbar">
          <p className="text-[10px] font-mono tracking-wider text-text-muted uppercase text-left border-b border-border-subtle pb-1.5 flex items-center gap-1.5">
            <CheckSquare className="w-3.5 h-3.5 text-primary-green" /> Biriktirilgan suratlar ro'yxati
          </p>

          {Object.keys(mappedList).length === 0 ? (
            <p className="text-xs text-text-secondary italic text-center py-6">Hali hech bir savolga surat biriktirilmagan.</p>
          ) : (
            <div className="space-y-2">
              {Object.keys(mappedList).map((idx) => (
                <div key={idx} className="flex items-center justify-between bg-surface-2 p-2 rounded-lg border border-border-subtle">
                  <span className="text-xs font-semibold text-white flex items-center gap-2">
                    <Link2 className="w-3.5 h-3.5 text-primary-green" /> {idx}-savolga rasm ulandi
                  </span>
                  <button
                    onClick={() => handleRemoveMap(idx)}
                    className="p-1 rounded text-text-muted hover:text-danger-accent transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>

      <footer className="pt-2 flex justify-end">
        <Button variant="secondary" className="px-8" onClick={handleFinish}>
          Tasdiqlash va Keyingisi
        </Button>
      </footer>
    </div>
  );
}

// ✅ DONE: src/components/teacher/ImageMapper.jsx
