// ✅ 4-step Interactive AI-based Test Creator Wizard
import React, { useState } from 'react';
import { supabase } from '../../lib/supabaseClient';
import { useAuthStore } from '../../store/useAuthStore';
import { useAppStore } from '../../store/useAppStore';
import { triggerHaptic } from '../../lib/telegramAuth';
import Button from '../ui/Button';
import Card from '../ui/Card';
import Input from '../ui/Input';
import OCRUploader from './OCRUploader';
import ImageMapper from './ImageMapper';
import TestPreview from './TestPreview';
import { Sparkles, FileText, ImageIcon, CheckSquare, Layers, Lock, Unlock } from 'lucide-react';

export default function TestCreator({ onCreationComplete }) {
  const { profile } = useAuthStore();
  const { showToast } = useAppStore();

  const [creationMethod, setCreationMethod] = useState(null); // null | 'existing' | 'new'
  const [existingTests, setExistingTests] = useState([]);
  const [loadingExisting, setLoadingExisting] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const [wizardStep, setWizardStep] = useState(1);
  const [submitting, setSubmitting] = useState(false);

  // Step 1: Metadata
  const [testTitle, setTestTitle] = useState('');
  const [testGrade, setTestGrade] = useState('10-sinf');
  const [testLimit, setTestLimit] = useState('20'); // minutes
  const [testDifficulty, setTestDifficulty] = useState('o_rta');
  const [isPremium, setIsPremium] = useState(false);
  const [testPrice, setTestPrice] = useState('25000'); // Sum. co'm fallback

  // Step 2 & 3 & 4 data states
  const [questionsDeck, setQuestionsDeck] = useState([]);

  const loadExistingTests = async () => {
    setLoadingExisting(true);
    try {
      const { data, error } = await supabase
        .from('tests')
        .select('*')
        .order('created_at', { ascending: false });
      if (data) {
        setExistingTests(data);
      }
    } catch (err) {
      console.error("Xatolik mavjud testlarni yuklashda:", err);
      showToast("Mavjud testlarni yuklashda xatolik yuz berdi.", "error");
    } finally {
      setLoadingExisting(false);
    }
  };

  const handleSelectExistingTest = async (test) => {
    triggerHaptic('light');
    showToast("Savollar yuklanmoqda...", "info");
    try {
      const { data, error } = await supabase
        .from('questions')
        .select('*')
        .eq('test_id', test.id)
        .order('order_number', { ascending: true });
      
      if (error) throw error;

      if (!data || data.length === 0) {
        showToast("Tanlangan testda bironta ham savol topilmadi!", "warning");
        return;
      }

      // Format questions for preview/editing
      const formattedQs = data.map((q) => ({
        question_text: q.question_text || q.text,
        options: q.options || ['', '', '', ''],
        correct_index: q.correct_index !== undefined ? q.correct_index : 0,
        topic: q.topic || 'Biologiya',
        image_url: q.image_url || null
      }));

      setQuestionsDeck(formattedQs);
      setTestTitle(`Nusxa: ${test.title}`);
      setTestGrade(test.grade || '10-sinf');
      setTestLimit(String(test.time_limit || 20));
      setTestDifficulty(test.difficulty || 'o_rta');
      setIsPremium(test.is_premium || false);
      setTestPrice(String(test.price || 25000));

      setCreationMethod('new');
      setWizardStep(4); // Jump directly to verification/checks step as requested!
      showToast("Test savollari yuklandi! Tahrirlashingiz, tekshirishingiz va saqlashingiz mumkin.", "success");
    } catch (err) {
      console.error(err);
      showToast("Savollarni ko'chirishda xatolik yuz berdi.", "error");
    }
  };

  const handleNextWizardStep = () => {
    triggerHaptic('light');

    if (wizardStep === 1) {
      if (!testTitle.trim()) {
        showToast("Iltimos, test sarlavhasini kiriting!", "warning");
        return;
      }
      setWizardStep(2);
    } else if (wizardStep === 2) {
      if (questionsDeck.length === 0) {
        showToast("Iltimos, kamida bitta savol qo'shing yoki OCR orqali yuklang!", "warning");
        return;
      }
      setWizardStep(3);
    } else if (wizardStep === 3) {
      setWizardStep(4);
    }
  };

  const handlePrevWizardStep = () => {
    triggerHaptic('light');
    if (wizardStep === 1) {
      setCreationMethod(null);
    } else {
      setWizardStep(wizardStep - 1);
    }
  };

  // Callback once OCR finishes scanning
  const handleOcrExtraction = (extractedQuestions) => {
    setQuestionsDeck(extractedQuestions);
    setWizardStep(4); // jump directly to Preview edits for maximum educator comfort!
  };

  // Callback once Image Mapper completing linkage
  const handleImageMappingResult = (mappedObject) => {
    const updatedQs = [...questionsDeck];
    Object.keys(mappedObject).forEach((idxStr) => {
      const idx = parseInt(idxStr) - 1;
      if (updatedQs[idx]) {
        updatedQs[idx].image_url = mappedObject[idxStr];
      }
    });
    setQuestionsDeck(updatedQs);
    setWizardStep(4);
  };

  // Save full test to Supabase
  const handleFinalSave = async (finalQuestions) => {
    setSubmitting(true);
    triggerHaptic('success');
    showToast("Test bazaga saqlanmoqda...", "info");

    try {
      // 1. Post to 'tests' table
      const testRecord = {
        title: testTitle.trim(),
        teacher_id: profile.id,
        center_name: profile.learning_center || 'BioQuiz',
        time_limit: parseInt(testLimit) || 20,
        grade: testGrade,
        difficulty: testDifficulty,
        is_premium: isPremium,
        price: isPremium ? (parseInt(testPrice) || 25000) : 0,
        question_count: finalQuestions.length,
        status: 'active'
      };

      const { data: newTest, error: testErr } = await supabase
        .from('tests')
        .insert(testRecord)
        .select()
        .single();

      if (testErr) throw testErr;

      // 2. Post all questions list to 'questions' table
      const questionsToInsert = finalQuestions.map((q, qIndex) => ({
        test_id: newTest.id,
        order_number: qIndex + 1,
        question_text: q.question_text || q.text,
        options: q.options,
        correct_index: q.correct_index,
        topic: q.topic || 'Biologiya',
        difficulty: testDifficulty,
        image_url: q.image_url || null
      }));

      const { error: qsErr } = await supabase.from('questions').insert(questionsToInsert);
      if (qsErr) throw qsErr;

      showToast(`"${testTitle}" imtihoni muvaffaqiyatli saqlandi!`, "success");
      
      if (onCreationComplete) {
        onCreationComplete();
      }
    } catch (err) {
      console.error(err);
      showToast("Testni saqlashda muammo yuz berdi. Qayta urinib ko'ring.", "error");
    } finally {
      setSubmitting(false);
    }
  };

  // 1. CHOOSE CREATION METHOD SCREEN (Landing)
  if (!creationMethod) {
    return (
      <div id="test_creation_landing" className="w-full space-y-6 animate-fade-in text-left pb-[60px]">
        <Card variant="glass" className="p-6 border-primary-green/20">
          <div className="text-center max-w-xl mx-auto space-y-3 py-4">
            <h3 className="text-xl font-extrabold text-white">Yangi Imtihon Tuzish Rejimi</h3>
            <p className="text-xs text-text-secondary leading-relaxed">
              Biologiya bo'yicha imtihonlarni tayyorlashning eng ilg'or usullaridan foydalaning. 
              Mavjud bazadagi testlardan nusxa ko'chirib yangi test taxlash yoki mutlaqo yangidan boshlashni tanlang.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mt-6">
            {/* Card 1: Copy from existing database tests */}
            <div
              id="select_method_existing"
              onClick={() => {
                setCreationMethod('existing');
                loadExistingTests();
                triggerHaptic('light');
              }}
              className="bg-surface-2/60 hover:bg-surface-2 border border-border-subtle hover:border-primary-green p-6 rounded-2xl flex flex-col justify-between cursor-pointer transition-all hover:scale-[1.02] duration-200 outline-none group text-left min-h-[170px]"
            >
              <div className="space-y-3.5">
                <div className="w-12 h-12 rounded-xl bg-primary-green/10 flex items-center justify-center text-primary-green group-hover:scale-110 duration-200">
                  <Layers className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-extrabold text-white text-base">Mavjud testlardan nusxa olish (Taxlash)</h4>
                  <p className="text-xs text-text-secondary mt-1">
                    Bazada bor bo'lgan va avval yuklangan darslik testlaridan nusxa ko'chirib, o'zgartirgan holda yangi testlar tuzish.
                  </p>
                </div>
              </div>
            </div>

            {/* Card 2: Create a brand new test */}
            <div
              id="select_method_new"
              onClick={() => {
                setCreationMethod('new');
                setWizardStep(1);
                triggerHaptic('light');
              }}
              className="bg-surface-2/60 hover:bg-surface-2 border border-border-subtle hover:border-primary-cyan p-6 rounded-2xl flex flex-col justify-between cursor-pointer transition-all hover:scale-[1.02] duration-200 outline-none group text-left min-h-[170px]"
            >
              <div className="space-y-3.5">
                <div className="w-12 h-12 rounded-xl bg-primary-cyan/10 flex items-center justify-center text-primary-cyan group-hover:scale-110 duration-200">
                  <Sparkles className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-extrabold text-white text-base">Mutlaqo yangi test yaratish</h4>
                  <p className="text-xs text-text-secondary mt-1">
                    Hujjat yuklash (AI OCR), qo'lda to'ldirish, savollarga rasm qo'shish va ulashishdan oldin tekshirish sehrgari.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  // 2. CHOOSE EXISTING TEST FROM DATABASE SCREEN
  if (creationMethod === 'existing') {
    const filteredTests = existingTests.filter(t => 
      t.title.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return (
      <div id="existing_tests_selector_window" className="w-full space-y-6 animate-fade-in text-left pb-[60px]">
        <Card variant="glass" className="p-5 border-primary-green/20">
          <div className="flex items-center justify-between border-b border-border-subtle pb-4">
            <div>
              <h3 className="text-lg font-extrabold text-white">Bazada bor bo'lgan testlar ro'yxati</h3>
              <p className="text-xs text-text-secondary">Nusxa ko'chirib, o'zgartirish uchun kerakli darslikni tanlang</p>
            </div>
            <Button variant="glass" size="sm" onClick={() => setCreationMethod(null)}>
              Orqaga
            </Button>
          </div>

          <div className="mt-4">
            <Input
              placeholder="Test nomini qidirish..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          {loadingExisting ? (
            <div className="text-center py-12">
              <div className="w-8 h-8 rounded-full border-t-2 border-primary-green animate-spin mx-auto mb-4" />
              <p className="text-xs text-text-secondary">Faol testlar daryosi o'qilmoqda...</p>
            </div>
          ) : filteredTests.length === 0 ? (
            <div className="text-center py-12 italic text-xs text-text-secondary bg-surface-1 rounded-2xl border border-border-subtle">
              Hech qanday darslik yoki o'qitilgan testlar topilmadi.
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4 max-h-[400px] overflow-y-auto no-scrollbar pr-1">
              {filteredTests.map((test) => (
                <div
                  key={test.id}
                  className="bg-surface-2 border border-border-subtle rounded-2xl p-4 flex flex-col justify-between gap-3 text-left hover:border-primary-green/40 duration-200"
                >
                  <div>
                    <span className="text-[9px] font-mono bg-surface-1 px-2 py-0.5 rounded text-text-muted font-bold uppercase">{test.grade || '10-sinf'}</span>
                    <h4 className="font-extrabold text-white text-sm mt-1">{test.title}</h4>
                    <p className="text-text-secondary text-[10px] mt-1">Savollar: <strong className="font-mono text-primary-cyan">{test.question_count} ta</strong> · Vaqt: <strong className="font-mono">{test.time_limit} m</strong></p>
                  </div>
                  <Button
                    variant="primary"
                    size="sm"
                    className="w-full uppercase text-[10px] font-mono tracking-wider font-extrabold mt-1"
                    onClick={() => handleSelectExistingTest(test)}
                  >
                    Ushbu testdan nusxa olish
                  </Button>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    );
  }

  // 3. FULL SEAMLESS WIZARD STEP LAYOUTS (for creating new test, or editing copied tests)
  return (
    <div id="test_creator_wizard" className="w-full space-y-6 animate-fade-in text-left pb-[60px]">
      
      {/* Step guide Header bar */}
      <Card variant="glass" className="py-4 px-5 border-primary-green/20">
        <div className="flex items-center justify-between">
          <div className="text-left">
            <h3 className="text-lg font-extrabold text-white">Yangi imtihon tuzish</h3>
            <p className="text-xs text-text-secondary">AI va OCR yordamida tezkor savollar tuzish sehrgari</p>
          </div>
          
          <div className="flex gap-1.5 items-center bg-surface-2 p-1.5 rounded-xl border border-border-subtle">
            {[
              { s: 1, icon: <Layers className="w-3.5 h-3.5" /> },
              { s: 2, icon: <FileText className="w-3.5 h-3.5" /> },
              { s: 3, icon: <ImageIcon className="w-3.5 h-3.5" /> },
              { s: 4, icon: <CheckSquare className="w-3.5 h-3.5" /> }
            ].map((stepObj) => (
              <div
                key={stepObj.s}
                className={`w-7 h-7 rounded-lg flex items-center justify-center transition-all
                ${wizardStep === stepObj.s 
                  ? 'bg-primary-green text-[#020c07] font-black' 
                  : 'bg-transparent text-text-muted hover:text-white'}`}
              >
                {stepObj.icon}
              </div>
            ))}
          </div>
        </div>
      </Card>

      {/* STEP 1: Metadata setup */}
      {wizardStep === 1 && (
        <Card variant="glass" className="p-6 space-y-5 border-border-subtle animate-fade-in">
          <h4 className="text-sm font-black text-white border-b border-border-subtle pb-2 uppercase tracking-wide">1-Bosqich: Imtihon tafsilotlari</h4>
          
          <div className="space-y-4">
            <Input
              label="Test sarlavhasi (Mavzu)"
              placeholder="Masalan: Mitoz va Meyoz bo'linish, Asab tizimi..."
              value={testTitle}
              onChange={(e) => setTestTitle(e.target.value)}
              required
            />

            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold font-mono uppercase tracking-wider text-text-secondary">Mo'ljallangan sinf</label>
                <select
                  value={testGrade}
                  onChange={(e) => setTestGrade(e.target.value)}
                  className="w-full bg-surface-1 border border-border-subtle focus:border-primary-green rounded-xl px-4 py-3 text-sm text-white font-semibold outline-none cursor-pointer"
                >
                  <option value="9-sinf">9-sinf darsligi</option>
                  <option value="10-sinf">10-sinf darsligi</option>
                  <option value="11-sinf">11-sinf darsligi</option>
                  <option value="Aralash">Aralash / Blok testlar</option>
                </select>
              </div>

              <Input
                type="number"
                label="Vaqt limiti (Daqiqa)"
                placeholder="20"
                value={testLimit}
                onChange={(e) => setTestLimit(e.target.value)}
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold font-mono uppercase tracking-wider text-text-secondary">Qiyinchilik darajasi</label>
                <select
                  value={testDifficulty}
                  onChange={(e) => setTestDifficulty(e.target.value)}
                  className="w-full bg-surface-1 border border-border-subtle focus:border-primary-green rounded-xl px-4 py-3 text-sm text-white font-semibold outline-none cursor-pointer"
                >
                  <option value="oson">🌱 Oson jamoa</option>
                  <option value="o_rta">🌿 O'rta barqaror</option>
                  <option value="qiyin">🌲 Qiyin olim</option>
                </select>
              </div>

              {/* Free vs Premium Pricing locks card toggle */}
              <div className="flex flex-col gap-1.5">
                <label className="text-xs font-bold font-mono uppercase tracking-wider text-text-secondary">Premium (Pullik) test</label>
                <div
                  onClick={() => { setIsPremium(!isPremium); triggerHaptic('light'); }}
                  className={`flex items-center justify-between rounded-xl border px-4 py-3 text-sm font-semibold transition-all cursor-pointer select-none
                  ${isPremium ? 'border-amber-400 bg-amber-400/5 text-amber-400' : 'border-border-subtle bg-surface-1 text-text-secondary'}`}
                >
                  <span className="flex items-center gap-1.5">
                    {isPremium ? <Lock className="w-4 h-4 text-amber-400" /> : <Unlock className="w-4 h-4" />}
                    {isPremium ? 'PREMIUM (Locked)' : 'FREE (Ochiq)'}
                  </span>
                </div>
              </div>
            </div>

            {isPremium && (
              <Input
                type="number"
                label="Test narxi (Sumda)"
                placeholder="25000"
                value={testPrice}
                onChange={(e) => setTestPrice(e.target.value)}
                icon={<Sparkles className="w-4 h-4 text-amber-500 animate-spin" />}
              />
            )}
          </div>
        </Card>
      )}

      {/* STEP 2: Questions feed / OCR doc scanner */}
      {wizardStep === 2 && (
        <Card variant="glass" className="p-6 space-y-4 border-border-subtle animate-fade-in">
          <h4 className="text-sm font-black text-white border-b border-border-subtle pb-2 uppercase tracking-wide">2-Bosqich: Savollarni kiriting</h4>
          
          <OCRUploader onExtractionComplete={handleOcrExtraction} />

          <div className="text-center py-4 border-t border-border-subtle/40">
            <span className="text-xs text-text-secondary">Yoki yangi bo'sh savollar varag'ini qo'lda to'ldirmoqchimisiz?</span>
            <div className="mt-3 flex justify-center">
              <Button
                variant="secondary"
                size="sm"
                onClick={() => {
                  setQuestionsDeck([{ question_text: '', options: ['', '', '', ''], correct_index: 0, topic: 'Biologiya' }]);
                  setWizardStep(4);
                }}
              >
                Qo'lda to'ldirish
              </Button>
            </div>
          </div>
        </Card>
      )}

      {/* STEP 3: Illustration linker */}
      {wizardStep === 3 && (
        <Card variant="glass" className="p-6 border-border-subtle animate-fade-in">
          <h4 className="text-sm font-black text-white border-b border-border-subtle pb-2 uppercase tracking-wide mb-4">3-Bosqich: Rasmlarni muvofiqlashtirish (Rasm qo'shish)</h4>
          <ImageMapper questions={questionsDeck} onMappingComplete={handleImageMappingResult} />
        </Card>
      )}

      {/* STEP 4: Editing Preview Table and saving */}
      {wizardStep === 4 && (
        <Card variant="glass" className="p-5 border-border-subtle animate-fade-in">
          <h4 className="text-sm font-black text-white border-b border-border-subtle pb-2 uppercase tracking-wide mb-4">4-Bosqich: Tekshirish va Yuborish (Ulashishdan oldin tahrir qilish)</h4>
          <TestPreview initialQuestions={questionsDeck} onSave={handleFinalSave} />
        </Card>
      )}

      {/* Bottom wizard operations bar */}
      <footer id="creator_wizard_footer" className="flex items-center justify-between border-t border-border-subtle/50 pt-4 gap-4">
        {wizardStep >= 1 && (
          <Button variant="glass" className="px-6" onClick={handlePrevWizardStep}>
            Orqaga
          </Button>
        )}
        
        {wizardStep < 4 && (
          <Button variant="primary" className="ml-auto px-8" onClick={handleNextWizardStep}>
            Keyingisi
          </Button>
        )}
      </footer>

    </div>
  );
}

// ✅ DONE: src/components/teacher/TestCreator.jsx

// ✅ DONE: src/components/teacher/TestCreator.jsx
