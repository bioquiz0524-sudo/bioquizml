// ✅ Spaced Repetition Flip cards board with SM-2 scheduling links
import React, { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabaseClient';
import { useAuthStore } from '../../store/useAuthStore';
import { useAppStore } from '../../store/useAppStore';
import { calculateNextReview } from '../../lib/spacedRepetition';
import { triggerHaptic } from '../../lib/telegramAuth';
import Button from '../ui/Button';
import Card from '../ui/Card';
import Badge from '../ui/Badge';
import { Brain, Smile, Meh, Frown, Sparkles, RefreshCcw, CheckSquare, Award } from 'lucide-react';

export default function FlashcardViewer() {
  const { profile } = useAuthStore();
  const { showToast } = useAppStore();

  const [flashcards, setFlashcards] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (profile?.id) {
      loadDueFlashcards();
    }
  }, [profile?.id]);

  const loadDueFlashcards = async () => {
    setIsLoading(true);
    try {
      // Fetch cards whose next review date is today or earlier
      const nowString = new Date().toISOString();
      const { data: progressList } = await supabase
        .from('student_flashcard_progress')
        .select(`
          id,
          flashcard_id,
          confidence_level,
          review_count,
          interval,
          easiness_factor,
          flashcards (
            id,
            front_text,
            back_text,
            topic,
            difficulty
          )
        `)
        .eq('student_id', profile.id)
        .lte('next_review_date', nowString);

      if (progressList && progressList.length > 0) {
        // Flatten list items
        const list = progressList.map((pr) => ({
          progress_id: pr.id,
          flashcard_id: pr.flashcard_id,
          review_count: pr.review_count || 0,
          interval: pr.interval || 1,
          easiness_factor: pr.easiness_factor || 2.5,
          front: pr.flashcards?.front_text || 'Savol nufuzi',
          back: pr.flashcards?.back_text || 'Javob matni',
          topic: pr.flashcards?.topic || 'Biologiya',
          difficulty: pr.flashcards?.difficulty || 'o_rta'
        }));
        setFlashcards(list);
      } else {
        // Fetch remaining cards from general collection in center as fallback if no custom failed reviews are due
        const { data: generalFc } = await supabase
          .from('flashcards')
          .select('*')
          .limit(8);

        if (generalFc) {
          const list = generalFc.map((g, i) => ({
            progress_id: null,
            flashcard_id: g.id,
            review_count: 0,
            interval: 1,
            easiness_factor: 2.5,
            front: g.front_text,
            back: g.back_text,
            topic: g.topic || 'Uslubiy',
            difficulty: g.difficulty || 'o_rta'
          }));
          setFlashcards(list);
        }
      }
    } catch (e) {
      console.error("Flashcards load exception", e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFlipCard = () => {
    setIsFlipped(!isFlipped);
    triggerHaptic('light');
  };

  const handleVoteConfidence = async (score) => {
    if (flashcards.length === 0) return;
    
    triggerHaptic('success');
    const activeCard = flashcards[currentIndex];

    // Compute SM-2 variables through spacer helper
    const calculated = calculateNextReview(
      score,
      activeCard.review_count
    );

    try {
      if (profile?.id) {
        const payload = {
          student_id: profile.id,
          flashcard_id: activeCard.flashcard_id,
          confidence_level: score,
          review_count: calculated.review_count,
          easiness_factor: 2.5,
          interval: score >= 4 ? (score === 5 ? 14 : 7) : (score >= 2 ? 3 : 1),
          next_review_date: calculated.next_review_date
        };

        if (activeCard.progress_id) {
          payload.id = activeCard.progress_id;
        }

        await supabase.from('student_flashcard_progress').upsert(payload);
      }

      showToast("Kartaxonadagi taraqqiyot saqlandi!", "success");

      // Slide to next card instance
      setIsFlipped(false);
      setTimeout(() => {
        if (currentIndex + 1 < flashcards.length) {
          setCurrentIndex(currentIndex + 1);
        } else {
          // Finished cards batch
          setFlashcards([]);
          setCurrentIndex(0);
          showToast("Ajoyib! Bugungi flashcardlar darsini yakunladingiz!", "success");
        }
      }, 250);

    } catch (err) {
      showToast("Tizimda og'ish yuz berdi.", "error");
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-[300px] flex items-center justify-center text-text-secondary animate-pulse text-sm">
        Sizning interval kartalaringiz hisob-kitob qilinmoqda...
      </div>
    );
  }

  return (
    <div id="spaced_flashcard_container" className="w-full space-y-6 animate-fade-in text-left pb-[90px]">
      
      {/* Visual Title card */}
      <Card variant="glass" className="p-4.5 border-primary-green/20">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-primary-green/10 text-primary-green">
            <Brain className="w-5.5 h-5.5 text-[#00E676] animate-pulse" />
          </div>
          <div className="text-left flex-grow">
            <h3 className="font-extrabold text-white text-base">Interval Flashcard takrorlash</h3>
            <p className="text-xs text-text-secondary">Xato qilingan savollar asosida yodlash darslari</p>
          </div>
        </div>
      </Card>

      {flashcards.length === 0 ? (
        <Card variant="glass" className="p-10 text-center border-dashed border-border-subtle max-w-sm mx-auto space-y-4">
          <div className="w-14 h-14 bg-primary-green/10 flex items-center justify-center rounded-full mx-auto shadow-2xl">
            <Award className="w-7 h-7 text-primary-green animate-bounce" />
          </div>
          <div className="space-y-1">
            <h4 className="font-extrabold text-[#E8F5E9] text-base">Hozircha hamma darslar yodlandi!</h4>
            <p className="text-xs text-text-secondary">Xato imtihon mavzulari topilsa yangi takrorlash kartalari avtomatik qo'shiladi.</p>
          </div>
          <Button variant="secondary" size="sm" className="w-full" onClick={loadDueFlashcards} icon={<RefreshCcw className="w-4 h-4" />}>
            Qayta yuklash
          </Button>
        </Card>
      ) : (
        <div className="max-w-sm mx-auto space-y-5">
          {/* Card counter */}
          <div className="text-right text-xs font-semibold text-text-secondary pl-1 font-mono">
            Takrorlash varag'i: <strong className="text-white">{currentIndex + 1} / {flashcards.length}</strong>
          </div>

          {/* 3D Rotational visual Flashcard object using pure CSS matrix flips */}
          <div
            id="spaced_flip_card"
            onClick={handleFlipCard}
            className={`w-full h-72 cursor-pointer transition-transform duration-500 transform ease-in-out select-none preserve-3d relative
            ${isFlipped ? 'rotate-y-180' : ''}`}
          >
            {/* FRONT side */}
            <div className="absolute inset-0 backface-hidden glass-panel p-6 flex flex-col justify-between rounded-3xl border border-border-subtle bg-surface-1 shadow-2xl">
              <div className="flex justify-between items-center">
                <Badge variant="blue">{flashcards[currentIndex].topic}</Badge>
                <Badge variant="default">Savol ko'rinishi</Badge>
              </div>

              <div className="text-center py-4 flex-grow flex items-center justify-center">
                <p className="text-base sm:text-lg font-bold text-white text-glow-light leading-relaxed">
                  {flashcards[currentIndex].front}
                </p>
              </div>

              <p className="text-[10px] text-center text-text-muted font-mono uppercase tracking-widest animate-pulse">Aylantirish uchun bosing 🔄</p>
            </div>

            {/* BACK side */}
            <div className="absolute inset-0 backface-hidden rotate-y-180 glass-panel p-6 flex flex-col justify-between rounded-3xl border-2 border-primary-green bg-card-bg shadow-[0_0_20px_rgba(0,230,118,0.1)]">
              <div className="flex justify-between items-center">
                <Badge variant="pro">{flashcards[currentIndex].topic}</Badge>
                <Badge variant="success">Yodlash Kaliti</Badge>
              </div>

              <div className="text-center py-4 flex-grow flex items-center justify-center">
                <p className="text-lg font-black text-primary-green text-glow leading-relaxed">
                  {flashcards[currentIndex].back}
                </p>
              </div>

              <p className="text-[10px] text-center text-[#69F0AE] font-mono uppercase tracking-widest">To'liq javob kaliti 🧬</p>
            </div>
          </div>

          {/* Actions Voting dock */}
          {isFlipped && (
            <Card variant="glass" className="p-4 border-border-subtle space-y-3 animate-slide-up">
              <p className="text-center text-xs font-bold text-text-secondary">Ushbu javobni qanchalik tez esladingiz?</p>
              
              <div className="grid grid-cols-3 gap-2">
                <Button
                  variant="danger"
                  className="px-2 font-bold text-xs h-12 gap-1"
                  onClick={() => handleVoteConfidence(2)}
                >
                  <Frown className="w-4 h-4 text-[#020c07]" /> Unutdim
                </Button>
                <Button
                  variant="glass"
                  className="px-2 font-semibold text-xs border border-warning-accent text-warning-accent hover:bg-warning-accent/10 h-12 gap-1"
                  onClick={() => handleVoteConfidence(4)}
                >
                  <Meh className="w-4 h-4 text-warning-accent" /> O'rtacha
                </Button>
                <Button
                  variant="primary"
                  className="px-2 font-bold text-xs glow-green h-12 gap-1 text-[#020c07]"
                  onClick={() => handleVoteConfidence(5)}
                >
                  <Smile className="w-4 h-4 text-[#020c07]" /> Esladim!
                </Button>
              </div>
            </Card>
          )}
        </div>
      )}

    </div>
  );
}

// ✅ DONE: src/components/student/FlashcardViewer.jsx
