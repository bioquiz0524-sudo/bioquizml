/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// ✅ Complete Full-Stack React Orchestration Routing for BioQuiz Platform Telegram Mini App
import React, { useEffect, useState } from 'react';
import { useAuthStore } from './store/useAuthStore';
import { useAppStore } from './store/useAppStore';
import { useQuizStore } from './store/useQuizStore';
import { triggerHaptic } from './lib/telegramAuth';
import OnboardingFlow from './components/auth/OnboardingFlow';
import StudentDashboard from './components/student/Dashboard';
import TeacherDashboard from './components/teacher/Dashboard';
import AdminDashboard from './components/admin/AdminDashboard';
import FlashcardViewer from './components/student/FlashcardViewer';
import StudentProfile from './components/student/Profile';
import QuizEngine from './components/quiz/QuizEngine';
import Toast from './components/ui/Toast';
import Modal from './components/ui/Modal';
import Button from './components/ui/Button';
import BottomNav from './components/ui/BottomNav';
import Card from './components/ui/Card';
import { Coins, Sparkles, LogOut, ShieldAlert, Award, Star, ShoppingBag, Landmark } from 'lucide-react';

export default function App() {
  const { profile, isLoading: authLoading, login: loadProfile, logout, addCredits, updateProfile } = useAuthStore();
  const { activeTab, setActiveTab, modals, closeModal, showToast } = useAppStore();

  const [playingTest, setPlayingTest] = useState(null);
  const [playingQuestions, setPlayingQuestions] = useState([]);
  
  // States of selected live session waits room
  const [liveSessPin, setLiveSessPin] = useState(null);
  const [liveSessObj, setLiveSessObj] = useState(null);

  // Initialize and load telegram profiles
  useEffect(() => {
    loadProfile();
  }, []);

  const handleStartActiveTest = (testObj, questionsList) => {
    setPlayingTest(testObj);
    setPlayingQuestions(questionsList);
  };

  const handleFinishActiveTest = () => {
    setPlayingTest(null);
    setPlayingQuestions([]);
    setActiveTab('dashboard');
  };

  const handleJoinLiveWaitRoom = (formattedPin, sessionObject) => {
    setLiveSessPin(formattedPin);
    setLiveSessObj(sessionObject);
  };

  const handleExitLiveWaitRoom = () => {
    setLiveSessPin(null);
    setLiveSessObj(null);
    setActiveTab('dashboard');
  };

  const handleDirectCreditsBuy = async (amount) => {
    triggerHaptic('success');
    try {
      await addCredits(amount);
      showToast(`${amount.toLocaleString()} UZS hisobingizga qo'shildi!`, 'success');
      closeModal('refill_balance_modal');
    } catch (e) {
      showToast('To\'ldirishda xatolik yuz berdi.', 'error');
    }
  };

  const handleBuyProStatusInApp = async () => {
    triggerHaptic('success');
    const balance = profile?.wallet_balance || 0;
    
    if (balance < 50000) {
      showToast("Balansingiz yetarli emas! Premium narxi 50,000 UZS", "error");
      closeModal('upgrade_modal');
      return;
    }

    try {
      const net = balance - 50000;
      await updateProfile({
        wallet_balance: net,
        is_pro: true
      });
      showToast("Tabriklaymiz! Siz PRO talaba unvonini qo'lga kiritdingiz!", "success");
      closeModal('upgrade_modal');
    } catch (e) {
      showToast("PRO ulanishda muammo.", "error");
    }
  };

  // 1. Loading initialization wrapper page
  if (authLoading) {
    return (
      <div id="big_init_spinner" className="min-h-screen bg-bg flex flex-col justify-center items-center text-center p-6">
        <div className="w-16 h-16 rounded-3xl bg-surface-1 border border-primary-green flex items-center justify-center shadow-[0_0_15px_rgba(0,230,118,0.25)] animate-pulse-glow mb-4">
          <Sparkles className="w-8 h-8 text-primary-green" />
        </div>
        <h2 className="text-white text-lg font-black tracking-widest font-sans uppercase">BIOQUIZ</h2>
        <p className="text-xs text-text-secondary mt-1 font-semibold animate-pulse">Profil ma'lumotlari bazadan yuklanmoqda...</p>
      </div>
    );
  }

  // 2. Multi-step Onboarding selector if user profile is new or incomplete
  const needsOnboarding = !profile?.role || !profile?.learning_center;
  if (needsOnboarding) {
    return (
      <div id="onboarding_layer" className="bg-bg min-h-screen">
        <OnboardingFlow />
        <Toast />
      </div>
    );
  }

  // 3. Immersive FULL VIEWPORT Testplay Takeover
  if (playingTest && playingQuestions.length > 0) {
    return (
      <div id="quiz_immersive_takeover" className="min-h-screen bg-bg p-4 flex flex-col justify-center max-w-md mx-auto">
        <QuizEngine
          test={playingTest}
          initialQuestions={playingQuestions}
          onFinished={handleFinishActiveTest}
        />
        <Toast />
      </div>
    );
  }

  // 4. Immersive Kahoot Wait lobby room
  if (liveSessPin) {
    return (
      <div id="live_session_lobby_room" className="min-h-screen bg-bg px-4 py-8 flex flex-col justify-between max-w-md mx-auto text-center">
        <header className="space-y-4 pt-6">
          <div className="w-16 h-16 rounded-3xl bg-surface-1 border-2 border-primary-green flex items-center justify-center mx-auto shadow-[0_0_20px_rgba(0,230,118,0.3)] animate-pulse-glow">
            <Award className="w-8 h-8 text-primary-green" />
          </div>
          <div className="space-y-1">
            <span className="text-[10px] font-mono font-black tracking-widest text-primary-green uppercase bg-primary-green/10 px-3 py-1 rounded-full">SINF LOBBISI</span>
            <h2 className="text-3xl font-black font-mono text-white tracking-widest text-glow mt-2">{liveSessPin}</h2>
          </div>
        </header>

        <main className="gym-cards-area flex items-center justify-center py-8">
          <Card variant="glass" className="p-6 border-primary-green/35 animate-scale-in max-w-sm space-y-4">
            <h3 className="font-extrabold text-white text-base">Musobaqa uningiz muvaffaqiyatli drayverlandi</h3>
            <p className="text-xs text-text-secondary leading-relaxed">
              Siz bellashuv xonasiga qo'shildingiz! O'qituvchi ekrandan start tugmasini bosgandan so'ng, biologiya savollari telefoningizda reaktiv shakllanadi.
            </p>
            <div className="w-8 h-8 border-2 border-border-subtle border-t-primary-green border-r-primary-green rounded-full animate-spin mx-auto mt-2" />
          </Card>
        </main>

        <footer className="action-exit">
          <Button variant="danger" className="w-full" onClick={handleExitLiveWaitRoom}>
            Lobbini tark etish
          </Button>
        </footer>
        <Toast />
      </div>
    );
  }

  return (
    <div id="root_layout_container" className="min-h-screen bg-bg text-text-primary px-4 pt-5 pb-24 max-w-lg mx-auto overflow-x-hidden relative">
      {/* Decorative ambient glowing backdrops of the Sleek Interface Theme */}
      <div className="absolute top-[-100px] left-[-100px] w-[300px] h-[300px] bg-[#00E676] opacity-10 blur-[120px] rounded-full pointer-events-none"></div>
      <div className="absolute bottom-[-100px] right-[-100px] w-[300px] h-[300px] bg-[#00BCD4] opacity-5 blur-[120px] rounded-full pointer-events-none"></div>
      
      {/* 5. TOP NOTIFY HEADER */}
      <header id="layout_top_header" className="flex items-center justify-between mb-6">
        <div className="text-left space-y-0.5">
          <span className="text-[10px] font-bold font-mono tracking-widest text-[#00E676] uppercase">BIOQUIZ PLATFORMA</span>
          <h1 className="text-white text-lg font-black tracking-tight">{profile.role === 'teacher' ? 'O\'qituvchi Kabineti' : 'Talaba Kabineti'}</h1>
        </div>

        {/* Action Logout selector */}
        <button
          id="logout_action"
          onClick={() => { logout(); triggerHaptic('error'); }}
          className="p-2 bg-surface-1 border border-border-subtle hover:border-danger-accent/50 rounded-xl text-text-secondary hover:text-[#FF5252] transition-colors cursor-pointer"
          title="Tizimdan chiqish"
        >
          <LogOut className="w-5 h-5" />
        </button>
      </header>

      {/* 6. DYNAMIC TAB CONTAINER */}
      <main id="layout_primary_content_portal" className="w-full">
        {activeTab === 'dashboard' && (
          profile.role === 'teacher' 
            ? <TeacherDashboard /> 
            : <StudentDashboard onSelectSessionCode={handleJoinLiveWaitRoom} onSelectQuiz={handleStartActiveTest} />
        )}

        {activeTab === 'flashcards' && (
          profile.role === 'teacher'
            ? (
              <Card variant="glass" className="p-8 text-center border-dashed border-border-subtle">
                <ShieldAlert className="w-12 h-12 text-primary-green mx-auto mb-3" />
                <p className="text-base font-extrabold text-[#E8F5E9] mb-1">Flashcardlar faqat talabar uchun</p>
                <p className="text-xs text-text-secondary">O'qituvchi sifatida yangi savollar yaratganingizda guruhdagi studentlar interval takrorlash kartalarini ko'rishadi.</p>
              </Card>
            )
            : <FlashcardViewer />
        )}

        {activeTab === 'profile' && (
          <StudentProfile />
        )}

        {activeTab === 'admin' && (
          profile.role === 'admin' ? <AdminDashboard /> : <TeacherDashboard />
        )}
      </main>

      {/* 7. PERSISTENT NAVIGATION footer */}
      <BottomNav />

      {/* 8. GLOBAL BOTTOM SHEET MODALS */}
      
      {/* Refill coins virtual balance modal popup */}
      <Modal
        id="refill_balance_modal"
        isOpen={modals.refill_balance_modal}
        onClose={() => closeModal('refill_balance_modal')}
        title="Hamyon virtual balansini oshirish"
      >
        <div className="space-y-5 text-left">
          <p className="text-xs text-text-secondary">
            Xarid qilmoqchi bo'lgan premium testlaringiz uchun virtual so'm miqdorlarini hisobingizga yuklang:
          </p>

          <div className="grid grid-cols-1 gap-3">
            {[
              { title: 'Kichik to\'plam', desc: 'Sodda testlar va bitta sinov', amount: 15000 },
              { title: 'O\'rta takroriy imkon', desc: 'Blok testlar va mavzuli darslar', amount: 30000 },
              { title: 'Olimlik daraja paket', desc: 'Cheksiz biologiya test sayohati', amount: 50000 }
            ].map((pack) => (
              <Card
                key={pack.amount}
                variant="interactive"
                className="p-4 flex items-center justify-between border-border-subtle"
                onClick={() => handleDirectCreditsBuy(pack.amount)}
              >
                <div className="text-left space-y-0.5">
                  <h4 className="font-bold text-white text-sm">{pack.title}</h4>
                  <p className="text-xs text-text-secondary">{pack.desc}</p>
                </div>
                <span className="font-mono text-sm font-black text-primary-green">+{pack.amount.toLocaleString()} UZS</span>
              </Card>
            ))}
          </div>
        </div>
      </Modal>

      {/* PRO Premium modal popup */}
      <Modal
        id="upgrade_modal"
        isOpen={modals.upgrade_modal}
        onClose={() => closeModal('upgrade_modal')}
        title="PRO Premium hisobiga o'tish"
      >
        <div className="space-y-6 text-left">
          <div className="w-12 h-12 bg-amber-500/10 border border-amber-500 flex items-center justify-center rounded-2xl shadow-xl mx-auto mb-2 animate-bounce-short">
            <Star className="w-6 h-6 text-amber-500 fill-current" />
          </div>

          <div className="text-center space-y-1">
            <h4 className="text-lg font-black text-white">PRO Status Oltin Imkoniyati</h4>
            <p className="text-xs text-text-secondary">Takrorlash kartalari va ilg'or AI tahlillar doskasi qulfini butunlay oching</p>
          </div>

          <div className="bg-surface-2 p-4 rounded-xl border border-border-subtle space-y-2 text-xs text-text-secondary">
            <p className="flex items-center gap-2">✨ Cheksiz sun'iy intellekt (OCR) drayverlari</p>
            <p className="flex items-center gap-2">✨ Xato imtihon ko'rsatgichlaridan automatic Spaced Repetition flashcardlar</p>
            <p className="flex items-center gap-2">✨ O'qituvchining individual guruhlarida barcha pullik testlar BEPUL</p>
          </div>

          <div className="flex gap-3 justify-end items-center pt-2">
            <Button variant="ghost" onClick={() => closeModal('upgrade_modal')}>Orqaga</Button>
            <Button variant="primary" className="bg-amber-400 hover:bg-amber-500 border border-amber-400 font-extrabold px-6" onClick={handleBuyProStatusInApp}>
              <ShoppingBag className="w-4 h-4 mr-1 text-bg" /> 50,000 UZS ga yuklash
            </Button>
          </div>
        </div>
      </Modal>

      <Toast />
    </div>
  );
}

