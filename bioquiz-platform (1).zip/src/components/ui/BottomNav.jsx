// ✅ Fixed Position Bottom Tab Navigation Bar for Telegram Webapp WebView
import React from 'react';
import { useAppStore } from '../../store/useAppStore';
import { useAuthStore } from '../../store/useAuthStore';
import { LayoutDashboard, BrainCircuit, User, ShieldAlert } from 'lucide-react';
import { triggerHaptic } from '../../lib/telegramAuth';

export default function BottomNav() {
  const { activeTab, setActiveTab } = useAppStore();
  const { profile } = useAuthStore();

  const handleTabChange = (tabId) => {
    setActiveTab(tabId);
    triggerHaptic('light');
  };

  const navItems = [
    { id: 'dashboard', label: 'Bosh sahifa', icon: <LayoutDashboard className="w-5.5 h-5.5" /> },
    { id: 'flashcards', label: 'Flashcards', icon: <BrainCircuit className="w-5.5 h-5.5" /> },
    { id: 'profile', label: 'Kabinet', icon: <User className="w-5.5 h-5.5" /> },
  ];

  // If user is a teacher or an admin, show the administrative navigation tab
  const canSeeAdmin = profile?.role === 'admin' || profile?.role === 'teacher';
  if (canSeeAdmin) {
    navItems.push({
      id: 'admin',
      label: profile.role === 'admin' ? 'Admin' : 'Sinfim',
      icon: <ShieldAlert className="w-5.5 h-5.5" />
    });
  }

  return (
    <nav
      id="bottom_nav_bar"
      className="fixed bottom-0 left-0 right-0 z-40 bg-surface-1/90 backdrop-blur-lg border-t border-border-subtle/70 px-2.5 pb-safe-bottom h-[72px] flex items-center justify-around shadow-2xl"
    >
      <div className="w-full max-w-lg mx-auto flex items-center justify-around">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              id={`nav_${item.id}`}
              key={item.id}
              onClick={() => handleTabChange(item.id)}
              className={`flex flex-col items-center justify-center gap-1.5 h-full px-4 text-xs font-semibold select-none transition-all duration-250 cursor-pointer
              ${isActive ? 'text-primary-green scale-110 font-bold' : 'text-text-secondary opacity-60 hover:opacity-100 hover:text-white'}`}
            >
              <div
                id={`nav_${item.id}_icon`}
                className={`transition-transform duration-300 ${isActive ? 'drop-shadow-[0_0_8px_rgba(0,230,118,0.5)] scale-110' : ''}`}
              >
                {item.icon}
              </div>
              <span id={`nav_${item.id}_label`} className="text-[10px] sm:text-xs tracking-tight">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}

// ✅ DONE: src/components/ui/BottomNav.jsx
