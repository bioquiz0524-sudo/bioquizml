// ✅ Interactive OCR drag & drop zone with animated upload indicators
import React, { useState } from 'react';
import { processDocumentOCR } from '../../lib/ocrProcessor';
import { useAppStore } from '../../store/useAppStore';
import { triggerHaptic } from '../../lib/telegramAuth';
import ProgressBar from '../ui/ProgressBar';
import { UploadCloud, FileText, Sparkles, Brain } from 'lucide-react';

export default function OCRUploader({ onExtractionComplete }) {
  const { showToast } = useAppStore();
  const [isDragging, setIsDragging] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadedFileName, setUploadedFileName] = useState('');

  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const processFile = async (file) => {
    // 20MB size constraint validation
    if (file.size > 20 * 1024 * 1024) {
      showToast("Fayl hajmi 20MB dan oshishi mumkin emas!", "error");
      triggerHaptic('error');
      return;
    }

    setUploadedFileName(file.name);
    setIsProcessing(true);
    setUploadProgress(10);
    triggerHaptic('light');

    try {
      const extractedQs = await processDocumentOCR(file, (p) => {
        setUploadProgress(p);
      });

      if (extractedQs && extractedQs.length > 0) {
        showToast("AI Savollarni muvaffaqiyatli aniqladi!", "success");
        triggerHaptic('success');
        if (onExtractionComplete) {
          onExtractionComplete(extractedQs);
        }
      } else {
        showToast("Hujjatdan savollarni ajratib bo'lmadi. Qayta urinib ko'ring.", "warning");
      }
    } catch (err) {
      showToast("Hujjatni o'qishda xatolik yuz berdi.", "error");
    } finally {
      setIsProcessing(false);
      setIsDragging(false);
      setUploadProgress(0);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) {
      processFile(file);
    }
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      processFile(file);
    }
  };

  return (
    <div id="ocr_uploader_container" className="w-full space-y-4">
      {isProcessing ? (
        <div id="ocr_processing_view" className="glass-panel p-8 rounded-2xl border border-primary-green/30 text-center space-y-4 animate-pulse">
          <div className="w-14 h-14 rounded-full bg-primary-green/10 flex items-center justify-center mx-auto shadow-[0_0_15px_rgba(0,230,118,0.2)]">
            <Brain className="w-7 h-7 text-primary-green animate-spin" />
          </div>
          <div className="space-y-1.5">
            <h4 className="font-extrabold text-white text-base">Hujjat tahlil qilinmoqda...</h4>
            <p className="text-xs text-text-secondary">Gemini AI savollar, variantlar va kalitlarni formatlamoqda</p>
          </div>
          <div className="max-w-xs mx-auto">
            <ProgressBar value={uploadProgress} color="green" showText />
          </div>
          <p className="text-[10px] font-mono text-text-muted">Yuklangan fayl: {uploadedFileName}</p>
        </div>
      ) : (
        <label
          id="drag_drop_zone"
          onDragOver={handleDragOver}
          onDragLeave={handleDragLeave}
          onDrop={handleDrop}
          className={`relative block w-full p-8 rounded-2xl border-2 border-dashed text-center transition-all cursor-pointer select-none
          ${isDragging 
            ? 'border-primary-green bg-primary-green/10 shadow-[0_0_20px_rgba(0,230,118,0.15)] scale-102' 
            : 'border-border-subtle bg-surface-1/40 hover:bg-surface-2 hover:border-text-secondary/50'}`}
        >
          <input
            id="hidden_file_input"
            type="file"
            accept=".pdf,.doc,.docx,image/*"
            onChange={handleFileChange}
            className="hidden"
          />
          <div className="space-y-4">
            <div className="w-12 h-12 rounded-xl bg-surface-2 border border-border-subtle flex items-center justify-center mx-auto text-text-secondary">
              <UploadCloud className="w-6 h-6 hover:text-primary-green transition-colors" />
            </div>
            <div className="space-y-1.5">
              <h4 className="font-bold text-white text-sm">Savollarni import qilish</h4>
              <p className="text-xs text-text-secondary">PDF, rasm yoki MS Word hujjatlarini shu yerga tashlang yoki bosing</p>
            </div>
            <div className="flex justify-center items-center gap-4 text-[10px] text-text-muted font-mono">
              <span className="flex items-center gap-1"><FileText className="w-3.5 h-3.5" /> Maks: 20MB</span>
              <span className="flex items-center gap-1"><Sparkles className="w-3.5 h-3.5 text-primary-green" /> AI qo'llab-quvvatlaydi</span>
            </div>
          </div>
        </label>
      )}
    </div>
  );
}

// ✅ DONE: src/components/teacher/OCRUploader.jsx
